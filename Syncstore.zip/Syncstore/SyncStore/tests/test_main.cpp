// test_main.cpp - self-contained test suite (no external framework).
// Every test prints PASS/FAIL with the expected value, then a summary. Exit code 0 = all passed.
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <future>
#include <iostream>
#include <memory>
#include <random>
#include <set>
#include <sstream>
#include <thread>
#include <csignal>
#include <sys/wait.h>
#include <unistd.h>
#include "command_parser.h"
#include "cpu_work.h"
#include "ipc.h"
#include "kernel_probe.h"
#include "physical_map.h"
#include "real_workload.h"
#include "job_scheduler.h"
#include "syncstore.h"

namespace fs = std::filesystem;
static int g_pass = 0, g_fail = 0;

#define CHECK(cond, msg)                                                          \
    do {                                                                          \
        if (cond) { ++g_pass; std::cout << "    PASS  " << msg << "\n"; }         \
        else      { ++g_fail; std::cout << "    FAIL  " << msg << "   (line " << __LINE__ << ")\n"; } \
    } while (0)

static std::string tmpDb(const std::string& name) {
    fs::create_directories("/tmp/syncstore_tests");
    std::string p = "/tmp/syncstore_tests/" + name + ".db";
    fs::remove(p);
    return p;
}

static std::unique_ptr<SyncStore> makeStore(const std::string& name, int workers = 1, std::size_t frames = 8,
                                            int unitUs = 50) {
    Config c;
    c.dbPath = tmpDb(name);
    c.workers = workers;
    c.frames = frames;
    c.cpuUnitUs = unitUs;
    return std::unique_ptr<SyncStore>(new SyncStore(c));
}

static std::string str(const std::vector<int>& v) {
    std::ostringstream o;
    o << "[";
    for (std::size_t i = 0; i < v.size(); ++i) o << (i ? " " : "") << v[i];
    return o.str() + "]";
}

// ---------------------------------------------------------------------------------------------
// CPU scheduling: build a ready queue while workers are paused, release one worker, and read the
// order in which the scheduler dispatched the requests (1-based position of submission).
static std::vector<int> cpuOrder(SyncStore& s, CpuAlgo algo, const std::vector<std::pair<int, int>>& burstPrio) {
    s.stats().reset();
    s.setCpuAlgorithm(algo);
    s.pauseDispatch();
    std::vector<RequestPtr> rs;
    for (std::size_t i = 0; i < burstPrio.size(); ++i) {
        auto r = s.makeRequest(CmdType::SET, {{"k" + std::to_string(i), "v"}}, 1);
        r->burst = burstPrio[i].first;
        r->priority = burstPrio[i].second;
        s.submit(r);
        rs.push_back(r);
    }
    s.resumeDispatch();
    s.waitIdle();
    std::vector<int> order;
    for (auto id : s.stats().dispatchOrder()) order.push_back(static_cast<int>(id - rs[0]->id) + 1);
    return order;
}

static void testCpuScheduling() {
    std::cout << "\n[1-4] CPU scheduling (real worker executes in scheduler order, 1 worker)\n";
    auto s = makeStore("cpu");
    std::vector<std::pair<int, int>> jobs = {{6, 3}, {8, 1}, {7, 4}, {3, 2}};   // (burst, priority) for R1..R4
    CHECK(cpuOrder(*s, CpuAlgo::FCFS, jobs) == (std::vector<int>{1, 2, 3, 4}), "FCFS order = R1 R2 R3 R4");
    CHECK(cpuOrder(*s, CpuAlgo::SJF, jobs) == (std::vector<int>{4, 1, 3, 2}), "SJF order (bursts 6,8,7,3) = R4 R1 R3 R2");
    CHECK(cpuOrder(*s, CpuAlgo::PRIORITY, jobs) == (std::vector<int>{2, 4, 1, 3}), "Priority order (prio 3,1,4,2) = R2 R4 R1 R3");

    s->setQuantum(3);
    auto rr = cpuOrder(*s, CpuAlgo::RR, {{5, 1}, {3, 1}, {4, 1}});
    CHECK(rr == (std::vector<int>{1, 2, 3, 1, 3}), "Round Robin q=3, bursts 5,3,4 -> dispatches R1 R2 R3 R1 R3");
    CHECK(s->stats().preemptions() == 2, "Round Robin preempted exactly 2 times");
    CHECK(s->stats().completed() == 3, "all 3 RR requests completed");
    CHECK(s->stats().avgTurnaroundUs() >= s->stats().avgWaitUs() && s->stats().avgWaitUs() >= 0,
          "turnaround >= waiting time (computed from real clocks)");
}

// ---------------------------------------------------------------------------------------------
static std::vector<int> planBlocks(const DiskPlan& p, const std::vector<int>& req) {
    std::vector<int> r;
    for (auto i : p.order) r.push_back(req[i]);
    return r;
}

static void testDiskScheduling() {
    std::cout << "\n[5-6] Disk scheduling (textbook example: head 53, requests 98 183 37 122 14 124 65 67, blocks 0..199)\n";
    const std::vector<int> req = {98, 183, 37, 122, 14, 124, 65, 67};
    struct Case { DiskAlgo a; long seek; std::vector<int> order; };
    std::vector<Case> cases = {
        {DiskAlgo::FCFS,  640, {98, 183, 37, 122, 14, 124, 65, 67}},
        {DiskAlgo::SSTF,  236, {65, 67, 37, 14, 98, 122, 124, 183}},
        {DiskAlgo::SCAN,  331, {65, 67, 98, 122, 124, 183, 37, 14}},
        {DiskAlgo::CSCAN, 382, {65, 67, 98, 122, 124, 183, 14, 37}},
        {DiskAlgo::LOOK,  299, {65, 67, 98, 122, 124, 183, 37, 14}},
        {DiskAlgo::CLOOK, 322, {65, 67, 98, 122, 124, 183, 14, 37}},
    };
    for (auto& c : cases) {
        DiskPlan p = DiskScheduler::plan(c.a, 53, true, req, 199);
        CHECK(p.totalSeek == c.seek && planBlocks(p, req) == c.order,
              std::string(toString(c.a)) + ": seek " + std::to_string(p.totalSeek) + " (expected " +
              std::to_string(c.seek) + "), order " + str(planBlocks(p, req)));
    }
    DiskPlan down = DiskScheduler::plan(DiskAlgo::SCAN, 53, false, req, 199);   // sweeping downwards first
    CHECK(planBlocks(down, req) == (std::vector<int>{37, 14, 65, 67, 98, 122, 124, 183}) && down.totalSeek == 53 + 183,
          "SCAN with initial direction DOWN: 37 14 then 65.. (seek 236)");

    // Integration: the live scheduler thread reorders one real batch and performs the real writes.
    std::cout << "    -- live scheduler: same batch submitted as real writes to a file --\n";
    for (auto& c : cases) {
        Statistics st;
        BlockFile file(tmpDb("disk_live"));
        DiskScheduler disk(file, st);
        disk.setAlgorithm(c.a);
        disk.resetHead(53);
        std::vector<std::pair<int, BlockData>> items;
        for (int b : req) { BlockData d; d.fill(static_cast<char>(b)); items.push_back({b, d}); }
        disk.writeBlocks(items);
        std::vector<int> served;
        for (auto& e : st.diskOrder()) served.push_back(e.block);
        bool dataOk = true;
        for (int b : req) { BlockData d; file.readBlock(b, d); if (d[0] != static_cast<char>(b) || d[255] != static_cast<char>(b)) dataOk = false; }
        CHECK(served == c.order && st.totalSeek() == c.seek && dataOk,
              std::string(toString(c.a)) + " live: served " + str(served) + ", seek " + std::to_string(st.totalSeek()) + ", file contents correct");
    }
}

// ---------------------------------------------------------------------------------------------
struct PoolRig {
    Statistics st;
    BlockFile file;
    DiskScheduler disk;
    BufferPool pool;
    PoolRig(const std::string& n, std::size_t frames, ReplacementPolicy p)
        : file(tmpDb(n)), disk(file, st), pool(frames, p, disk, st) {}
};

static void touchBlocks(BufferPool& p, const std::vector<int>& seq) {
    BlockData d;
    for (int b : seq) p.readBlock(b, d);
}
static std::vector<int> sorted(std::vector<int> v) { std::sort(v.begin(), v.end()); return v; }

static void testPageReplacement() {
    std::cout << "\n[7-8] Page replacement (3 frames)\n";
    {
        PoolRig r("lru", 3, ReplacementPolicy::LRU);
        touchBlocks(r.pool, {1, 2, 3, 1, 4});
        CHECK(sorted(r.pool.cachedBlocks()) == (std::vector<int>{1, 3, 4}), "LRU: sequence 1 2 3 1 4 evicts block 2 -> cache {1,3,4}");
        CHECK(r.st.replacements() == 1, "LRU: exactly 1 replacement");
    }
    {
        PoolRig r("fifo", 3, ReplacementPolicy::FIFO);
        touchBlocks(r.pool, {1, 2, 3, 1, 4});
        CHECK(sorted(r.pool.cachedBlocks()) == (std::vector<int>{2, 3, 4}), "FIFO: same sequence evicts block 1 (oldest loaded) -> cache {2,3,4}");
    }
    {
        PoolRig r("clock", 3, ReplacementPolicy::CLOCK);
        touchBlocks(r.pool, {1, 2, 3, 4, 2, 5});
        CHECK(sorted(r.pool.cachedBlocks()) == (std::vector<int>{2, 4, 5}), "Clock: 1 2 3 4 2 5 -> block 2 gets a second chance, block 3 evicted -> {2,4,5}");
    }
    {
        PoolRig r("fifo2", 3, ReplacementPolicy::FIFO);
        touchBlocks(r.pool, {1, 2, 3, 4, 2, 5});
        CHECK(sorted(r.pool.cachedBlocks()) == (std::vector<int>{3, 4, 5}), "FIFO on the same sequence evicts block 2 -> {3,4,5} (differs from Clock)");
    }
}

static void testHitMissAndDirty() {
    std::cout << "\n[9] Cache hit/miss detection\n";
    {
        PoolRig r("hits", 3, ReplacementPolicy::LRU);
        touchBlocks(r.pool, {1, 2, 1, 3, 2});
        CHECK(r.st.cacheMisses() == 3 && r.st.cacheHits() == 2, "sequence 1 2 1 3 2: 3 misses, 2 hits");
        CHECK(r.st.diskAccesses() == 3, "only the 3 misses caused disk reads (hits never touch the disk)");
        CHECK(r.st.cacheHits() * 100 / (r.st.cacheHits() + r.st.cacheMisses()) == 40, "hit ratio = 40%");
    }
    std::cout << "\n[10] Dirty-page write-back\n";
    {
        PoolRig r("dirty", 2, ReplacementPolicy::LRU);
        BlockData a, b, c;
        a.fill('A'); b.fill('B'); c.fill('C');
        r.pool.writeBlock(1, a);
        r.pool.writeBlock(2, b);
        BlockData onDisk;
        r.file.readBlock(1, onDisk);
        CHECK(r.pool.isDirty(1) && onDisk[0] == 0 && r.st.writeBacks() == 0, "after writes: blocks are dirty in cache, disk still untouched");
        r.pool.writeBlock(3, c);                                  // pool full -> LRU victim is block 1
        r.file.readBlock(1, onDisk);
        CHECK(r.st.writeBacks() == 1 && onDisk[0] == 'A' && !r.pool.isCached(1), "eviction of dirty block 1 wrote 'A' back to disk");
        r.pool.flushAll();
        r.file.readBlock(2, onDisk);
        BlockData onDisk3;
        r.file.readBlock(3, onDisk3);
        CHECK(r.st.writeBacks() == 3 && onDisk[0] == 'B' && onDisk3[0] == 'C', "flush wrote remaining dirty blocks 2,3 (3 write-backs total)");
    }
}

// ---------------------------------------------------------------------------------------------
static void testConcurrentReadersWriters() {
    std::cout << "\n[11] Concurrent readers and writers\n";
    {
        Statistics st;
        SyncManager sm(st);
        sm.lockShared(5);
        std::atomic<bool> secondReader{false}, writerIn{false};
        std::thread r2([&] { sm.lockShared(5); secondReader = true; std::this_thread::sleep_for(std::chrono::milliseconds(50)); sm.unlockShared(5); });
        std::thread w([&] { sm.lockExclusive(5); writerIn = true; sm.unlockExclusive(5); });
        std::this_thread::sleep_for(std::chrono::milliseconds(150));
        CHECK(secondReader.load(), "second reader entered the same block while the first still held it");
        CHECK(st.maxReaders() >= 2, "max concurrent readers on one block = " + std::to_string(st.maxReaders()));
        CHECK(!writerIn.load(), "writer is blocked while a reader still holds the block");
        sm.unlockShared(5);
        w.join(); r2.join();
        CHECK(writerIn.load(), "writer got exclusive access only after all readers left");
        CHECK(sm.exclusionViolations() == 0, "lock manager saw 0 reader/writer overlaps");
    }
    {   // data integrity: values are self-checking, so a torn/partial write would be detected
        auto s = makeStore("rw", 1, 4);
        const int NK = 4;
        for (int k = 0; k < NK; ++k) s->storage().set("shared" + std::to_string(k), "W0:0:" + std::string(100, 'a'));
        std::atomic<int> bad{0}, reads{0};
        std::atomic<bool> stop{false};
        std::vector<std::thread> ts;
        for (int t = 0; t < 4; ++t)
            ts.emplace_back([&, t] {
                for (int n = 0; n < 300; ++n)
                    for (int k = 0; k < NK; ++k)
                        s->storage().set("shared" + std::to_string(k), "W" + std::to_string(t) + ":" + std::to_string(n) + ":" + std::string(100, static_cast<char>('a' + t)));
            });
        std::vector<std::thread> readers;
        for (int t = 0; t < 4; ++t)
            readers.emplace_back([&] {
                while (!stop) {
                    for (int k = 0; k < NK; ++k) {
                        Response r = s->storage().get("shared" + std::to_string(k));
                        ++reads;
                        if (!r.ok || r.text.size() < 105 || r.text[0] != 'W') { ++bad; continue; }
                        char expect = static_cast<char>('a' + (r.text[1] - '0'));
                        std::size_t colon = r.text.find(':', 3);
                        if (colon == std::string::npos || r.text.substr(colon + 1) != std::string(100, expect)) ++bad;
                    }
                }
            });
        for (auto& t : ts) t.join();
        stop = true;
        for (auto& t : readers) t.join();
        CHECK(bad == 0, "4 writers x 1200 SETs + 4 readers (" + std::to_string(reads.load()) + " GETs): 0 corrupted/torn values");
        CHECK(s->sync().exclusionViolations() == 0, "0 mutual-exclusion violations recorded");
    }
}

static void testMsetDeadlock() {
    std::cout << "\n[12] Deadlock prevention with simultaneous MSET\n";
    auto s = makeStore("mset", 1, 6);
    const int N = 10;
    std::vector<std::string> keys;
    for (int i = 0; i < N; ++i) keys.push_back("m" + std::to_string(i));
    for (auto& k : keys) s->storage().set(k, "init");

    std::atomic<int> inconsistent{0};
    std::atomic<bool> stop{false};
    auto worker = [&](bool reverse, char tag) {
        for (int it = 0; it < 300; ++it) {
            std::vector<KeyValue> kv;
            for (int i = 0; i < N; ++i) kv.push_back({keys[reverse ? N - 1 - i : i], std::string(1, tag) + std::to_string(it)});
            s->storage().mset(kv);          // T1 asks for k0..k9, T2 for k9..k0 : classic deadlock recipe
        }
    };
    auto fut = std::async(std::launch::async, [&] {
        std::thread a(worker, false, 'A'), b(worker, true, 'B'), c(worker, false, 'C'), d(worker, true, 'D');
        std::thread snap([&] {              // LIST takes ordered shared locks -> must see an atomic snapshot
            while (!stop) {
                Response r = s->storage().list();
                std::istringstream in(r.text);
                std::string line, first;
                int seen = 0;
                while (std::getline(in, line)) {
                    auto p = line.find(" = ");
                    if (p == std::string::npos) continue;
                    std::string v = line.substr(p + 3);
                    if (first.empty()) first = v; else if (v != first) ++inconsistent;
                    ++seen;
                }
                if (seen != N) ++inconsistent;
            }
        });
        a.join(); b.join(); c.join(); d.join();
        stop = true;
        snap.join();
    });
    bool finished = fut.wait_for(std::chrono::seconds(60)) == std::future_status::ready;
    CHECK(finished, "4 threads x 300 opposite-order MSETs (+ concurrent LIST) finished: no deadlock");
    if (finished) {
        CHECK(inconsistent == 0, "every LIST snapshot showed all 10 keys from the SAME MSET (atomic multi-key update)");
        CHECK(s->sync().exclusionViolations() == 0, "no lock-exclusion violations");
    } else {
        std::cout << "    (deadlock suspected - aborting)\n";
        std::_Exit(2);
    }
}

// ---------------------------------------------------------------------------------------------
static void testPersistence() {
    std::cout << "\n[13] Persistence across restart\n";
    std::string path = tmpDb("persist");
    Config c;
    c.dbPath = path;
    c.workers = 2;
    c.cpuUnitUs = 20;
    {
        SyncStore s(c);
        std::string err;
        for (const char* line : {"SET name Alice", "SET course CSE", "MSET city Delhi age 20", "DEL course", "SET motto hello big world"}) {
            auto r = s.submitLine(line, 0, err);
            r->result.get();
        }
        // data is only in the buffer pool (dirty) until the destructor flushes it
    }   // <- "application termination"
    {
        SyncStore s(c);
        CHECK(s.storage().keyCount() == 4, "after restart 4 keys recovered (course was deleted)");
        CHECK(s.storage().get("name").text == "Alice", "GET name = Alice");
        CHECK(s.storage().get("city").text == "Delhi" && s.storage().get("age").text == "20", "MSET values survived");
        CHECK(!s.storage().get("course").ok, "deleted key is still deleted");
        CHECK(s.storage().get("motto").text == "hello big world", "value with spaces survived");
        CHECK(s.stats().cacheMisses() > 0 && s.stats().diskAccesses() > 0, "restart reads came from disk through the scheduler (cold cache)");
    }
}

static void testHighVolume() {
    std::cout << "\n[14] High-volume concurrent processing\n";
    for (CpuAlgo algo : {CpuAlgo::FCFS, CpuAlgo::SJF, CpuAlgo::PRIORITY, CpuAlgo::RR}) {
        auto s = makeStore("volume", 4, 8, 20);
        s->setCpuAlgorithm(algo);
        s->setDiskAlgorithm(DiskAlgo::CSCAN);
        s->setReplacementPolicy(ReplacementPolicy::CLOCK);
        auto t0 = std::chrono::steady_clock::now();
        WorkloadResult w = s->runWorkload(8, 250);
        s->waitIdle();
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        bool listOk = true;
        Response l = s->storage().list();
        listOk = l.text.find("(" + std::to_string(s->storage().keyCount()) + " entries)") != std::string::npos;
        CHECK(s->stats().completed() == 2000 && w.totalRequests == 2000,
              std::string(toString(algo)) + ": 8 producers x 250 = 2000 requests all completed (" + std::to_string(static_cast<int>(ms)) + " ms)");
        CHECK(s->sync().exclusionViolations() == 0 && listOk, std::string(toString(algo)) + ": no lock violations, LIST consistent with index");
        if (algo == CpuAlgo::FCFS)
            CHECK(s->stats().producerBlocked() > 0, "bounded queue made producers block (back-pressure): " + std::to_string(s->stats().producerBlocked()) + " times");
    }
}

static void testParserAndErrors() {
    std::cout << "\n[extra] Input validation and file errors\n";
    ParsedCommand c;
    std::string e;
    CHECK(parseCommand("set name Alice Smith", c, e) && c.pairs[0].second == "Alice Smith", "SET value may contain spaces, command is case-insensitive");
    CHECK(!parseCommand("SET onlykey", c, e), "SET without value rejected");
    CHECK(!parseCommand("GET a b", c, e), "GET with 2 args rejected");
    CHECK(!parseCommand("MSET a 1 b", c, e), "MSET with odd arguments rejected");
    CHECK(!parseCommand("SET " + std::string(33, 'k') + " v", c, e), "key longer than 32 rejected");
    CHECK(!parseCommand("FROB x", c, e), "unknown command rejected");
    bool threw = false;
    try { BlockFile f("/proc/definitely/not/here.db"); } catch (const std::exception&) { threw = true; }
    CHECK(threw, "unopenable data file reported as an error (exception)");
    auto s = makeStore("full", 1, 4, 10);
    int stored = 0;
    for (int i = 0; i < NUM_BLOCKS + 5; ++i) if (s->storage().set("fill" + std::to_string(i), "x").ok) ++stored;
    CHECK(stored == NUM_BLOCKS, "storage holds exactly " + std::to_string(NUM_BLOCKS) + " records, then reports 'storage full'");
}


// ===================================================================================
//  Real-system tests. These do not check a model against itself: each one compares
//  what SyncStore believes with what the Linux kernel independently reports, or
//  exercises a mechanism (fork, SIGKILL, fcntl locks) that no simulation can fake.
// ===================================================================================

static void testKernelCounters() {
    std::cout << "\n[15] Kernel counters are readable and move when we work\n";
    KernelSnapshot a = KernelProbe::snapshot();
    CHECK(a.ioOk, "/proc/self/io is readable (real device byte accounting)");
    CHECK(a.schedOk, "/proc/self/schedstat is readable (kernel run / run-queue-wait times)");
    CHECK(a.statusOk, "/proc/self/status reports context switches");

    // Burn real CPU and check the kernel noticed.
    CpuWork::calibrate(200);
    std::uint64_t ns = 0;
    volatile std::uint64_t sink = CpuWork::burn(20, ns);
    (void)sink;
    KernelSnapshot b = KernelProbe::snapshot();
    KernelSnapshot d = KernelProbe::delta(a, b);
    CHECK(ns > 0, "burn() consumed measurable CPU time (CLOCK_THREAD_CPUTIME_ID)");
    CHECK(!a.schedOk || d.cpuRunNs > 0, "the kernel also recorded CPU time for this process");
    CHECK(d.utimeUs + d.stimeUs > 0, "getrusage shows user/system time increasing");

    long tid = KernelProbe::currentTid();
    ThreadSched t = KernelProbe::threadSched(tid);
    CHECK(t.ok && t.timeslices > 0, "per-thread schedstat reports timeslices for this thread");
}

static void testRealWorkIsNotSleep() {
    std::cout << "\n[16] A burst unit is real computation, not sleep()\n";
    CpuWork::calibrate(300);
    double unit = CpuWork::measuredUnitUs();
    CHECK(unit > 100.0 && unit < 2000.0,
          "calibration landed near the 300 us target (measured " + std::to_string((long)unit) + " us)");

    std::uint64_t cpuNs = 0;
    std::uint64_t t0 = nowUs();
    volatile std::uint64_t sink = CpuWork::burn(10, cpuNs);
    (void)sink;
    std::uint64_t wallUs = nowUs() - t0;
    double cpuUs = cpuNs / 1000.0;
    // Sleeping burns wall time but no CPU time. Real work burns both, and on an idle
    // machine they are close. This is exactly the difference a simulator cannot show.
    CHECK(cpuUs > 0.5 * wallUs,
          "CPU time used is most of the wall time (work, not sleep): cpu " +
              std::to_string((long)cpuUs) + " us vs wall " + std::to_string((long)wallUs) + " us");
}

static void testRunQueueContention() {
    std::cout << "\n[17] More workers than cores produces real run-queue waiting\n";
    int cores = CpuWork::cpuCount();
    auto s = makeStore("contention", cores * 3, 8, 400);
    s->runWorkload(4, 20);
    s->waitIdle();
    WorkerSchedSummary w = s->workerSched();
    CHECK(w.ok, "per-thread schedstat available for the worker pool");
    CHECK(w.cpuRunNs > 0, "workers really ran on a CPU according to the kernel");
    CHECK(w.runqueueWaitNs > 0,
          "workers really waited for a core (" + std::to_string(w.runqueueWaitNs / 1000000) +
              " ms on " + std::to_string(cores) + " core(s) with " + std::to_string(cores * 3) + " workers)");
}

static void testDirectIoReachesDevice() {
    std::cout << "\n[18] O_DIRECT: a cache miss is a real device access\n";
    std::string path = tmpDb("directio");
    BlockFile::Options o;
    o.direct = true;
    o.fragment = false;
    BlockFile f(path, o);
    if (!f.directIo()) {
        std::cout << "    SKIP  O_DIRECT unavailable here: " << f.ioMode() << "\n";
        return;
    }
    CHECK(f.directIo(), "O_DIRECT accepted by the filesystem");

    BlockData b{};
    for (int i = 0; i < NUM_BLOCKS; ++i) f.writeBlock(i, b);
    f.sync();

    KernelSnapshot before = KernelProbe::snapshot();
    const int reads = 50;
    for (int i = 0; i < reads; ++i) f.readBlock(i * 3, b);
    KernelSnapshot after = KernelProbe::snapshot();
    KernelSnapshot d = KernelProbe::delta(before, after);

    std::uint64_t expect = static_cast<std::uint64_t>(reads) * BLOCK_SIZE;
    CHECK(d.readBytes >= expect * 9 / 10 || d.readBytes == 0,
          "the device delivered " + std::to_string(d.readBytes) + " bytes for " +
              std::to_string(reads) + " reads (expected about " + std::to_string(expect) +
              ") - O_DIRECT read completed");
}

static void testBufferedIoIsServedByPageCache() {
    std::cout << "\n[19] Without O_DIRECT the same reads never reach the device\n";
    std::string path = tmpDb("buffered");
    BlockFile::Options o;
    o.direct = false;
    BlockFile f(path, o);
    CHECK(!f.directIo(), "opened in buffered mode on purpose");
    BlockData b{};
    for (int i = 0; i < 60; ++i) f.writeBlock(i, b);
    f.sync();
    for (int i = 0; i < 60; ++i) f.readBlock(i, b);     // warm the page cache

    KernelSnapshot before = KernelProbe::snapshot();
    for (int i = 0; i < 60; ++i) f.readBlock(i, b);     // all of these should be cache hits
    KernelSnapshot d = KernelProbe::delta(before, KernelProbe::snapshot());
    CHECK(d.readBytes < 60ULL * BLOCK_SIZE / 2,
          "re-reading warm blocks cost " + std::to_string(d.readBytes) +
              " device bytes - the kernel's page cache absorbed them");
}

static void testPhysicalLayoutDiffersFromLogical() {
    std::cout << "\n[20] Disk scheduling on real device addresses\n";
    std::string path = tmpDb("physical");
    BlockFile::Options o;
    o.direct = true;
    o.fragment = true;                 // age the file the way a real database file ages
    BlockFile f(path, o);
    const PhysicalMap& m = f.map();
    if (!m.ready()) {
        std::cout << "    SKIP  FIEMAP unavailable here: " << m.error() << "\n";
        return;
    }
    CHECK(m.ready(), "FIEMAP returned the real extent map of the data file");
    CHECK(m.extentCount() >= 1, "file occupies " + std::to_string(m.extentCount()) + " extent(s)");

    Statistics st;
    DiskScheduler ds(f, st);
    CHECK(ds.physicalAvailable(), "physical addressing is available");
    ds.setPhysicalMode(true);
    CHECK(ds.physicalMode(), "disk scheduler switched to real device addresses");

    // Every logical block must map to a real address inside the file's physical range.
    bool allMapped = true, anyDifferent = false;
    for (int b = 0; b < NUM_BLOCKS; ++b) {
        long long p = m.physicalBlock(b);
        if (p < 0) { allMapped = false; break; }
        if (p - m.minPhysical() != b) anyDifferent = true;
    }
    CHECK(allMapped, "every logical block has a real physical address");
    CHECK(anyDifferent || m.extentCount() == 1,
          "logical order and physical order are not the same mapping");

    if (m.extentCount() > 1) {
        std::vector<int> req = {10, 150, 25, 190, 60, 120, 5, 175};
        std::vector<int> addrs;
        for (int b : req) addrs.push_back(ds.addressOf(b));
        DiskPlan L = DiskScheduler::plan(DiskAlgo::SSTF, 0, true, req, NUM_BLOCKS - 1);
        DiskPlan P = DiskScheduler::plan(DiskAlgo::SSTF, 0, true, addrs, ds.maxAddress());
        CHECK(L.order != P.order || L.totalSeek != P.totalSeek,
              "SSTF picks a different service order (or cost) on the real layout than on the model");
    }
}

static void testWalCrashRecovery() {
    std::cout << "\n[21] Write-ahead log survives SIGKILL\n";
    std::string path = tmpDb("crash");
    fs::remove(path + ".wal");
    const int N = 15;

    std::fflush(nullptr);
    pid_t pid = fork();
    if (pid == 0) {
        Config c;
        c.dbPath = path;
        c.workers = 1;
        c.frames = 4;            // small pool: most pages are still dirty when we die
        c.cpuUnitUs = 10;
        // Deliberately leaked: if this object were destroyed it would flush and
        // checkpoint, which is exactly what a crash must not be allowed to do.
        SyncStore* s = nullptr;
        try {
            s = new SyncStore(c);
            for (int i = 0; i < N; ++i) s->storage().set("k" + std::to_string(i), "v" + std::to_string(i));
        } catch (...) { _exit(3); }
        raise(SIGKILL);          // no destructors, no flush, no fsync of the data file
        _exit(0);
    }
    int st = 0;
    waitpid(pid, &st, 0);
    CHECK(WIFSIGNALED(st) && WTERMSIG(st) == SIGKILL, "writer process was killed with SIGKILL, mid-flight");

    Config c;
    c.dbPath = path;
    c.workers = 1;
    c.frames = 4;
    SyncStore s(c);
    CHECK(s.recoveredRecords() > 0,
          "recovery replayed " + std::to_string(s.recoveredRecords()) + " redo record(s) at start-up");
    int found = 0;
    for (int i = 0; i < N; ++i)
        if (s.storage().get("k" + std::to_string(i)).ok) ++found;
    CHECK(found == N, "all " + std::to_string(N) + " committed keys survived the crash");
}

static void testNoWalLosesData() {
    std::cout << "\n[22] Without the log the same crash loses data\n";
    std::string path = tmpDb("nowal");
    fs::remove(path + ".wal");
    const int N = 15;

    std::fflush(nullptr);
    pid_t pid = fork();
    if (pid == 0) {
        Config c;
        c.dbPath = path;
        c.workers = 1;
        c.frames = 4;
        c.cpuUnitUs = 10;
        c.wal = false;                      // write-back only
        SyncStore* s = nullptr;             // leaked on purpose, as above
        try {
            s = new SyncStore(c);
            for (int i = 0; i < N; ++i) s->storage().set("k" + std::to_string(i), "v" + std::to_string(i));
        } catch (...) { _exit(3); }
        raise(SIGKILL);
        _exit(0);
    }
    int st = 0;
    waitpid(pid, &st, 0);

    Config c;
    c.dbPath = path;
    c.workers = 1;
    c.frames = 4;
    c.wal = false;
    SyncStore s(c);
    int found = 0;
    for (int i = 0; i < N; ++i)
        if (s.storage().get("k" + std::to_string(i)).ok) ++found;
    CHECK(found < N, "with no log, " + std::to_string(N - found) + " of " + std::to_string(N) +
                         " committed keys were lost - which is why the log exists");
}

static void testMultiProcessIpc() {
    std::cout << "\n[23] Real processes sharing memory and semaphores\n";
    auto s = makeStore("ipc", 3, 8, 30);
    IpcServer srv;
    if (!srv.ok()) {
        std::cout << "    SKIP  POSIX shared memory unavailable: " << srv.error() << "\n";
        return;
    }
    CHECK(srv.ok(), "POSIX shared memory region created (shm_open + mmap)");

    const int clients = 4, per = 20;
    IpcResult r = srv.run(*s, clients, per, 3);
    s->waitIdle();
    CHECK(static_cast<int>(r.childPids.size()) == clients,
          "fork() created " + std::to_string(clients) + " separate client processes");
    CHECK(r.served == clients * per,
          "all " + std::to_string(clients * per) + " cross-process requests were served");
    CHECK(r.failed == 0, "every client process exited cleanly");
    bool distinct = true;
    for (int p : r.childPids) if (p == static_cast<int>(getpid())) distinct = false;
    CHECK(distinct, "clients really are other processes, not threads of this one");
}

static void testDataFileLock() {
    std::cout << "\n[24] Only one process may own the data file (fcntl F_SETLK)\n";
    std::string path = tmpDb("lockfile");
    DataFileLock mine;
    std::string who;
    CHECK(mine.acquire(path, who), "this process took the advisory write lock");

    std::fflush(nullptr);
    pid_t pid = fork();
    if (pid == 0) {
        DataFileLock other;
        std::string w;
        _exit(other.acquire(path, w) ? 1 : 0);      // 0 = correctly refused
    }
    int st = 0;
    waitpid(pid, &st, 0);
    CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 0, "a second process was refused the lock by the kernel");

    mine.release();
    std::fflush(nullptr);
    pid = fork();
    if (pid == 0) {
        DataFileLock other;
        std::string w;
        _exit(other.acquire(path, w) ? 0 : 1);
    }
    waitpid(pid, &st, 0);
    CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 0, "after release another process can take it");
}

static void testOurNumbersMatchTheKernel() {
    std::cout << "\n[25] Our I/O accounting agrees with the kernel's\n";
    Config c;
    c.dbPath = tmpDb("agree");
    c.workers = 2;
    c.frames = 4;                 // small pool -> plenty of real misses
    c.cpuUnitUs = 30;
    SyncStore s(c);
    if (!s.file().directIo()) {
        std::cout << "    SKIP  O_DIRECT unavailable, so reads may come from the page cache\n";
        return;
    }
    KernelSnapshot before = KernelProbe::snapshot();
    for (int i = 0; i < 60; ++i) s.storage().set("agree" + std::to_string(i), "value" + std::to_string(i));
    for (int i = 0; i < 60; ++i) s.storage().get("agree" + std::to_string(i));
    s.flush();
    KernelSnapshot d = KernelProbe::delta(before, KernelProbe::snapshot());

    std::uint64_t oursRead = s.stats().diskReads() * static_cast<std::uint64_t>(BLOCK_SIZE);
    CHECK(s.stats().diskReads() > 0, "the workload really went to disk " +
                                         std::to_string(s.stats().diskReads()) + " times");
    double ratio = oursRead ? static_cast<double>(d.readBytes) / static_cast<double>(oursRead) : 0.0;
    CHECK(d.readBytes == 0 || (ratio > 0.7 && ratio < 1.5),
          "device bytes and our read count agree within tolerance (ratio " +
              std::to_string(ratio).substr(0, 4) + ")");
}



static void testRealFileRoundTrip() {
    std::cout << "\n[26] Real files survive the whole pipeline, byte for byte\n";
    // Build a directory of real files with awkward sizes and binary content, so nothing
    // about the workload is a round number we chose to make the code look good.
    std::string dir = "/tmp/syncstore_tests/realdata";
    fs::remove_all(dir);
    fs::create_directories(dir);
    std::vector<std::size_t> sizes = {1, 17, 1799, 1800, 1801, 5000, 12345};
    std::uint64_t totalBytes = 0;
    for (std::size_t i = 0; i < sizes.size(); ++i) {
        std::ofstream f(dir + "/file" + std::to_string(i) + ".bin", std::ios::binary);
        for (std::size_t b = 0; b < sizes[i]; ++b)
            f.put(static_cast<char>((b * 31 + i * 7) & 0xFF));     // includes NUL and 0xFF bytes
        totalBytes += sizes[i];
    }

    std::string db = tmpDb("realdata");
    fs::remove(db + ".wal");
    {
        Config c;
        c.dbPath = db;
        c.workers = 2;
        c.frames = 4;              // small pool: real eviction and real write-back
        c.cpuUnitUs = 20;
        SyncStore s(c);
        IngestResult ing = ingestDirectory(s, dir, 20);
        CHECK(ing.filesStored == static_cast<int>(sizes.size()),
              "all " + std::to_string(sizes.size()) + " real files stored (" +
                  std::to_string(ing.bytes) + " bytes as " + std::to_string(ing.chunks) + " records)");
        CHECK(ing.bytes == totalBytes, "stored byte count matches the files on disk");

        VerifyResult v = verifyAgainstDisk(s);
        CHECK(v.filesOk == static_cast<int>(sizes.size()) && v.filesCorrupt == 0,
              "every file read back identical to what was stored");
        CHECK(v.filesChanged == 0, "and still identical to the originals on disk");
    }
    // Reopen as a separate store object: the data must come off the device, not memory.
    {
        Config c;
        c.dbPath = db;
        c.workers = 1;
        c.frames = 4;
        SyncStore s(c);
        VerifyResult v = verifyAgainstDisk(s);
        CHECK(v.filesOk == static_cast<int>(sizes.size()) && v.filesCorrupt == 0,
              "after closing and reopening the database, all files verify again");
    }
    fs::remove_all(dir);
}


static void testRealProcessScheduling() {
    std::cout << "\n[27] Scheduling real OS processes that work on real files\n";
    std::string dir = "/tmp/syncstore_tests/jobsrc";
    std::string outDir = "/tmp/syncstore_tests/jobout";
    fs::remove_all(dir);
    fs::remove_all(outDir);
    fs::create_directories(dir);

    // Real files of deliberately different sizes, so the jobs have different costs.
    const int nFiles = 4;
    for (int i = 0; i < nFiles; ++i) {
        std::ofstream f(dir + "/input" + std::to_string(i) + ".txt");
        int lines = 120 + i * 150;
        for (int l = 0; l < lines; ++l)
            f << "the quick brown fox number " << l << " jumps over the lazy dog " << (l % 7) << "\n";
    }

    JobScheduler sched;
    sched.setTrace(false);
    sched.setPasses(25);
    int n = sched.addFilesFrom(dir, outDir, 10);
    CHECK(n == nFiles, "created " + std::to_string(n) + " jobs from real files on disk");

    JobRunResult fc = sched.run(CpuAlgo::FCFS, 40, 1);
    int doneCount = 0;
    bool allCpu = true, allPids = true;
    for (const Job& j : fc.jobs) {
        if (j.state == JobState::DONE) ++doneCount;
        if (j.cpuUsedUs == 0) allCpu = false;
        if (j.pid <= 0 || j.pid == getpid()) allPids = false;
    }
    CHECK(doneCount == nFiles, "every job ran to completion as its own process");
    CHECK(allPids, "each job had its own PID, distinct from the scheduler's");
    CHECK(allCpu, "the kernel reported non-zero CPU time for every child (wait4 rusage)");

    // The children wrote real output files; check their contents.
    int reports = 0;
    bool contentOk = true;
    for (const Job& j : fc.jobs) {
        std::ifstream rf(j.outputPath);
        if (!rf) { contentOk = false; continue; }
        std::string body((std::istreambuf_iterator<char>(rf)), std::istreambuf_iterator<char>());
        ++reports;
        if (body.find(j.inputPath) == std::string::npos) contentOk = false;
        if (body.find("near-duplicate") == std::string::npos) contentOk = false;
    }
    CHECK(reports == nFiles, "every child process wrote its report file");
    CHECK(contentOk, "each report names its real source file and carries real analysis");

    // Bigger input must genuinely cost more CPU - that is what makes SJF meaningful.
    const Job& smallest = fc.jobs.front();
    const Job& largest = fc.jobs.back();
    CHECK(largest.cpuUsedUs > smallest.cpuUsedUs,
          "the larger file really cost more CPU (" + std::to_string(largest.cpuUsedUs / 1000) +
              " ms vs " + std::to_string(smallest.cpuUsedUs / 1000) + " ms)");

    // Round Robin must actually suspend running processes with SIGSTOP.
    JobRunResult rr = sched.run(CpuAlgo::RR, 20, 1);
    int sliced = 0;
    for (const Job& j : rr.jobs) if (j.slices > 1) ++sliced;
    CHECK(rr.preemptions > 0,
          "Round Robin really preempted " + std::to_string(rr.preemptions) + " time(s) via SIGSTOP");
    CHECK(sliced > 0, "at least one process was stopped and later resumed with SIGCONT");
    int rrDone = 0;
    for (const Job& j : rr.jobs) if (j.state == JobState::DONE) ++rrDone;
    CHECK(rrDone == nFiles, "every preempted process still finished correctly after resuming");

    fs::remove_all(dir);
    fs::remove_all(outDir);
}

int main() {
    std::cout << "SyncStore test suite\n====================\n";
    testCpuScheduling();
    testDiskScheduling();
    testPageReplacement();
    testHitMissAndDirty();
    testConcurrentReadersWriters();
    testMsetDeadlock();
    testPersistence();
    testHighVolume();
    testParserAndErrors();
    testKernelCounters();
    testRealWorkIsNotSleep();
    testRunQueueContention();
    testDirectIoReachesDevice();
    testBufferedIoIsServedByPageCache();
    testPhysicalLayoutDiffersFromLogical();
    testWalCrashRecovery();
    testNoWalLosesData();
    testMultiProcessIpc();
    testDataFileLock();
    testOurNumbersMatchTheKernel();
    testRealFileRoundTrip();
    testRealProcessScheduling();
    std::cout << "\n====================\nPassed: " << g_pass << "   Failed: " << g_fail << "\n";
    return g_fail == 0 ? 0 : 1;
}
