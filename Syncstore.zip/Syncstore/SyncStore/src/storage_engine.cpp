#include "storage_engine.h"
#include <algorithm>
#include <cstring>
#include <sstream>
#include <thread>

namespace {
constexpr unsigned char USED_MARK = 0xA5;

std::uint32_t fnv1a(const std::string& s) {            // simple stable hash -> preferred block
    std::uint32_t h = 2166136261u;
    for (unsigned char c : s) { h ^= c; h *= 16777619u; }
    return h;
}

// RAII helper: releases the block locks even if an exception is thrown while they are held.
class BlockLocks {
public:
    BlockLocks(SyncManager& s, std::vector<int> blocks, bool exclusive)
        : sync_(s), exclusive_(exclusive), blocks_(s.lockAll(std::move(blocks), exclusive)) {}
    ~BlockLocks() { sync_.unlockAll(blocks_, exclusive_); }
    const std::vector<int>& blocks() const { return blocks_; }
private:
    SyncManager& sync_;
    bool exclusive_;
    std::vector<int> blocks_;
};
}  // namespace

void StorageEngine::encodeRecord(const std::string& key, const std::string& value, BlockData& out) {
    out.fill(0);
    out[0] = static_cast<char>(USED_MARK);
    out[1] = static_cast<char>(key.size());
    out[2] = static_cast<char>(value.size() & 0xFF);
    out[3] = static_cast<char>((value.size() >> 8) & 0xFF);
    std::memcpy(out.data() + 4, key.data(), key.size());
    std::memcpy(out.data() + 4 + key.size(), value.data(), value.size());
}

bool StorageEngine::decodeRecord(const BlockData& in, std::string& key, std::string& value) {
    if (static_cast<unsigned char>(in[0]) != USED_MARK) return false;
    std::size_t klen = static_cast<unsigned char>(in[1]);
    std::size_t vlen = static_cast<unsigned char>(in[2]) | (static_cast<unsigned char>(in[3]) << 8);
    if (klen == 0 || klen > MAX_KEY_LEN || vlen > MAX_VALUE_LEN || 4 + klen + vlen > BLOCK_SIZE) return false;
    key.assign(in.data() + 4, klen);
    value.assign(in.data() + 4 + klen, vlen);
    return true;
}

StorageEngine::StorageEngine(BlockFile& file, BufferPool& pool, SyncManager& sync, Statistics& stats,
                             Wal* wal)
    : file_(file), pool_(pool), sync_(sync), stats_(stats), wal_(wal) {
    used_.fill(false);
    rebuildIndex();
}

// Persistence: the block file IS the database. At start-up we scan it once to rebuild the
// in-memory key -> block index and the free-block bitmap (no threads are running yet).
void StorageEngine::rebuildIndex() {
    BlockData data;
    for (int b = 0; b < NUM_BLOCKS; ++b) {
        file_.readBlock(b, data);
        std::string k, v;
        if (decodeRecord(data, k, v) && !index_.count(k)) { index_[k] = b; used_[b] = true; }
    }
}

int StorageEngine::allocateLocked(const std::string& key) {
    int start = static_cast<int>(fnv1a(key) % NUM_BLOCKS);   // key -> preferred block
    for (int i = 0; i < NUM_BLOCKS; ++i) {
        int b = (start + i) % NUM_BLOCKS;                    // linear probing on collision
        if (!used_[b]) { used_[b] = true; return b; }
    }
    return -1;
}

int StorageEngine::resolveForWrite(const std::string& key) {
    std::lock_guard<std::mutex> lk(indexMutex_);
    auto it = index_.find(key);
    if (it != index_.end()) return it->second;
    int b = allocateLocked(key);
    if (b >= 0) index_[key] = b;
    return b;
}

bool StorageEngine::ownsBlock(const std::string& key, int block) {
    std::lock_guard<std::mutex> lk(indexMutex_);
    auto it = index_.find(key);
    return it != index_.end() && it->second == block;
}

// Pattern used by SET/GET/DEL: look up the block, take the block lock, then RE-CHECK that the
// block still belongs to the key (another thread may have deleted/reallocated it meanwhile).
Response StorageEngine::set(const std::string& key, const std::string& value) {
    if (key.empty() || key.size() > MAX_KEY_LEN || value.empty() || value.size() > MAX_VALUE_LEN)
        return {false, "ERROR: invalid key/value length"};
    for (int attempt = 0; attempt < 100; ++attempt) {
        int b = resolveForWrite(key);
        if (b < 0) return {false, "ERROR: storage full (all " + std::to_string(NUM_BLOCKS) + " blocks used)"};
        BlockLocks guard(sync_, {b}, true);                   // writer: exclusive access
        if (!ownsBlock(key, b)) continue;                     // lost a race with DEL -> retry
        BlockData data;
        encodeRecord(key, value, data);
        logThenWrite(b, data);
        return {true, "OK (block " + std::to_string(b) + ")"};
    }
    return {false, "ERROR: too much contention, try again"};
}

Response StorageEngine::get(const std::string& key) {
    for (int attempt = 0; attempt < 5; ++attempt) {
        int b;
        {
            std::lock_guard<std::mutex> lk(indexMutex_);
            auto it = index_.find(key);
            if (it == index_.end()) return {false, "(not found)"};
            b = it->second;
        }
        BlockData data;
        {
            BlockLocks guard(sync_, {b}, false);              // reader: shared access, many at once
            pool_.readBlock(b, data);
        }
        std::string k, v;
        if (decodeRecord(data, k, v) && k == key) return {true, v};
        std::this_thread::yield();                            // block was just reassigned -> look again
    }
    return {false, "(not found)"};
}

Response StorageEngine::del(const std::string& key) {
    for (int attempt = 0; attempt < 5; ++attempt) {
        int b;
        {
            std::lock_guard<std::mutex> lk(indexMutex_);
            auto it = index_.find(key);
            if (it == index_.end()) return {false, "(not found)"};
            b = it->second;
        }
        BlockLocks guard(sync_, {b}, true);
        BlockData data;
        pool_.readBlock(b, data);
        std::string k, v;
        if (!decodeRecord(data, k, v) || k != key) { std::this_thread::yield(); continue; }
        BlockData freeBlock;
        freeBlock.fill(0);
        logThenWrite(b, freeBlock);                       // mark the block free on disk (via cache)
        {
            std::lock_guard<std::mutex> lk(indexMutex_);
            auto it = index_.find(key);
            if (it != index_.end() && it->second == b) { index_.erase(it); used_[b] = false; }
        }
        return {true, "DELETED (block " + std::to_string(b) + " freed)"};
    }
    return {false, "(not found)"};
}

Response StorageEngine::mset(const std::vector<KeyValue>& pairs) {
    if (pairs.empty()) return {false, "ERROR: MSET needs at least one pair"};
    std::map<std::string, std::string> latest;                // duplicate keys: last value wins
    for (auto& kv : pairs) {
        if (kv.first.empty() || kv.first.size() > MAX_KEY_LEN || kv.second.empty() || kv.second.size() > MAX_VALUE_LEN)
            return {false, "ERROR: invalid key/value length"};
        latest[kv.first] = kv.second;
    }
    std::vector<std::string> keys;
    for (auto& kv : latest) keys.push_back(kv.first);

    for (int attempt = 0; attempt < 100; ++attempt) {
        // 1. map every key to a block (allocating missing ones) - atomically under the index mutex
        std::vector<int> blocks;
        bool full = false;
        {
            std::lock_guard<std::mutex> lk(indexMutex_);
            std::vector<std::string> fresh;
            for (auto& k : keys) {
                auto it = index_.find(k);
                if (it != index_.end()) { blocks.push_back(it->second); continue; }
                int b = allocateLocked(k);
                if (b < 0) { full = true; break; }
                index_[k] = b; fresh.push_back(k); blocks.push_back(b);
            }
            if (full) for (auto& k : fresh) { used_[index_[k]] = false; index_.erase(k); }   // roll back
        }
        if (full) return {false, "ERROR: storage full"};

        // 2. lock ALL blocks in ascending block order (deadlock prevention: no circular wait)
        BlockLocks guard(sync_, blocks, true);

        // 3. validate that nothing changed while we were acquiring the locks
        bool valid = true;
        {
            std::lock_guard<std::mutex> lk(indexMutex_);
            for (std::size_t i = 0; i < keys.size(); ++i) {
                auto it = index_.find(keys[i]);
                if (it == index_.end() || it->second != blocks[i]) { valid = false; break; }
            }
        }
        if (!valid) continue;                                 // guard releases all locks; retry

        // 4. all-or-nothing update while holding every lock
        for (std::size_t i = 0; i < keys.size(); ++i) {
            BlockData data;
            encodeRecord(keys[i], latest[keys[i]], data);
            logThenWrite(blocks[i], data);
        }
        std::ostringstream o;
        o << "OK (" << keys.size() << " keys, locked blocks:";
        for (int b : guard.blocks()) o << ' ' << b;
        o << ")";
        return {true, o.str()};
    }
    return {false, "ERROR: too much contention, try again"};
}

Response StorageEngine::list() {
    std::vector<std::pair<std::string, int>> entries;
    {
        std::lock_guard<std::mutex> lk(indexMutex_);
        for (auto& kv : index_) entries.push_back(kv);
    }
    std::vector<int> blocks;
    for (auto& e : entries) blocks.push_back(e.second);

    std::ostringstream o;
    std::size_t count = 0;
    {
        BlockLocks guard(sync_, blocks, false);               // shared locks, ascending order
        for (auto& e : entries) {
            BlockData data;
            pool_.readBlock(e.second, data);
            std::string k, v;
            if (decodeRecord(data, k, v) && k == e.first) { o << k << " = " << v << "\n"; ++count; }
        }
    }
    o << "(" << count << " entries)";
    return {true, o.str()};
}

std::size_t StorageEngine::keyCount() const {
    std::lock_guard<std::mutex> lk(indexMutex_);
    return index_.size();
}

// Diagnostic view: key -> block map, plus whether each block currently sits in the buffer pool.
// Reads the cached copy if present, else the file directly (no statistics are disturbed).
std::string StorageEngine::describeStorage() {
    std::vector<std::pair<int, std::string>> byBlock;
    {
        std::lock_guard<std::mutex> lk(indexMutex_);
        for (auto& kv : index_) byBlock.push_back({kv.second, kv.first});
    }
    std::sort(byBlock.begin(), byBlock.end());
    std::ostringstream o;
    o << "File: " << file_.path() << "   (" << NUM_BLOCKS << " blocks x " << BLOCK_SIZE << " bytes = "
      << NUM_BLOCKS * BLOCK_SIZE << " bytes)\n";
    o << "Used blocks: " << byBlock.size() << " / " << NUM_BLOCKS << "\n";
    if (byBlock.empty()) { o << "(storage is empty)\n"; return o.str(); }
    o << "  block  cache   key -> value\n";
    for (auto& e : byBlock) {
        BlockData data;
        bool cached = pool_.peek(e.first, data);
        if (!cached) file_.readBlock(e.first, data);
        std::string k, v;
        bool ok = decodeRecord(data, k, v);
        char line[64];
        std::snprintf(line, sizeof line, "  %5d  %-6s ", e.first, cached ? (pool_.isDirty(e.first) ? "dirty" : "clean") : "-");
        o << line << (ok ? k + " -> " + v : e.second + " -> (not yet written)") << "\n";
    }
    return o.str();
}

// Write-ahead logging. The order matters and is the whole point:
//   1. append the after-image to the log and fdatasync it  -> the device has promised it
//   2. only then modify the page in the buffer pool        -> may reach data.db much later
// A crash between 1 and 2 is harmless: recovery replays the record.
void StorageEngine::logThenWrite(int block, const BlockData& data) {
    if (wal_ && wal_->enabled()) wal_->logWrite(block, data);
    pool_.writeBlock(block, data);
}
