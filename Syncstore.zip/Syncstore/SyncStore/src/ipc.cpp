#include "ipc.h"
#include <fcntl.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <atomic>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <random>
#include <sstream>
#include <thread>
#include <vector>
#include "common.h"
#include "syncstore.h"

namespace {
void putStr(char* dst, std::size_t cap, const std::string& s) {
    std::size_t n = s.size() < cap - 1 ? s.size() : cap - 1;
    std::memcpy(dst, s.data(), n);
    dst[n] = '\0';
}
}  // namespace

// ------------------------------------------------------------------ IpcServer

IpcServer::IpcServer() {
    shmName_ = "/syncstore." + std::to_string(::getpid());
    int fd = ::shm_open(shmName_.c_str(), O_CREAT | O_EXCL | O_RDWR, 0600);
    if (fd < 0) {
        error_ = std::string("shm_open: ") + std::strerror(errno);
        return;
    }
    if (::ftruncate(fd, sizeof(IpcRegion)) != 0) {
        error_ = std::string("ftruncate: ") + std::strerror(errno);
        ::close(fd);
        ::shm_unlink(shmName_.c_str());
        return;
    }
    void* p = ::mmap(nullptr, sizeof(IpcRegion), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    ::close(fd);
    // Unlink straight away: the mapping stays valid for us and for every child we fork,
    // and nothing is left behind in /dev/shm if we are killed.
    ::shm_unlink(shmName_.c_str());
    if (p == MAP_FAILED) {
        error_ = std::string("mmap: ") + std::strerror(errno);
        return;
    }

    region_ = static_cast<IpcRegion*>(p);
    std::memset(region_, 0, sizeof(IpcRegion));

    // pshared = 1: these semaphores work ACROSS processes, which is the whole point.
    if (::sem_init(&region_->emptySlots, 1, IPC_SLOTS) != 0 ||
        ::sem_init(&region_->fullSlots, 1, 0) != 0 ||
        ::sem_init(&region_->mutex, 1, 1) != 0) {
        error_ = std::string("sem_init(pshared): ") + std::strerror(errno);
        ::munmap(region_, sizeof(IpcRegion));
        region_ = nullptr;
        return;
    }
    for (int i = 0; i < IPC_SLOTS; ++i) {
        if (::sem_init(&region_->slots[i].done, 1, 0) != 0) {
            error_ = "sem_init(slot): " + std::string(std::strerror(errno));
            ::munmap(region_, sizeof(IpcRegion));
            region_ = nullptr;
            return;
        }
        region_->freeList[i] = i;
    }
    region_->freeTop = IPC_SLOTS;
}

IpcServer::~IpcServer() {
    if (!region_) return;
    ::sem_destroy(&region_->emptySlots);
    ::sem_destroy(&region_->fullSlots);
    ::sem_destroy(&region_->mutex);
    for (int i = 0; i < IPC_SLOTS; ++i) ::sem_destroy(&region_->slots[i].done);
    ::munmap(region_, sizeof(IpcRegion));
    region_ = nullptr;
}

// Runs in the CHILD process. It shares only the mapped region with the server.
void IpcServer::clientMain(int clientIndex, int perClient) {
    std::mt19937 rng(static_cast<unsigned>(::getpid()) * 2654435761u + clientIndex);
    const int myPid = ::getpid();

    for (int n = 0; n < perClient; ++n) {
        int pick = static_cast<int>(rng() % 100);
        std::string key = "p" + std::to_string(clientIndex) + "k" + std::to_string(rng() % 40);
        std::string cmd;
        if (pick < 45)      cmd = "SET " + key + " v" + std::to_string(rng() % 1000);
        else if (pick < 80) cmd = "GET " + key;
        else if (pick < 90) cmd = "DEL " + key;
        else if (pick < 97) cmd = "MSET " + key + "a v1 " + key + "b v2";
        else                cmd = "LIST";

        // ---- bounded-buffer produce, across processes ----
        int sv = 0;
        ::sem_getvalue(&region_->emptySlots, &sv);
        if (sv == 0) {
            ::sem_wait(&region_->mutex);
            ++region_->clientBlocked;      // we are about to block: the queue is full
            ::sem_post(&region_->mutex);
        }
        while (::sem_wait(&region_->emptySlots) != 0 && errno == EINTR) {}

        ::sem_wait(&region_->mutex);
        int slot = region_->freeList[--region_->freeTop];
        IpcSlot& s = region_->slots[slot];
        putStr(s.cmd, IPC_CMD_LEN, cmd);
        s.reply[0] = '\0';
        s.ok = 0;
        s.clientPid = myPid;
        s.submitUs = nowUs();
        region_->ring[region_->tail] = slot;
        region_->tail = (region_->tail + 1) % IPC_SLOTS;
        ++region_->count;
        ++region_->submitted;
        ::sem_post(&region_->mutex);
        ::sem_post(&region_->fullSlots);

        // ---- wait for OUR reply ----
        while (::sem_wait(&s.done) != 0 && errno == EINTR) {}

        ::sem_wait(&region_->mutex);
        region_->totalLatencyUs += (s.finishUs > s.submitUs) ? (s.finishUs - s.submitUs) : 0;
        region_->freeList[region_->freeTop++] = slot;
        ::sem_post(&region_->mutex);
        ::sem_post(&region_->emptySlots);
    }
    ::_exit(0);
}

// Runs in SERVER threads: take a request out of shared memory, push it through the normal
// SyncStore pipeline (bounded queue -> CPU scheduler -> worker -> storage), answer the slot.
void IpcServer::serveLoop(SyncStore& store) {
    while (true) {
        int sv = 0;
        ::sem_getvalue(&region_->fullSlots, &sv);
        if (sv == 0) {
            ::sem_wait(&region_->mutex);
            ++region_->serverBlocked;
            ::sem_post(&region_->mutex);
        }
        while (::sem_wait(&region_->fullSlots) != 0 && errno == EINTR) {}
        if (region_->stop) { ::sem_post(&region_->fullSlots); return; }

        ::sem_wait(&region_->mutex);
        if (region_->count == 0) { ::sem_post(&region_->mutex); continue; }
        int slot = region_->ring[region_->head];
        region_->head = (region_->head + 1) % IPC_SLOTS;
        --region_->count;
        ::sem_post(&region_->mutex);

        IpcSlot& s = region_->slots[slot];
        std::string cmd(s.cmd);
        std::string err;
        Response resp;
        RequestPtr r = store.submitLine(cmd, slot, err);
        if (!r) {
            resp.ok = false;
            resp.text = err.empty() ? "rejected" : err;
        } else {
            resp = r->result.get();
        }

        putStr(s.reply, IPC_REPLY_LEN, resp.text);
        s.ok = resp.ok ? 1 : 0;
        s.finishUs = nowUs();

        ::sem_wait(&region_->mutex);
        ++region_->served;
        ::sem_post(&region_->mutex);
        ::sem_post(&s.done);
    }
}

IpcResult IpcServer::run(SyncStore& store, int clients, int perClient, int serverThreads) {
    IpcResult res;
    res.clients = clients;
    res.requestsPerClient = perClient;
    if (!region_) {
        res.note = "shared memory unavailable: " + error_;
        return res;
    }
    if (clients < 1) clients = 1;
    if (perClient < 1) perClient = 1;
    if (serverThreads < 1) serverThreads = 1;

    region_->stop = 0;
    region_->submitted = region_->served = 0;
    region_->clientBlocked = region_->serverBlocked = 0;
    region_->totalLatencyUs = 0;

    const std::uint64_t t0 = nowUs();

    // fork() real child processes. Each gets a copy of our address space, but the mapped
    // region is MAP_SHARED so all of them see the same ring and the same semaphores.
    std::vector<pid_t> kids;
    std::fflush(nullptr);        // children must not inherit buffered output
    for (int i = 0; i < clients; ++i) {
        pid_t pid = ::fork();
        if (pid == 0) {
            clientMain(i, perClient);    // never returns
        } else if (pid > 0) {
            kids.push_back(pid);
            res.childPids.push_back(static_cast<int>(pid));
        }
    }
    if (kids.empty()) {
        res.note = std::string("fork failed: ") + std::strerror(errno);
        return res;
    }

    std::vector<std::thread> servers;
    for (int i = 0; i < serverThreads; ++i)
        servers.emplace_back([this, &store] { serveLoop(store); });

    for (pid_t p : kids) {
        int st = 0;
        ::waitpid(p, &st, 0);
        if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) ++res.failed;
    }

    region_->stop = 1;
    for (int i = 0; i < serverThreads; ++i) ::sem_post(&region_->fullSlots);
    for (auto& t : servers) t.join();

    res.elapsedMs = (nowUs() - t0) / 1000.0;
    res.served = static_cast<int>(region_->served);
    res.clientBlocked = region_->clientBlocked;
    res.serverBlocked = region_->serverBlocked;
    if (region_->served)
        res.avgLatencyMs = static_cast<double>(region_->totalLatencyUs) / region_->served / 1000.0;

    std::ostringstream o;
    o << clients << " real processes (pids " << res.childPids.front() << ".."
      << res.childPids.back() << ") talked to this one through " << sizeof(IpcRegion) / 1024
      << " KB of POSIX shared memory";
    res.note = o.str();
    return res;
}

// ------------------------------------------------------------------ DataFileLock

DataFileLock::~DataFileLock() { release(); }

bool DataFileLock::acquire(const std::string& path, std::string& holderInfo) {
    holderInfo.clear();
    const std::string lockPath = path + ".lock";
    fd_ = ::open(lockPath.c_str(), O_RDWR | O_CREAT, 0644);
    if (fd_ < 0) {
        holderInfo = std::string("cannot open lock file: ") + std::strerror(errno);
        return false;
    }
    struct flock fl {};
    fl.l_type = F_WRLCK;
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;
    if (::fcntl(fd_, F_SETLK, &fl) == 0) {
        // Record who holds it, for the next process that tries.
        if (::ftruncate(fd_, 0) == 0) {
            std::string me = std::to_string(::getpid()) + "\n";
            ssize_t ignored = ::write(fd_, me.data(), me.size());
            (void)ignored;
        }
        return true;
    }
    // Someone else has it. F_GETLK asks the kernel who.
    struct flock probe {};
    probe.l_type = F_WRLCK;
    probe.l_whence = SEEK_SET;
    if (::fcntl(fd_, F_GETLK, &probe) == 0 && probe.l_type != F_UNLCK)
        holderInfo = "process " + std::to_string(probe.l_pid);
    else
        holderInfo = "another process";
    ::close(fd_);
    fd_ = -1;
    return false;
}

void DataFileLock::release() {
    if (fd_ < 0) return;
    struct flock fl {};
    fl.l_type = F_UNLCK;
    fl.l_whence = SEEK_SET;
    ::fcntl(fd_, F_SETLK, &fl);
    ::close(fd_);
    fd_ = -1;
}
