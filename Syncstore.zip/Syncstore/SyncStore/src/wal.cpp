#include "wal.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
#include <filesystem>
#include <sstream>
#include <stdexcept>
#include <vector>
#include "kernel_probe.h"

namespace {

constexpr std::uint32_t WAL_MAGIC = 0x57414C31;   // "WAL1"
constexpr std::uint32_t REC_WRITE = 1;
constexpr std::uint32_t REC_CHECKPOINT = 2;

#pragma pack(push, 1)
struct RecHeader {
    std::uint32_t magic;
    std::uint64_t lsn;
    std::uint32_t type;
    std::int32_t block;
    std::uint32_t crc;      // of the payload
    std::uint32_t len;      // payload length
};
#pragma pack(pop)

std::uint32_t crc32(const void* data, std::size_t n) {
    static std::uint32_t table[256];
    static bool init = false;
    if (!init) {
        for (std::uint32_t i = 0; i < 256; ++i) {
            std::uint32_t c = i;
            for (int k = 0; k < 8; ++k) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
            table[i] = c;
        }
        init = true;
    }
    const auto* p = static_cast<const unsigned char*>(data);
    std::uint32_t c = 0xFFFFFFFFu;
    for (std::size_t i = 0; i < n; ++i) c = table[(c ^ p[i]) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

std::uint64_t monotonicNs() {
    struct timespec ts;
    ::clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<std::uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<std::uint64_t>(ts.tv_nsec);
}

bool writeFully(int fd, const void* buf, std::size_t n) {
    const char* p = static_cast<const char*>(buf);
    std::size_t done = 0;
    while (done < n) {
        ssize_t w = ::write(fd, p + done, n - done);
        if (w < 0) { if (errno == EINTR) continue; return false; }
        done += static_cast<std::size_t>(w);
    }
    return true;
}

}  // namespace

Wal::Wal(const std::string& path, bool enabled) : enabled_(enabled), path_(path) {
    if (enabled_) openLog();
}

Wal::~Wal() { if (fd_ >= 0) ::close(fd_); }

void Wal::openLog() {
    auto parent = std::filesystem::path(path_).parent_path();
    if (!parent.empty()) {
        std::error_code ec;
        std::filesystem::create_directories(parent, ec);
    }
    fd_ = ::open(path_.c_str(), O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd_ < 0) throw std::runtime_error("cannot open WAL '" + path_ + "': " + std::strerror(errno));
    // Continue the LSN sequence past whatever is already in the file.
    struct stat st;
    if (::fstat(fd_, &st) == 0 && st.st_size > 0)
        lsn_ = static_cast<std::uint64_t>(st.st_size / (sizeof(RecHeader) + BLOCK_SIZE)) + 1;
}

std::uint64_t Wal::logWrite(int block, const BlockData& after) {
    if (!enabled_ || fd_ < 0) return 0;

    RecHeader h;
    h.magic = WAL_MAGIC;
    h.lsn = lsn_++;
    h.type = REC_WRITE;
    h.block = block;
    h.len = BLOCK_SIZE;
    h.crc = crc32(after.data(), BLOCK_SIZE);

    std::vector<char> rec(sizeof(RecHeader) + BLOCK_SIZE);
    std::memcpy(rec.data(), &h, sizeof(RecHeader));
    std::memcpy(rec.data() + sizeof(RecHeader), after.data(), BLOCK_SIZE);

    std::lock_guard<std::mutex> lk(mtx_);
    if (!writeFully(fd_, rec.data(), rec.size()))
        throw std::runtime_error(std::string("WAL append failed: ") + std::strerror(errno));

    // The write-ahead rule. Until this returns, the device has not promised anything.
    const std::uint64_t t0 = monotonicNs();
    ::fdatasync(fd_);
    st_.fsyncNs += monotonicNs() - t0;

    ++st_.appends;
    ++st_.commits;
    st_.bytes += rec.size();
    return h.lsn;
}

void Wal::checkpoint() {
    if (!enabled_ || fd_ < 0) return;
    std::lock_guard<std::mutex> lk(mtx_);

    RecHeader h{};
    h.magic = WAL_MAGIC;
    h.lsn = lsn_++;
    h.type = REC_CHECKPOINT;
    h.block = -1;
    h.len = 0;
    h.crc = 0;
    writeFully(fd_, &h, sizeof(h));
    const std::uint64_t t0 = monotonicNs();
    ::fdatasync(fd_);
    st_.fsyncNs += monotonicNs() - t0;

    // Every page the log describes is already in the data file, so the log can be emptied.
    ::close(fd_);
    fd_ = ::open(path_.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_APPEND, 0644);
    ++st_.checkpoints;
}

WalStats Wal::stats() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return st_;
}

void Wal::resetStats() {
    std::lock_guard<std::mutex> lk(mtx_);
    std::uint64_t replayed = st_.replayed, tail = st_.truncatedTail;
    st_ = WalStats{};
    st_.replayed = replayed;
    st_.truncatedTail = tail;
}

double Wal::avgCommitUs() const {
    std::lock_guard<std::mutex> lk(mtx_);
    if (st_.commits == 0) return 0.0;
    return static_cast<double>(st_.fsyncNs) / 1000.0 / static_cast<double>(st_.commits);
}

int Wal::recover(const std::string& walPath, BlockFile& file, std::string& summary,
                 std::uint64_t* truncatedTail) {
    summary.clear();
    if (truncatedTail) *truncatedTail = 0;

    int fd = ::open(walPath.c_str(), O_RDONLY);
    if (fd < 0) { summary = "no write-ahead log found - clean start"; return 0; }

    struct stat st;
    if (::fstat(fd, &st) != 0 || st.st_size == 0) {
        ::close(fd);
        summary = "write-ahead log is empty - the last shutdown was clean";
        return 0;
    }

    const std::size_t recSize = sizeof(RecHeader) + BLOCK_SIZE;
    int applied = 0, skipped = 0;
    std::uint64_t badTail = 0;
    std::vector<char> buf(recSize);
    off_t pos = 0;

    while (pos < st.st_size) {
        RecHeader h{};
        ssize_t n = ::pread(fd, &h, sizeof(h), pos);
        if (n != static_cast<ssize_t>(sizeof(h)) || h.magic != WAL_MAGIC) {
            badTail = static_cast<std::uint64_t>(st.st_size - pos);
            break;                                   // torn tail: the crash landed mid-record
        }
        if (h.type == REC_CHECKPOINT) { pos += static_cast<off_t>(sizeof(h)); continue; }
        if (h.len != BLOCK_SIZE) { badTail = static_cast<std::uint64_t>(st.st_size - pos); break; }

        n = ::pread(fd, buf.data(), BLOCK_SIZE, pos + static_cast<off_t>(sizeof(h)));
        if (n != BLOCK_SIZE) { badTail = static_cast<std::uint64_t>(st.st_size - pos); break; }

        if (crc32(buf.data(), BLOCK_SIZE) != h.crc) { ++skipped; badTail = static_cast<std::uint64_t>(st.st_size - pos); break; }

        BlockData bd{};
        std::memcpy(bd.data(), buf.data(), BLOCK_SIZE);
        try {
            file.writeBlock(h.block, bd);            // redo: after-images are idempotent
            ++applied;
        } catch (const std::exception&) {
            ++skipped;
        }
        pos += static_cast<off_t>(recSize);
    }
    ::close(fd);
    file.sync();

    std::ostringstream o;
    if (applied || badTail || skipped) {
        o << "recovery: replayed " << applied << " redo record(s) into " << file.path();
        if (badTail) o << "; discarded " << badTail << " byte(s) of torn tail (the crash landed mid-write)";
        if (skipped) o << "; " << skipped << " record(s) failed their checksum";
        o << ". The previous run did NOT shut down cleanly.";
    } else {
        o << "write-ahead log held no outstanding work - the last shutdown was clean";
    }
    summary = o.str();
    if (truncatedTail) *truncatedTail = badTail;

    // The log has been applied; start the new run with an empty one.
    int t = ::open(walPath.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (t >= 0) { ::fsync(t); ::close(t); }
    return applied;
}
