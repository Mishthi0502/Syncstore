#include "syncstore.h"
#include <chrono>
#include <random>
#include "command_parser.h"
#include "cpu_work.h"
#include "kernel_probe.h"
#include <sstream>
#include <iomanip>

SyncStore::SyncStore(const Config& cfg) : cfg_(cfg) {
    cpu_.setQuantum(cfg_.quantum);

    // One burst unit must cost cfg_.cpuUnitUs of REAL CPU time, so measure the work kernel
    // on this machine before anything else uses it.
    if (cfg_.realWork) CpuWork::calibrate(cfg_.cpuUnitUs);

    BlockFile::Options opt;
    opt.direct = cfg_.directIo;
    opt.fragment = cfg_.fragmentNewDb;
    opt.mapPhysical = true;
    file_.reset(new BlockFile(cfg_.dbPath, opt));

    // Crash recovery happens before anything else reads the data file: the log may hold
    // committed writes that never reached data.db because the process was killed.
    walPath_ = cfg_.dbPath + ".wal";
    if (cfg_.wal) {
        recoveredRecords_ = Wal::recover(walPath_, *file_, recoveryNote_);
        if (recoveredRecords_ > 0) file_->remapPhysical();
    } else {
        recoveryNote_ = "write-ahead log disabled for this run (a crash would lose recent writes)";
    }
    wal_.reset(new Wal(walPath_, cfg_.wal));

    disk_.reset(new DiskScheduler(*file_, stats_));
    if (cfg_.physicalDisk) disk_->setPhysicalMode(true);
    pool_.reset(new BufferPool(cfg_.frames, ReplacementPolicy::LRU, *disk_, stats_));
    sync_.reset(new SyncManager(stats_));
    storage_.reset(new StorageEngine(*file_, *pool_, *sync_, stats_, wal_.get()));

    // Baseline for the kernel counters is taken AFTER the boot-time index scan, so the
    // "model vs kernel" comparison covers the workload only.
    startSnap_ = KernelProbe::snapshot();
    startWorkers();
}

SyncStore::~SyncStore() {
    try { stopWorkers(); flush(); } catch (...) {}
}

void SyncStore::startWorkers() {
    { std::lock_guard<std::mutex> lk(workerInfoMtx_); workerInfo_.clear(); }
    queue_.reset(new RequestQueue(cfg_.queueCapacity, cpu_, stats_));
    disk_->setBatchTarget(static_cast<std::size_t>(cfg_.workers));
    stats_.setWorkers(cfg_.workers);
    for (int i = 0; i < cfg_.workers; ++i) workers_.emplace_back(&SyncStore::workerLoop, this);
}

void SyncStore::stopWorkers() {
    if (!queue_) return;
    queue_->resume();
    queue_->waitUntilIdle();
    queue_->shutdown(static_cast<int>(workers_.size()));
    for (auto& t : workers_) t.join();
    workers_.clear();
}

void SyncStore::setWorkers(int n) {
    if (n < 1) n = 1;
    if (n > 64) n = 64;
    stopWorkers();
    cfg_.workers = n;
    startWorkers();
}

void SyncStore::setKernelPolicy(KernelPolicy p, int rtPriority) {
    stopWorkers();
    cfg_.kernelPolicy = p;
    cfg_.rtPriority = rtPriority;
    policyNote_.clear();
    startWorkers();
}

void SyncStore::setPinWorkers(bool on) {
    stopWorkers();
    cfg_.pinWorkers = on;
    startWorkers();
}

bool SyncStore::setPhysicalDisk(bool on) {
    queue_->waitUntilIdle();
    disk_->setPhysicalMode(on);
    cfg_.physicalDisk = disk_->physicalMode();
    return disk_->physicalMode() == on;
}

void SyncStore::setBufferFrames(std::size_t n) {
    queue_->waitUntilIdle();
    pool_->resize(n);
    cfg_.frames = pool_->frameCount();
}

void SyncStore::flush() {
    pool_->flushAll();      // every dirty page goes to data.db
    file_->sync();          // ... and the device confirms it
    if (wal_) wal_->checkpoint();   // only now may the log forget those records

    // A brand new file can be sparse, so FIEMAP has nothing to report until blocks are
    // actually allocated. Once they are, pick up the real layout.
    if (!file_->map().ready()) {
        file_->remapPhysical();
        if (cfg_.physicalDisk && file_->map().ready()) disk_->setPhysicalMode(true);
    }
}

void SyncStore::resetBaseline() {
    stats_.reset();
    startSnap_ = KernelProbe::snapshot();
    std::lock_guard<std::mutex> lk(workerInfoMtx_);
    for (WorkerInfo& wi : workerInfo_) wi.base = KernelProbe::threadSched(wi.tid);
}

RequestPtr SyncStore::makeRequest(CmdType type, std::vector<KeyValue> pairs, int producerId) const {
    auto r = std::make_shared<Request>();
    r->type = type;
    r->pairs = std::move(pairs);
    r->producerId = producerId;
    r->burst = defaultBurst(type, r->pairs.size());
    r->priority = defaultPriority(type);
    return r;
}

void SyncStore::submit(RequestPtr r) {
    r->id = nextId_++;
    r->remaining = r->burst;
    r->arrivalUs = nowUs();
    queue_->push(r);                                  // blocks (semaphore) while the queue is full
}

RequestPtr SyncStore::submitLine(const std::string& line, int producerId, std::string& error) {
    ParsedCommand cmd;
    if (!parseCommand(line, cmd, error)) return nullptr;
    if (cmd.type == CmdType::STATS || cmd.type == CmdType::FLUSH || cmd.type == CmdType::HELP) {
        error = "internal: not a storage request";
        return nullptr;
    }
    auto r = makeRequest(cmd.type, cmd.pairs, producerId);
    submit(r);
    return r;
}

Response SyncStore::runCommand(const Request& r) {
    switch (r.type) {
        case CmdType::SET:  return storage_->set(r.pairs[0].first, r.pairs[0].second);
        case CmdType::GET:  return storage_->get(r.pairs[0].first);
        case CmdType::DEL:  return storage_->del(r.pairs[0].first);
        case CmdType::MSET: return storage_->mset(r.pairs);
        case CmdType::LIST: return storage_->list();
        default:            return {false, "ERROR: not a storage command"};
    }
}

// A worker thread = one "CPU core".  Each loop iteration executes ONE time slice of ONE request:
//   1. pop() lets the CPU scheduler choose the request,
//   2. the worker "runs" it for slice units (non-preemptive: the whole burst; Round Robin: <= quantum),
//   3. if burst remains the request is preempted and goes back to the tail of the ready queue,
//   4. otherwise the real storage operation is executed and the request completes.
void SyncStore::workerLoop() {
    // Ask the kernel for the policy this run was configured with, and record the thread's
    // starting schedstat so the report can show real run-queue waiting later.
    {
        std::string err;
        if (!CpuWork::applyPolicy(cfg_.kernelPolicy, cfg_.rtPriority, 0, err) && !err.empty()) {
            std::lock_guard<std::mutex> lk(workerInfoMtx_);
            if (policyNote_.empty()) policyNote_ = err;
        }
        long tid = KernelProbe::currentTid();
        if (cfg_.pinWorkers) {
            std::lock_guard<std::mutex> lk(workerInfoMtx_);
            CpuWork::pinToCpu(static_cast<int>(workerInfo_.size()) % CpuWork::cpuCount());
        }
        WorkerInfo wi;
        wi.tid = tid;
        wi.base = KernelProbe::threadSched(tid);
        std::lock_guard<std::mutex> lk(workerInfoMtx_);
        workerInfo_.push_back(wi);
    }
    while (true) {
        RequestPtr r = queue_->pop();
        if (!r) return;

        int slice = cpu_.sliceFor(*r);
        std::uint64_t t0 = nowUs();
        if (cfg_.realWork) {
            // Genuine computation. The thread stays RUNNABLE, so it really competes for a
            // core and the kernel really has to schedule it.
            std::uint64_t cpuNs = 0;
            workSink_ ^= CpuWork::burn(slice, cpuNs);
            r->cpuNs += cpuNs;
        } else {
            std::this_thread::sleep_for(std::chrono::microseconds(static_cast<long>(slice) * cfg_.cpuUnitUs));
        }
        r->ranOnCpu = CpuWork::currentCpu();
        ++r->slices;
        r->remaining -= slice;
        r->serviceUs += nowUs() - t0;

        if (r->remaining > 0) {                       // time quantum expired -> preempt
            stats_.recordPreemption();
            stats_.log("CPU", "preempt R" + std::to_string(r->id) + " (remaining " + std::to_string(r->remaining) + ")");
            queue_->requeue(r);
            continue;
        }

        Response resp;
        t0 = nowUs();
        try {
            resp = runCommand(*r);
        } catch (const std::exception& e) {
            resp = {false, std::string("ERROR: ") + e.what()};
        }
        r->serviceUs += nowUs() - t0;
        r->finishUs = nowUs();
        r->turnaroundUs = r->finishUs - r->arrivalUs;                       // completion - arrival
        r->waitUs = r->turnaroundUs > r->serviceUs ? r->turnaroundUs - r->serviceUs : 0;   // turnaround - service
        stats_.recordCompletion(r->id, toString(r->type), r->burst, r->waitUs, r->turnaroundUs);
        queue_->complete();                           // frees the queue slot (sem_post emptySlots)
        r->promise.set_value(resp);
    }
}

WorkloadResult SyncStore::runWorkload(int producers, int perProducer) {
    WorkloadResult res;
    res.producers = producers;
    res.totalRequests = producers * perProducer;
    stats_.setProducers(producers);
    std::vector<std::vector<RequestPtr>> issued(producers);
    std::uint64_t t0 = nowUs();

    // Each producer thread = one simulated user submitting requests independently.
    std::vector<std::thread> threads;
    for (int p = 0; p < producers; ++p) {
        threads.emplace_back([this, p, perProducer, &issued] {
            std::mt19937 rng(1000 + p);                      // fixed seed -> repeatable workload
            auto key = [&] { return "key" + std::to_string(rng() % 30); };
            for (int i = 0; i < perProducer; ++i) {
                int dice = static_cast<int>(rng() % 100);
                std::string val = "val" + std::to_string(p) + "_" + std::to_string(i);
                RequestPtr r;
                if (dice < 40)      r = makeRequest(CmdType::GET, {{key(), ""}}, p + 1);
                else if (dice < 70) r = makeRequest(CmdType::SET, {{key(), val}}, p + 1);
                else if (dice < 80) r = makeRequest(CmdType::DEL, {{key(), ""}}, p + 1);
                else if (dice < 95) {                        // MSET with random key order -> overlapping lock sets
                    std::vector<KeyValue> kv;
                    int n = 2 + static_cast<int>(rng() % 3);
                    for (int j = 0; j < n; ++j) kv.push_back({key(), val});
                    r = makeRequest(CmdType::MSET, kv, p + 1);
                } else              r = makeRequest(CmdType::LIST, {}, p + 1);
                submit(r);
                issued[p].push_back(r);
            }
        });
    }
    for (auto& t : threads) t.join();
    for (auto& v : issued)
        for (auto& r : v) {
            Response resp = r->result.get();
            if (resp.ok) ++res.succeeded; else ++res.notFound;
        }
    res.elapsedMs = (nowUs() - t0) / 1000.0;
    return res;
}

std::string SyncStore::statsReport() const {
    StatsContext c;
    c.cpuAlgo = toString(cpu_.algorithm());
    c.diskAlgo = toString(disk_->algorithm());
    c.cacheAlgo = toString(pool_->policy());
    c.workers = cfg_.workers;
    c.quantum = cpu_.quantum();
    c.cpuUnitUs = cfg_.cpuUnitUs;
    c.frames = static_cast<int>(pool_->frameCount());
    c.queueCapacity = static_cast<int>(cfg_.queueCapacity);
    c.burstMode = cfg_.realWork ? "real measured CPU work" : "sleep(), i.e. modelled";
    c.addressing = disk_->addressingDescription();
    return stats_.report(c);
}
