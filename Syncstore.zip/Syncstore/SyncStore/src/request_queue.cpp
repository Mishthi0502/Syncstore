#include "request_queue.h"
#include <cerrno>
#include <sstream>

namespace {
void semWait(sem_t* s) { while (sem_wait(s) == -1 && errno == EINTR) {} }
}

RequestQueue::RequestQueue(std::size_t capacity, CpuScheduler& sched, Statistics& stats)
    : capacity_(capacity), sched_(sched), stats_(stats) {
    sem_init(&emptySlots_, 0, static_cast<unsigned>(capacity));
    sem_init(&fullSlots_, 0, 0);
}

RequestQueue::~RequestQueue() {
    sem_destroy(&emptySlots_);
    sem_destroy(&fullSlots_);
}

void RequestQueue::push(RequestPtr r) {
    if (sem_trywait(&emptySlots_) != 0) {          // queue full -> this producer must sleep
        stats_.recordProducerBlocked();
        semWait(&emptySlots_);
    }
    {
        std::lock_guard<std::mutex> lk(mtx_);
        ++outstanding_;
        ready_.push_back(std::move(r));
        stats_.recordEnqueue(ready_.size());
    }
    sem_post(&fullSlots_);
}

RequestPtr RequestQueue::pop() {
    if (sem_trywait(&fullSlots_) != 0) {           // queue empty -> this worker must sleep
        stats_.recordConsumerBlocked();
        semWait(&fullSlots_);
    }
    std::unique_lock<std::mutex> lk(mtx_);
    gateCv_.wait(lk, [&] { return !paused_ || stopping_; });
    if (ready_.empty()) return nullptr;            // woken by shutdown()

    // *** CPU SCHEDULING DECISION happens here ***
    std::size_t idx = sched_.selectNext(ready_);
    RequestPtr r = ready_[idx];
    ready_.erase(ready_.begin() + static_cast<std::ptrdiff_t>(idx));

    bool first = !r->started;
    if (first) { r->started = true; r->firstDispatchUs = nowUs(); }
    stats_.recordDispatch(r->id, first, first ? r->firstDispatchUs - r->arrivalUs : 0);
    if (stats_.trace()) {
        std::ostringstream o;
        o << "dispatch R" << r->id << " " << toString(r->type) << " (burst " << r->burst << ", remaining "
          << r->remaining << ", prio " << r->priority << ") chosen from " << ready_.size() + 1 << " ready";
        stats_.log("CPU", o.str());
    }
    return r;
}

void RequestQueue::requeue(RequestPtr r) {
    {
        std::lock_guard<std::mutex> lk(mtx_);
        ready_.push_back(std::move(r));
    }
    sem_post(&fullSlots_);
}

void RequestQueue::complete() {
    {
        std::lock_guard<std::mutex> lk(mtx_);
        --outstanding_;
        if (outstanding_ == 0) idleCv_.notify_all();
    }
    sem_post(&emptySlots_);
}

void RequestQueue::pause() {
    std::lock_guard<std::mutex> lk(mtx_);
    paused_ = true;
}

void RequestQueue::resume() {
    { std::lock_guard<std::mutex> lk(mtx_); paused_ = false; }
    gateCv_.notify_all();
}

void RequestQueue::waitUntilIdle() {
    std::unique_lock<std::mutex> lk(mtx_);
    idleCv_.wait(lk, [&] { return outstanding_ == 0; });
}

void RequestQueue::shutdown(int workers) {
    { std::lock_guard<std::mutex> lk(mtx_); stopping_ = true; }
    gateCv_.notify_all();
    for (int i = 0; i < workers; ++i) sem_post(&fullSlots_);
}

std::size_t RequestQueue::size() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return ready_.size();
}
