#include "disk_scheduler.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <numeric>
#include <sstream>
#include <stdexcept>

const char* toString(DiskAlgo a) {
    switch (a) {
        case DiskAlgo::FCFS:  return "FCFS";
        case DiskAlgo::SSTF:  return "SSTF";
        case DiskAlgo::SCAN:  return "SCAN";
        case DiskAlgo::CSCAN: return "C-SCAN";
        case DiskAlgo::LOOK:  return "LOOK";
        case DiskAlgo::CLOOK: return "C-LOOK";
    }
    return "?";
}

// ---------------------------------------------------------------------------
// The six disk-scheduling algorithms.  head = current head position, blocks = pending
// block numbers (in arrival order).  Seek distance counts every block the head crosses,
// including the trip to the disk edge (SCAN/C-SCAN) and the return jump (C-SCAN/C-LOOK).
// ---------------------------------------------------------------------------
DiskPlan DiskScheduler::plan(DiskAlgo algo, int head, bool dirUp,
                             const std::vector<int>& blocks, int maxBlock) {
    DiskPlan p;
    int pos = head;
    p.endDirectionUp = dirUp;
    auto move = [&](int to) {
        p.totalSeek += std::abs(to - pos);
        pos = to;
        p.headPath.push_back(to);
    };
    const std::size_t n = blocks.size();

    if (algo == DiskAlgo::FCFS) {                  // serve in arrival order
        for (std::size_t i = 0; i < n; ++i) { p.order.push_back(i); move(blocks[i]); }
    } else if (algo == DiskAlgo::SSTF) {           // always the closest pending block
        std::vector<bool> used(n, false);
        for (std::size_t k = 0; k < n; ++k) {
            std::size_t best = n;
            int bestDist = 0;
            for (std::size_t i = 0; i < n; ++i) {
                if (used[i]) continue;
                int d = std::abs(blocks[i] - pos);
                if (best == n || d < bestDist) { best = i; bestDist = d; }
            }
            used[best] = true;
            p.order.push_back(best);
            move(blocks[best]);
        }
    } else {                                       // SCAN, C-SCAN, LOOK, C-LOOK
        const bool circular = (algo == DiskAlgo::CSCAN || algo == DiskAlgo::CLOOK);
        const bool goesToEdge = (algo == DiskAlgo::SCAN || algo == DiskAlgo::CSCAN);
        const bool up = circular ? true : dirUp;

        std::vector<std::size_t> idx(n);
        std::iota(idx.begin(), idx.end(), 0);
        std::stable_sort(idx.begin(), idx.end(),
                         [&](std::size_t a, std::size_t b) { return blocks[a] < blocks[b]; });

        std::vector<std::size_t> first, second;    // first = ahead of the head, second = behind it
        if (up) {
            for (auto i : idx) (blocks[i] >= head ? first : second).push_back(i);   // first ascending
            if (!circular) std::reverse(second.begin(), second.end());               // sweep back downwards
        } else {
            for (auto it = idx.rbegin(); it != idx.rend(); ++it)
                (blocks[*it] <= head ? first : second).push_back(*it);               // first descending
            std::reverse(second.begin(), second.end());                              // sweep back upwards
        }

        for (auto i : first) { p.order.push_back(i); move(blocks[i]); }
        if (!second.empty()) {
            if (circular) {
                if (goesToEdge) { move(maxBlock); move(0); }   // C-SCAN: run to the end, jump to block 0
                // C-LOOK: no edge trip, the head just jumps to the lowest pending block (next loop)
            } else if (goesToEdge && !first.empty()) {
                move(up ? maxBlock : 0);                       // SCAN: touch the edge, then reverse
            }
            for (auto i : second) { p.order.push_back(i); move(blocks[i]); }
            if (!circular) p.endDirectionUp = !up;
        }
    }
    p.endHead = pos;
    return p;
}

// ---------------------------------------------------------------------------
DiskScheduler::DiskScheduler(BlockFile& file, Statistics& stats) : file_(file), stats_(stats) {
    thread_ = std::thread(&DiskScheduler::run, this);
}

DiskScheduler::~DiskScheduler() {
    {
        std::lock_guard<std::mutex> lk(mtx_);
        stop_ = true;
    }
    cvWork_.notify_all();
    thread_.join();
}

void DiskScheduler::submitAndWait(std::vector<Pending>& reqs) {
    std::unique_lock<std::mutex> lk(mtx_);
    for (auto& r : reqs) pending_.push_back(&r);
    cvWork_.notify_all();
    cvDone_.wait(lk, [&] {
        for (auto& r : reqs) if (!r.done) return false;
        return true;
    });
    for (auto& r : reqs) if (!r.error.empty()) throw std::runtime_error(r.error);
}

void DiskScheduler::readBlock(int block, BlockData& out) {
    std::vector<Pending> v(1);
    v[0].block = block; v[0].isWrite = false; v[0].readBuf = &out;
    submitAndWait(v);
}

void DiskScheduler::writeBlock(int block, const BlockData& data) {
    std::vector<Pending> v(1);
    v[0].block = block; v[0].isWrite = true; v[0].writeBuf = &data;
    submitAndWait(v);
}

void DiskScheduler::writeBlocks(const std::vector<std::pair<int, BlockData>>& items) {
    if (items.empty()) return;
    std::vector<Pending> v(items.size());
    for (std::size_t i = 0; i < items.size(); ++i) {
        v[i].block = items[i].first; v[i].isWrite = true; v[i].writeBuf = &items[i].second;
    }
    submitAndWait(v);
}

// ---- real-device addressing -------------------------------------------------------

void DiskScheduler::setPhysicalMode(bool on) {
    const PhysicalMap& m = file_.map();
    if (on && !m.ready()) { physical_ = false; return; }
    if (on) {
        physBase_ = static_cast<int>(m.minPhysical());
        physMax_ = static_cast<int>(m.maxPhysical() - m.minPhysical());
    }
    physical_ = on;
    resetHead(0);   // the head is now in a different address space
}

int DiskScheduler::addressOf(int block) const {
    if (!physical_) return block;
    long long p = file_.map().physicalBlock(block);
    if (p < 0) return block;                       // unmapped hole: fall back to logical
    long long a = p - physBase_;
    if (a < 0) a = 0;
    if (a > physMax_) a = physMax_;
    return static_cast<int>(a);
}

int DiskScheduler::maxAddress() const { return physical_ ? physMax_ : NUM_BLOCKS - 1; }

std::string DiskScheduler::addressingDescription() const {
    const PhysicalMap& m = file_.map();
    if (!physical_) {
        return m.ready() ? "logical block numbers 0.." + std::to_string(NUM_BLOCKS - 1) +
                               " (model; real layout is known but unused)"
                         : "logical block numbers 0.." + std::to_string(NUM_BLOCKS - 1) +
                               " (real layout unavailable: " + m.error() + ")";
    }
    return "real device blocks " + std::to_string(m.minPhysical()) + ".." +
           std::to_string(m.maxPhysical()) + " on /dev/" + file_.device() +
           " (" + std::to_string(m.extentCount()) + " extents, from FIEMAP)";
}

// The disk-scheduler thread: collects pending requests into a batch, orders the batch with
// the selected algorithm relative to the current head position, then performs the real I/O.
void DiskScheduler::run() {
    std::unique_lock<std::mutex> lk(mtx_);
    while (true) {
        cvWork_.wait(lk, [&] { return stop_ || !pending_.empty(); });
        if (pending_.empty()) break;               // stop_ is set and nothing left to do

        if (pending_.size() < batchTarget_)        // short batching window so concurrent requests meet
            cvWork_.wait_for(lk, std::chrono::microseconds(500),
                             [&] { return stop_ || pending_.size() >= batchTarget_; });

        std::vector<Pending*> batch;
        batch.swap(pending_);
        const DiskAlgo algo = algo_;
        const bool phys = physical_;

        std::vector<int> blocks, addrs;
        for (auto* p : batch) { blocks.push_back(p->block); addrs.push_back(addressOf(p->block)); }

        // The plan we execute, in whichever address space is active.
        DiskPlan plan = DiskScheduler::plan(algo, head_, dirUp_, addrs, maxAddress());

        // The same batch costed in the other address space, so the report can show what the
        // textbook model predicts next to what the real layout actually costs.
        long otherSeek = 0;
        if (phys) {
            otherSeek = DiskScheduler::plan(algo, 0, true, blocks, NUM_BLOCKS - 1).totalSeek;
            stats_.recordSeekModels(plan.totalSeek, otherSeek);
        } else if (file_.map().ready()) {
            std::vector<int> realAddrs;
            const PhysicalMap& m = file_.map();
            for (int b : blocks) {
                long long p = m.physicalBlock(b);
                realAddrs.push_back(static_cast<int>(p < 0 ? b : p - m.minPhysical()));
            }
            otherSeek = DiskScheduler::plan(algo, 0, true, realAddrs,
                                            static_cast<int>(m.maxPhysical() - m.minPhysical())).totalSeek;
            stats_.recordSeekModels(plan.totalSeek, otherSeek);
        }
        lk.unlock();

        if (stats_.trace()) {
            std::ostringstream o;
            o << toString(algo) << (phys ? " [real device blocks]" : " [logical blocks]")
              << ": head=" << head_.load() << " arrived[";
            for (std::size_t i = 0; i < addrs.size(); ++i) o << (i ? " " : "") << addrs[i];
            o << "] -> serve[";
            for (std::size_t i = 0; i < plan.order.size(); ++i) o << (i ? " " : "") << addrs[plan.order[i]];
            o << "] seek=" << plan.totalSeek;
            if (otherSeek) o << " (other model would cost " << otherSeek << ")";
            stats_.log("DISK", o.str());
        }

        for (std::size_t i : plan.order) {         // real I/O, in scheduled order
            Pending* p = batch[i];
            try {
                if (p->isWrite) file_.writeBlock(p->block, *p->writeBuf);
                else            file_.readBlock(p->block, *p->readBuf);
            } catch (const std::exception& e) {
                p->error = e.what();
            }
            stats_.recordDiskAccess(p->block, p->isWrite);
        }
        stats_.recordDiskBatch(batch.size(), plan.totalSeek);

        lk.lock();
        head_ = plan.endHead;
        dirUp_ = plan.endDirectionUp;
        for (auto* p : batch) p->done = true;
        cvDone_.notify_all();
    }
}
