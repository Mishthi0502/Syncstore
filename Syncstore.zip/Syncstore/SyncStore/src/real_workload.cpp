#include "real_workload.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <random>
#include <thread>
#include <atomic>
#include "kernel_probe.h"
#include "syncstore.h"

namespace fs = std::filesystem;

namespace {

std::uint32_t crc32(const void* data, std::size_t n) {
    static std::uint32_t table[256];
    static bool init = false;
    if (!init) {
        for (std::uint32_t i = 0; i < 256; ++i) {
            std::uint32_t c = i;
            for (int k = 0; k < 8; ++k) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
            table[i] = c;
        }
        init = true;
    }
    const auto* p = static_cast<const unsigned char*>(data);
    std::uint32_t c = 0xFFFFFFFFu;
    for (std::size_t i = 0; i < n; ++i) c = table[(c ^ p[i]) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

// Keys are limited to 32 characters, so a file is identified by a hash of its path.
std::string fileTag(const std::string& relPath) {
    std::uint32_t h = crc32(relPath.data(), relPath.size());
    char buf[16];
    std::snprintf(buf, sizeof buf, "f%08x", h);
    return buf;
}

std::string chunkKey(const std::string& tag, int i) { return tag + "#" + std::to_string(i); }

// Records hold text; binary bytes are escaped so a value never contains a NUL or a newline
// that the record encoder would have to care about.
std::string encodeChunk(const char* p, std::size_t n) {
    static const char* hex = "0123456789abcdef";
    std::string out;
    out.reserve(n * 2);
    for (std::size_t i = 0; i < n; ++i) {
        unsigned char c = static_cast<unsigned char>(p[i]);
        out.push_back(hex[c >> 4]);
        out.push_back(hex[c & 0xF]);
    }
    return out;
}

bool decodeChunk(const std::string& in, std::string& out) {
    if (in.size() % 2) return false;
    out.clear();
    out.reserve(in.size() / 2);
    auto nib = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        return -1;
    };
    for (std::size_t i = 0; i < in.size(); i += 2) {
        int hi = nib(in[i]), lo = nib(in[i + 1]);
        if (hi < 0 || lo < 0) return false;
        out.push_back(static_cast<char>((hi << 4) | lo));
    }
    return true;
}

// Each record holds CHUNK raw bytes, stored as 2*CHUNK hex characters.
constexpr std::size_t CHUNK = 1800;

struct ManifestEntry {
    std::string path;
    int chunks = 0;
    std::uint64_t size = 0;
    std::uint32_t crc = 0;
};

bool parseManifest(const std::string& v, ManifestEntry& e) {
    std::istringstream is(v);
    std::string chunks, size, crc;
    if (!std::getline(is, e.path, '|')) return false;
    if (!std::getline(is, chunks, '|')) return false;
    if (!std::getline(is, size, '|')) return false;
    if (!std::getline(is, crc)) return false;
    try {
        e.chunks = std::stoi(chunks);
        e.size = std::stoull(size);
        e.crc = static_cast<std::uint32_t>(std::stoul(crc));
    } catch (...) { return false; }
    return true;
}

}  // namespace

IngestResult ingestDirectory(SyncStore& store, const std::string& dir, int maxFiles) {
    IngestResult r;
    std::error_code ec;
    if (!fs::exists(dir, ec) || !fs::is_directory(dir, ec)) {
        r.note = "not a directory: " + dir;
        return r;
    }

    std::vector<std::string> files;
    for (fs::recursive_directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec), end;
         it != end && static_cast<int>(files.size()) < maxFiles * 4; it.increment(ec)) {
        if (ec) { ec.clear(); continue; }
        if (!it->is_regular_file(ec)) continue;
        auto sz = fs::file_size(it->path(), ec);
        if (ec || sz == 0 || sz > 64 * 1024) continue;        // skip empties and large blobs
        files.push_back(it->path().string());
    }
    std::sort(files.begin(), files.end());
    if (static_cast<int>(files.size()) > maxFiles) files.resize(maxFiles);
    if (files.empty()) { r.note = "no suitable files found under " + dir; return r; }

    KernelSnapshot before = KernelProbe::snapshot();
    const std::uint64_t t0 = nowUs();
    int manifestIndex = 0;

    for (const std::string& path : files) {
        std::ifstream f(path, std::ios::binary);
        if (!f) { ++r.filesSkipped; continue; }
        std::string content((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        if (content.empty()) { ++r.filesSkipped; continue; }

        const std::string tag = fileTag(path);
        const int nChunks = static_cast<int>((content.size() + CHUNK - 1) / CHUNK);

        bool failed = false;
        for (int i = 0; i < nChunks; ++i) {
            std::size_t off = static_cast<std::size_t>(i) * CHUNK;
            std::size_t len = std::min(CHUNK, content.size() - off);
            Response resp = store.storage().set(chunkKey(tag, i), encodeChunk(content.data() + off, len));
            if (!resp.ok) { failed = true; break; }        // out of blocks
            ++r.chunks;
        }
        if (failed) { ++r.filesSkipped; continue; }

        std::ostringstream m;
        m << path << "|" << nChunks << "|" << content.size() << "|" << crc32(content.data(), content.size());
        Response mr = store.storage().set("m#" + std::to_string(manifestIndex), m.str());
        if (!mr.ok) { ++r.filesSkipped; continue; }
        ++manifestIndex;

        ++r.filesStored;
        r.bytes += content.size();
    }

    store.flush();
    r.elapsedMs = (nowUs() - t0) / 1000.0;
    KernelSnapshot d = KernelProbe::delta(before, KernelProbe::snapshot());
    r.deviceWriteBytes = d.writeBytes;

    std::ostringstream note;
    note << "stored " << r.filesStored << " real file(s) as " << r.chunks << " records";
    if (r.filesSkipped) note << "; " << r.filesSkipped << " skipped (ran out of blocks)";
    r.note = note.str();
    return r;
}

VerifyResult verifyAgainstDisk(SyncStore& store) {
    VerifyResult v;
    KernelSnapshot before = KernelProbe::snapshot();
    const std::uint64_t t0 = nowUs();

    for (int idx = 0;; ++idx) {
        Response mr = store.storage().get("m#" + std::to_string(idx));
        if (!mr.ok) break;                                  // end of manifest
        ManifestEntry e;
        if (!parseManifest(mr.text, e)) { ++v.filesCorrupt; v.failures.push_back("unreadable manifest entry"); continue; }
        ++v.filesChecked;

        const std::string tag = fileTag(e.path);
        std::string rebuilt;
        rebuilt.reserve(e.size);
        bool missing = false;
        for (int i = 0; i < e.chunks; ++i) {
            Response cr = store.storage().get(chunkKey(tag, i));
            std::string bytes;
            if (!cr.ok || !decodeChunk(cr.text, bytes)) { missing = true; break; }
            rebuilt += bytes;
        }
        if (missing) { ++v.filesMissing; v.failures.push_back("missing chunks: " + e.path); continue; }

        // Compare what came out of SyncStore with the file still sitting on the filesystem.
        std::ifstream f(e.path, std::ios::binary);
        if (!f) { ++v.filesMissing; v.failures.push_back("original gone: " + e.path); continue; }
        std::string original((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());

        // Two different questions, kept apart:
        //   1. does what came out match what we put in?  (our correctness)
        //   2. does it still match the file on disk?     (has the source changed since?)
        const std::uint32_t got = crc32(rebuilt.data(), rebuilt.size());
        if (rebuilt.size() == e.size && got == e.crc) {
            ++v.filesOk;
            v.bytes += rebuilt.size();
            if (rebuilt != original) ++v.filesChanged;
        } else {
            ++v.filesCorrupt;
            std::ostringstream o;
            o << "mismatch: " << e.path << " (" << rebuilt.size() << " vs " << e.size << " bytes, crc "
              << got << " vs " << e.crc << ")";
            v.failures.push_back(o.str());
        }
    }

    v.elapsedMs = (nowUs() - t0) / 1000.0;
    KernelSnapshot d = KernelProbe::delta(before, KernelProbe::snapshot());
    v.deviceReadBytes = d.readBytes;
    return v;
}

// Collect every chunk key that is actually stored, by walking the manifest.
static std::vector<std::string> storedKeys(SyncStore& store) {
    std::vector<std::string> keys;
    for (int idx = 0;; ++idx) {
        Response mr = store.storage().get("m#" + std::to_string(idx));
        if (!mr.ok) break;
        ManifestEntry e;
        if (!parseManifest(mr.text, e)) continue;
        const std::string tag = fileTag(e.path);
        for (int i = 0; i < e.chunks; ++i) keys.push_back(chunkKey(tag, i));
    }
    return keys;
}

// A realistic read workload over the real data: several threads, and a skewed key
// distribution so a minority of records are hot. Both properties matter:
//   * re-reference is what lets LRU/FIFO/Clock differ at all - a single sequential
//     pass is all compulsory misses, so every policy scores identically;
//   * concurrency is what gives the disk scheduler batches bigger than one request,
//     so the ordering algorithms have something to reorder.
static void realReadWorkload(SyncStore& store, const std::vector<std::string>& keys,
                             int threads, int readsPerThread) {
    if (keys.empty()) return;
    std::atomic<int> ok{0};
    std::vector<std::thread> pool;
    for (int t = 0; t < threads; ++t) {
        pool.emplace_back([&, t] {
            std::mt19937 rng(1234u + static_cast<unsigned>(t));
            const std::size_t hot = std::max<std::size_t>(1, keys.size() / 5);   // 20 % hot set
            for (int i = 0; i < readsPerThread; ++i) {
                std::size_t k = (rng() % 100 < 80) ? (rng() % hot) : (rng() % keys.size());
                if (store.storage().get(keys[k]).ok) ok.fetch_add(1, std::memory_order_relaxed);
            }
        });
    }
    for (auto& th : pool) th.join();
}

std::vector<PolicyRow> comparePolicies(SyncStore& store) {
    std::vector<PolicyRow> rows;
    const ReplacementPolicy caches[] = {ReplacementPolicy::FIFO, ReplacementPolicy::LRU, ReplacementPolicy::CLOCK};
    const DiskAlgo disks[] = {DiskAlgo::FCFS, DiskAlgo::SSTF, DiskAlgo::SCAN, DiskAlgo::CLOOK};
    const std::size_t frames = store.pool().frameCount();

    const std::vector<std::string> keys = storedKeys(store);
    if (keys.empty()) return rows;
    const int threads = 4, reads = 400;

    for (ReplacementPolicy cp : caches) {
        for (DiskAlgo da : disks) {
            store.setReplacementPolicy(cp);
            store.setDiskAlgorithm(da);
            store.setBufferFrames(frames);   // flushes and rebuilds: every run starts cold
            store.resetBaseline();

            const std::uint64_t t0 = nowUs();
            realReadWorkload(store, keys, threads, reads);
            const double ms = (nowUs() - t0) / 1000.0;

            KernelSnapshot d = KernelProbe::delta(store.startSnapshot(), KernelProbe::snapshot());

            PolicyRow row;
            row.cacheAlgo = toString(cp);
            row.diskAlgo = toString(da);
            row.elapsedMs = ms;
            row.deviceReadBytes = d.readBytes;
            row.cacheHits = store.stats().cacheHits();
            row.cacheMisses = store.stats().cacheMisses();
            row.seek = store.stats().totalSeek();
            row.ok = true;
            rows.push_back(row);
        }
    }

    // Correctness is checked once, separately, so the table measures cost not validity.
    VerifyResult v = verifyAgainstDisk(store);
    for (PolicyRow& r : rows) r.ok = (v.filesCorrupt == 0 && v.filesMissing == 0 && v.filesOk > 0);
    return rows;
}
