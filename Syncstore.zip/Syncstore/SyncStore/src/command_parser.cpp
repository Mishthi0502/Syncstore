#include "command_parser.h"
#include <cctype>
#include "common.h"

namespace {
std::string nextToken(const std::string& s, std::size_t& pos) {
    while (pos < s.size() && std::isspace(static_cast<unsigned char>(s[pos]))) ++pos;
    std::size_t start = pos;
    while (pos < s.size() && !std::isspace(static_cast<unsigned char>(s[pos]))) ++pos;
    return s.substr(start, pos - start);
}
std::string restOfLine(const std::string& s, std::size_t pos) {
    while (pos < s.size() && std::isspace(static_cast<unsigned char>(s[pos]))) ++pos;
    std::string r = s.substr(pos);
    while (!r.empty() && std::isspace(static_cast<unsigned char>(r.back()))) r.pop_back();
    return r;
}
bool checkKey(const std::string& k, std::string& err) {
    if (k.empty()) { err = "missing key"; return false; }
    if (k.size() > MAX_KEY_LEN) { err = "key too long (max " + std::to_string(MAX_KEY_LEN) + " chars)"; return false; }
    return true;
}
bool checkValue(const std::string& v, std::string& err) {
    if (v.empty()) { err = "missing value"; return false; }
    if (v.size() > MAX_VALUE_LEN) { err = "value too long (max " + std::to_string(MAX_VALUE_LEN) + " chars)"; return false; }
    return true;
}
}  // namespace

bool parseCommand(const std::string& line, ParsedCommand& out, std::string& error) {
    out = ParsedCommand();
    std::size_t pos = 0;
    std::string cmd = nextToken(line, pos);
    if (cmd.empty()) { error = "empty command (type HELP)"; return false; }
    for (auto& c : cmd) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));

    if (cmd == "SET") {
        std::string key = nextToken(line, pos);
        std::string value = restOfLine(line, pos);
        std::string e;
        if (!checkKey(key, e) || !checkValue(value, e)) { error = "SET: " + e + "  (usage: SET key value)"; return false; }
        out.type = CmdType::SET;
        out.pairs.push_back({key, value});
        return true;
    }
    if (cmd == "GET" || cmd == "DEL") {
        std::string key = nextToken(line, pos);
        std::string extra = nextToken(line, pos);
        std::string e;
        if (!checkKey(key, e) || !extra.empty()) {
            error = cmd + ": " + (extra.empty() ? e : "too many arguments") + "  (usage: " + cmd + " key)";
            return false;
        }
        out.type = (cmd == "GET") ? CmdType::GET : CmdType::DEL;
        out.pairs.push_back({key, ""});
        return true;
    }
    if (cmd == "MSET") {
        std::vector<std::string> tok;
        for (std::string t = nextToken(line, pos); !t.empty(); t = nextToken(line, pos)) tok.push_back(t);
        if (tok.empty() || tok.size() % 2 != 0) { error = "MSET: need key/value pairs  (usage: MSET k1 v1 k2 v2 ...)"; return false; }
        for (std::size_t i = 0; i < tok.size(); i += 2) {
            std::string e;
            if (!checkKey(tok[i], e) || !checkValue(tok[i + 1], e)) { error = "MSET: " + e; return false; }
            out.pairs.push_back({tok[i], tok[i + 1]});
        }
        out.type = CmdType::MSET;
        return true;
    }
    if (cmd == "LIST" || cmd == "STATS" || cmd == "FLUSH" || cmd == "HELP") {
        if (!nextToken(line, pos).empty()) { error = cmd + " takes no arguments"; return false; }
        out.type = cmd == "LIST" ? CmdType::LIST : cmd == "STATS" ? CmdType::STATS
                 : cmd == "FLUSH" ? CmdType::FLUSH : CmdType::HELP;
        return true;
    }
    error = "unknown command '" + cmd + "' (type HELP)";
    return false;
}
