#include "cpu_scheduler.h"
#include <algorithm>

const char* toString(CpuAlgo a) {
    switch (a) {
        case CpuAlgo::FCFS:     return "FCFS";
        case CpuAlgo::SJF:      return "SJF";
        case CpuAlgo::PRIORITY: return "Priority";
        case CpuAlgo::RR:       return "Round Robin";
    }
    return "?";
}

std::size_t CpuScheduler::selectNext(const std::deque<RequestPtr>& ready) const {
    std::size_t best = 0;
    const CpuAlgo a = algo_;
    if (a == CpuAlgo::RR) return 0;               // circular FIFO: head of the ready queue
    for (std::size_t i = 1; i < ready.size(); ++i) {
        const Request& cand = *ready[i];
        const Request& cur = *ready[best];
        bool better = false;
        switch (a) {
            case CpuAlgo::FCFS:     better = cand.id < cur.id; break;
            case CpuAlgo::SJF:      better = cand.remaining < cur.remaining ||
                                             (cand.remaining == cur.remaining && cand.id < cur.id); break;
            case CpuAlgo::PRIORITY: better = cand.priority < cur.priority ||
                                             (cand.priority == cur.priority && cand.id < cur.id); break;
            default: break;
        }
        if (better) best = i;
    }
    return best;
}

int CpuScheduler::sliceFor(const Request& r) const {
    if (algo_ == CpuAlgo::RR) return std::min(quantum_.load(), r.remaining);
    return r.remaining;                            // non-preemptive: run to completion
}
