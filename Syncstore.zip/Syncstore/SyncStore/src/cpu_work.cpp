#include "cpu_work.h"
#include <sched.h>
#include <sys/resource.h>
#include <time.h>
#include <unistd.h>
#include <atomic>
#include <cerrno>
#include <cstring>
#include <sstream>
#include <vector>
#include "common.h"
#include "kernel_probe.h"

const char* toString(KernelPolicy p) {
    switch (p) {
        case KernelPolicy::OTHER: return "SCHED_OTHER (CFS)";
        case KernelPolicy::FIFO:  return "SCHED_FIFO (real-time FCFS)";
        case KernelPolicy::RR:    return "SCHED_RR (real-time round robin)";
    }
    return "?";
}

namespace {
std::atomic<std::uint64_t> g_iters{2000};
std::atomic<double> g_unitUs{0.0};

int toPosix(KernelPolicy p) {
    switch (p) {
        case KernelPolicy::FIFO: return SCHED_FIFO;
        case KernelPolicy::RR:   return SCHED_RR;
        default:                 return SCHED_OTHER;
    }
}

// The work kernel. Deliberately memory-touching and branchy, like real record handling:
// an FNV-style checksum pass over a 4 KB page plus a partial ordering pass. It must not
// be removable by the optimiser, so the result is returned and fed back in.
std::uint64_t workKernel(std::uint64_t seed, std::uint64_t iterations) {
    static thread_local std::vector<std::uint32_t> page(BLOCK_SIZE / sizeof(std::uint32_t));
    std::uint64_t h = seed | 1ULL;
    const std::size_t n = page.size();
    for (std::uint64_t it = 0; it < iterations; ++it) {
        // checksum + scatter write over the whole page (cache and TLB traffic)
        for (std::size_t i = 0; i < n; ++i) {
            h ^= page[i] + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2);
            page[i] = static_cast<std::uint32_t>(h >> 13);
        }
        // a short ordering pass over a window, as a record compaction would do
        for (std::size_t i = 1; i < 64 && i < n; ++i)
            if (page[i] < page[i - 1]) std::swap(page[i], page[i - 1]);
    }
    return h;
}
}  // namespace

void CpuWork::calibrate(int targetUsPerUnit) {
    if (targetUsPerUnit < 1) targetUsPerUnit = 1;
    std::uint64_t iters = 1;
    double perIterUs = 0.0;

    // Grow the iteration count until one run is long enough to time accurately.
    for (int attempt = 0; attempt < 24; ++attempt) {
        std::uint64_t t0 = KernelProbe::threadCpuTimeNs();
        volatile std::uint64_t sink = workKernel(0x1234, iters);
        (void)sink;
        std::uint64_t ns = KernelProbe::threadCpuTimeNs() - t0;
        if (ns > 2000000ULL) {                       // >2 ms of CPU: good enough to measure
            perIterUs = static_cast<double>(ns) / 1000.0 / static_cast<double>(iters);
            break;
        }
        iters *= 2;
    }
    if (perIterUs <= 0.0) perIterUs = 1.0;

    std::uint64_t want = static_cast<std::uint64_t>(targetUsPerUnit / perIterUs);
    if (want < 1) want = 1;
    g_iters = want;

    // Measure what one unit actually costs with that iteration count.
    std::uint64_t t0 = KernelProbe::threadCpuTimeNs();
    volatile std::uint64_t sink = workKernel(0x5678, want);
    (void)sink;
    g_unitUs = static_cast<double>(KernelProbe::threadCpuTimeNs() - t0) / 1000.0;
}

std::uint64_t CpuWork::iterationsPerUnit() { return g_iters; }
double CpuWork::measuredUnitUs() { return g_unitUs; }

std::uint64_t CpuWork::burn(int units, std::uint64_t& cpuNsOut) {
    if (units < 1) units = 1;
    std::uint64_t t0 = KernelProbe::threadCpuTimeNs();
    std::uint64_t h = workKernel(static_cast<std::uint64_t>(units) * 2654435761ULL,
                                 g_iters * static_cast<std::uint64_t>(units));
    cpuNsOut = KernelProbe::threadCpuTimeNs() - t0;
    return h;
}

bool CpuWork::policyAvailable(KernelPolicy p) {
    if (p == KernelPolicy::OTHER) return true;
    // Try it on the calling thread and put the old policy back.
    struct sched_param old {};
    int oldPolicy = ::sched_getscheduler(0);
    ::sched_getparam(0, &old);
    struct sched_param sp {};
    sp.sched_priority = ::sched_get_priority_min(toPosix(p));
    bool ok = ::sched_setscheduler(0, toPosix(p), &sp) == 0;
    if (ok) ::sched_setscheduler(0, oldPolicy < 0 ? SCHED_OTHER : oldPolicy, &old);
    return ok;
}

bool CpuWork::applyPolicy(KernelPolicy p, int rtPriority, int niceValue, std::string& err) {
    err.clear();
    if (p == KernelPolicy::OTHER) {
        struct sched_param sp {};
        sp.sched_priority = 0;
        if (::sched_setscheduler(0, SCHED_OTHER, &sp) != 0) {
            err = std::string("sched_setscheduler(SCHED_OTHER): ") + std::strerror(errno);
            return false;
        }
        if (niceValue < -20) niceValue = -20;
        if (niceValue > 19) niceValue = 19;
        errno = 0;
        // setpriority with PRIO_PROCESS on a tid sets that thread's nice value on Linux.
        if (::setpriority(PRIO_PROCESS, static_cast<id_t>(KernelProbe::currentTid()), niceValue) != 0 && errno != 0) {
            err = std::string("setpriority: ") + std::strerror(errno);
            return false;   // lowering nice needs privileges; caller decides what to do
        }
        return true;
    }

    const int lo = ::sched_get_priority_min(toPosix(p));
    const int hi = ::sched_get_priority_max(toPosix(p));
    if (rtPriority < lo) rtPriority = lo;
    // Stay far below the top so a runaway worker can never freeze the machine; the kernel's
    // RT throttle (sched_rt_runtime_us) is the second line of defence.
    const int cap = lo + (hi - lo) / 10;
    if (rtPriority > cap) rtPriority = cap;

    struct sched_param sp {};
    sp.sched_priority = rtPriority;
    if (::sched_setscheduler(0, toPosix(p), &sp) != 0) {
        err = std::string("sched_setscheduler(") + toString(p) + "): " + std::strerror(errno) +
              " (real-time policies usually need CAP_SYS_NICE or 'sudo')";
        return false;
    }
    return true;
}

KernelPolicy CpuWork::currentPolicy() {
    switch (::sched_getscheduler(0)) {
        case SCHED_FIFO: return KernelPolicy::FIFO;
        case SCHED_RR:   return KernelPolicy::RR;
        default:         return KernelPolicy::OTHER;
    }
}

std::string CpuWork::describeCurrentPolicy() {
    std::ostringstream o;
    KernelPolicy p = currentPolicy();
    o << toString(p);
    if (p == KernelPolicy::OTHER) {
        errno = 0;
        int n = ::getpriority(PRIO_PROCESS, static_cast<id_t>(KernelProbe::currentTid()));
        if (errno == 0) o << ", nice " << n;
    } else {
        struct sched_param sp {};
        if (::sched_getparam(0, &sp) == 0) o << ", rt priority " << sp.sched_priority;
        std::uint64_t q = kernelRrQuantumNs();
        if (p == KernelPolicy::RR && q) o << ", kernel quantum " << (q / 1000) << " us";
    }
    return o.str();
}

std::uint64_t CpuWork::kernelRrQuantumNs() {
    struct timespec ts {};
    if (::sched_rr_get_interval(0, &ts) != 0) return 0;
    return static_cast<std::uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<std::uint64_t>(ts.tv_nsec);
}

int CpuWork::cpuCount() {
    long n = ::sysconf(_SC_NPROCESSORS_ONLN);
    return n < 1 ? 1 : static_cast<int>(n);
}

int CpuWork::currentCpu() { return ::sched_getcpu(); }

bool CpuWork::pinToCpu(int cpu) {
    if (cpu < 0) return unpin();
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(static_cast<unsigned>(cpu % cpuCount()), &set);
    return ::sched_setaffinity(0, sizeof(set), &set) == 0;
}

bool CpuWork::unpin() {
    cpu_set_t set;
    CPU_ZERO(&set);
    for (int i = 0; i < cpuCount(); ++i) CPU_SET(static_cast<unsigned>(i), &set);
    return ::sched_setaffinity(0, sizeof(set), &set) == 0;
}

std::string CpuWork::affinityDescription() {
    cpu_set_t set;
    CPU_ZERO(&set);
    if (::sched_getaffinity(0, sizeof(set), &set) != 0) return "unknown";
    std::ostringstream o;
    o << "cpus{";
    bool first = true;
    for (int i = 0; i < cpuCount(); ++i)
        if (CPU_ISSET(static_cast<unsigned>(i), &set)) { o << (first ? "" : ",") << i; first = false; }
    o << "}";
    return o.str();
}
