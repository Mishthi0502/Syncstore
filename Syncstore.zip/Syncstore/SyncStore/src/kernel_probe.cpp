#include "kernel_probe.h"
#include <sys/resource.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>

namespace {
std::string g_device;

// Parse "key: value" style files (/proc/self/io, /proc/self/status, /proc/meminfo).
bool readKeyed(const char* path, const char* key, std::uint64_t& out) {
    std::ifstream f(path);
    if (!f) return false;
    std::string line;
    const std::size_t klen = std::strlen(key);
    while (std::getline(f, line)) {
        if (line.compare(0, klen, key) == 0 && line.size() > klen && (line[klen] == ':')) {
            std::istringstream is(line.substr(klen + 1));
            std::uint64_t v = 0;
            if (is >> v) { out = v; return true; }
            return false;
        }
    }
    return false;
}

bool readSchedstat(const std::string& path, std::uint64_t& run, std::uint64_t& wait, std::uint64_t& slices) {
    std::ifstream f(path);
    if (!f) return false;
    return static_cast<bool>(f >> run >> wait >> slices);
}
}  // namespace

void KernelProbe::setDevice(const std::string& name) { g_device = name; }
const std::string& KernelProbe::device() { return g_device; }

long KernelProbe::currentTid() { return static_cast<long>(::syscall(SYS_gettid)); }

std::uint64_t KernelProbe::threadCpuTimeNs() {
    struct timespec ts;
    if (::clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts) != 0) return 0;
    return static_cast<std::uint64_t>(ts.tv_sec) * 1000000000ULL + static_cast<std::uint64_t>(ts.tv_nsec);
}

ThreadSched KernelProbe::threadSched(long tid) {
    ThreadSched t;
    t.ok = readSchedstat("/proc/self/task/" + std::to_string(tid) + "/schedstat",
                         t.cpuRunNs, t.runqueueWaitNs, t.timeslices);
    return t;
}

KernelSnapshot KernelProbe::snapshot() {
    KernelSnapshot s;

    // ---- /proc/self/io : the only honest source for "did this really hit the disk?" ----
    s.ioOk = readKeyed("/proc/self/io", "read_bytes", s.readBytes);
    if (s.ioOk) {
        readKeyed("/proc/self/io", "write_bytes", s.writeBytes);
        readKeyed("/proc/self/io", "rchar", s.rchar);
        readKeyed("/proc/self/io", "wchar", s.wchar);
        readKeyed("/proc/self/io", "syscr", s.syscr);
        readKeyed("/proc/self/io", "syscw", s.syscw);
    }

    // ---- /proc/self/schedstat : the kernel's own run / run-queue-wait accounting ----
    s.schedOk = readSchedstat("/proc/self/schedstat", s.cpuRunNs, s.runqueueWaitNs, s.timeslices);

    // ---- /proc/self/status : real context switches ----
    s.statusOk = readKeyed("/proc/self/status", "voluntary_ctxt_switches", s.volCtxt);
    if (s.statusOk) readKeyed("/proc/self/status", "nonvoluntary_ctxt_switches", s.nonvolCtxt);

    // ---- getrusage : page faults, CPU time ----
    struct rusage ru;
    if (::getrusage(RUSAGE_SELF, &ru) == 0) {
        s.minFaults = static_cast<std::uint64_t>(ru.ru_minflt);
        s.majFaults = static_cast<std::uint64_t>(ru.ru_majflt);
        s.utimeUs = static_cast<std::uint64_t>(ru.ru_utime.tv_sec) * 1000000ULL + ru.ru_utime.tv_usec;
        s.stimeUs = static_cast<std::uint64_t>(ru.ru_stime.tv_sec) * 1000000ULL + ru.ru_stime.tv_usec;
    }

    // ---- /proc/diskstats : what the device itself served ----
    if (!g_device.empty()) {
        std::ifstream f("/proc/diskstats");
        std::string line;
        while (std::getline(f, line)) {
            std::istringstream is(line);
            unsigned maj, min;
            std::string name;
            if (!(is >> maj >> min >> name)) continue;
            if (name != g_device) continue;
            std::uint64_t rd, rdMerged, rdSec, msRead, wr, wrMerged, wrSec, msWrite, inflight, ioTicks;
            if (is >> rd >> rdMerged >> rdSec >> msRead >> wr >> wrMerged >> wrSec >> msWrite >> inflight >> ioTicks) {
                s.devReads = rd;
                s.devWrites = wr;
                s.devSectorsRead = rdSec;
                s.devSectorsWritten = wrSec;
                s.devIoTicksMs = ioTicks;
                s.diskOk = true;
            }
            break;
        }
    }

    // ---- /proc/meminfo : real memory pressure, used by the adaptive buffer pool ----
    s.memOk = readKeyed("/proc/meminfo", "MemTotal", s.memTotalKb);
    if (s.memOk) readKeyed("/proc/meminfo", "MemAvailable", s.memAvailableKb);

    return s;
}

KernelSnapshot KernelProbe::delta(const KernelSnapshot& a, const KernelSnapshot& b) {
    KernelSnapshot d;
    d.ioOk = a.ioOk && b.ioOk;
    d.schedOk = a.schedOk && b.schedOk;
    d.statusOk = a.statusOk && b.statusOk;
    d.diskOk = a.diskOk && b.diskOk;
    d.memOk = b.memOk;
#define SUB(f) d.f = (b.f >= a.f) ? (b.f - a.f) : 0
    SUB(rchar); SUB(wchar); SUB(syscr); SUB(syscw); SUB(readBytes); SUB(writeBytes);
    SUB(cpuRunNs); SUB(runqueueWaitNs); SUB(timeslices);
    SUB(volCtxt); SUB(nonvolCtxt);
    SUB(minFaults); SUB(majFaults); SUB(utimeUs); SUB(stimeUs);
    SUB(devReads); SUB(devWrites); SUB(devSectorsRead); SUB(devSectorsWritten); SUB(devIoTicksMs);
#undef SUB
    d.memTotalKb = b.memTotalKb;
    d.memAvailableKb = b.memAvailableKb;   // levels, not deltas
    return d;
}

std::string KernelProbe::capabilityLine() {
    KernelSnapshot s = snapshot();
    std::ostringstream o;
    o << "kernel counters: io=" << (s.ioOk ? "yes" : "NO")
      << " schedstat=" << (s.schedOk ? "yes" : "NO")
      << " ctxt=" << (s.statusOk ? "yes" : "NO")
      << " diskstats=" << (s.diskOk ? ("yes (" + g_device + ")") : std::string("NO"))
      << " meminfo=" << (s.memOk ? "yes" : "NO");
    return o.str();
}
