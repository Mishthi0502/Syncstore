#include "physical_map.h"
#include <fcntl.h>
#include <linux/fiemap.h>
#include <linux/fs.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <unistd.h>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <vector>

bool PhysicalMap::build(int fd, std::uint64_t blockSize, int numBlocks) {
    ready_ = false;
    extents_.clear();
    minPhys_ = maxPhys_ = -1;

    const unsigned maxExtents = 512;
    std::size_t bytes = sizeof(struct fiemap) + maxExtents * sizeof(struct fiemap_extent);
    std::vector<char> buf(bytes, 0);
    auto* fm = reinterpret_cast<struct fiemap*>(buf.data());
    fm->fm_start = 0;
    fm->fm_length = blockSize * static_cast<std::uint64_t>(numBlocks);
    fm->fm_flags = FIEMAP_FLAG_SYNC;          // flush delayed allocation first, so the map is true
    fm->fm_extent_count = maxExtents;

    if (::ioctl(fd, FS_IOC_FIEMAP, fm) < 0) {
        error_ = std::string("FIEMAP not available: ") + std::strerror(errno);
        return false;
    }
    if (fm->fm_mapped_extents == 0) {
        error_ = "file has no mapped extents yet (nothing allocated)";
        return false;
    }

    for (unsigned i = 0; i < fm->fm_mapped_extents; ++i) {
        const struct fiemap_extent& e = fm->fm_extents[i];
        if (e.fe_flags & FIEMAP_EXTENT_UNKNOWN) continue;
        Extent x;
        x.logicalBlock = e.fe_logical / blockSize;
        x.physicalBlock = e.fe_physical / blockSize;
        x.lengthBlocks = e.fe_length / blockSize;
        if (x.lengthBlocks == 0) continue;
        extents_.push_back(x);
        long long lo = static_cast<long long>(x.physicalBlock);
        long long hi = lo + static_cast<long long>(x.lengthBlocks) - 1;
        if (minPhys_ < 0 || lo < minPhys_) minPhys_ = lo;
        if (maxPhys_ < 0 || hi > maxPhys_) maxPhys_ = hi;
    }
    if (extents_.empty()) {
        error_ = "no usable extents returned";
        return false;
    }
    ready_ = true;
    error_.clear();
    return true;
}

long long PhysicalMap::physicalBlock(int logicalBlock) const {
    if (!ready_ || logicalBlock < 0) return -1;
    const auto lb = static_cast<std::uint64_t>(logicalBlock);
    for (const Extent& e : extents_) {
        if (lb >= e.logicalBlock && lb < e.logicalBlock + e.lengthBlocks) {
            return static_cast<long long>(e.physicalBlock + (lb - e.logicalBlock));
        }
    }
    return -1;   // hole: never written, so the filesystem has not allocated it
}

int PhysicalMap::backwardJumps() const {
    int n = 0;
    for (std::size_t i = 1; i < extents_.size(); ++i)
        if (extents_[i].physicalBlock < extents_[i - 1].physicalBlock) ++n;
    return n;
}

std::uint64_t PhysicalMap::physicalSpanBlocks() const {
    if (minPhys_ < 0 || maxPhys_ < minPhys_) return 0;
    return static_cast<std::uint64_t>(maxPhys_ - minPhys_ + 1);
}

std::string PhysicalMap::deviceOfPath(const std::string& path) {
    struct stat st;
    if (::stat(path.c_str(), &st) != 0) return "";
    unsigned maj = major(st.st_dev), min = minor(st.st_dev);
    std::string sys = "/sys/dev/block/" + std::to_string(maj) + ":" + std::to_string(min) + "/uevent";
    std::ifstream f(sys);
    std::string line;
    while (std::getline(f, line)) {
        if (line.compare(0, 8, "DEVNAME=") == 0) return line.substr(8);
    }
    return "";
}

bool PhysicalMap::deviceIsRotational(const std::string& device) {
    if (device.empty()) return false;
    // A partition (vda1) keeps the queue settings on its parent disk (vda).
    std::string base = device;
    while (!base.empty() && std::isdigit(static_cast<unsigned char>(base.back()))) base.pop_back();
    for (const std::string& d : {device, base}) {
        std::ifstream f("/sys/block/" + d + "/queue/rotational");
        int v = 0;
        if (f >> v) return v != 0;
    }
    return false;
}

std::uint64_t PhysicalMap::deviceSizeSectors(const std::string& device) {
    if (device.empty()) return 0;
    std::ifstream f("/sys/block/" + device + "/size");
    std::uint64_t v = 0;
    if (f >> v) return v;
    return 0;
}

int PhysicalMap::createFragmented(const std::string& path, std::uint64_t blockSize, int numBlocks,
                                  std::string& error) {
    const std::string filler = path + ".filler";
    ::unlink(path.c_str());
    ::unlink(filler.c_str());

    int fd = ::open(path.c_str(), O_RDWR | O_CREAT, 0644);
    if (fd < 0) { error = std::string("open: ") + std::strerror(errno); return -1; }
    int ff = ::open(filler.c_str(), O_RDWR | O_CREAT, 0644);
    if (ff < 0) { ::close(fd); error = std::string("open filler: ") + std::strerror(errno); return -1; }

    void* raw = nullptr;
    const std::size_t chunkBlocks = 16;                       // 64 KB chunks at 4 KB blocks
    const std::size_t chunk = static_cast<std::size_t>(blockSize) * chunkBlocks;
    if (::posix_memalign(&raw, 4096, chunk) != 0) {
        ::close(fd); ::close(ff);
        error = "posix_memalign failed";
        return -1;
    }
    std::memset(raw, 0, chunk);

    int written = 0;
    for (int b = 0; b < numBlocks; b += static_cast<int>(chunkBlocks)) {
        std::size_t n = std::min(chunkBlocks, static_cast<std::size_t>(numBlocks - b));
        if (::pwrite(fd, raw, n * blockSize, static_cast<off_t>(b) * blockSize) < 0) break;
        ::fsync(fd);                                          // force allocation now
        // steal the next physically-adjacent space with the filler file
        for (int j = 0; j < 8; ++j)
            if (::pwrite(ff, raw, chunk, static_cast<off_t>(written++) * chunk) < 0) break;
        ::fsync(ff);
    }
    ::free(raw);
    ::close(ff);
    ::unlink(filler.c_str());

    PhysicalMap m;
    int extents = m.build(fd, blockSize, numBlocks) ? static_cast<int>(m.extentCount()) : -1;
    if (extents < 0) error = m.error();
    ::close(fd);
    return extents;
}

std::string PhysicalMap::describe(int numBlocks) const {
    std::ostringstream o;
    if (!ready_) {
        o << "  physical map : unavailable (" << error_ << ")\n"
          << "                 falling back to logical block numbers\n";
        return o.str();
    }
    o << "  extents        : " << extents_.size()
      << "   backward jumps in physical order: " << backwardJumps() << "\n"
      << "  physical range : block " << minPhys_ << " .. " << maxPhys_
      << "  (span " << physicalSpanBlocks() << " blocks for " << numBlocks << " data blocks)\n";
    std::size_t show = extents_.size() < 8 ? extents_.size() : 8;
    for (std::size_t i = 0; i < show; ++i) {
        const Extent& e = extents_[i];
        o << "    logical " << std::setw(4) << e.logicalBlock
          << " .. " << std::setw(4) << (e.logicalBlock + e.lengthBlocks - 1)
          << "  ->  physical " << e.physicalBlock
          << " .. " << (e.physicalBlock + e.lengthBlocks - 1);
        if (i && e.physicalBlock < extents_[i - 1].physicalBlock) o << "   (backwards)";
        o << "\n";
    }
    if (show < extents_.size()) o << "    ... " << (extents_.size() - show) << " more\n";
    return o.str();
}
