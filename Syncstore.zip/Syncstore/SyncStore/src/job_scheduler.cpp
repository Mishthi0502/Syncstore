#include "job_scheduler.h"
#include <signal.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>
#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <thread>
#include "common.h"
#include "cpu_work.h"
#include "kernel_probe.h"

namespace fs = std::filesystem;

const char* toString(JobState s) {
    switch (s) {
        case JobState::READY:   return "ready";
        case JobState::RUNNING: return "running";
        case JobState::STOPPED: return "stopped";
        case JobState::DONE:    return "done";
        case JobState::FAILED:  return "failed";
    }
    return "?";
}

namespace {

std::uint32_t crc32(const void* data, std::size_t n) {
    static std::uint32_t table[256];
    static bool init = false;
    if (!init) {
        for (std::uint32_t i = 0; i < 256; ++i) {
            std::uint32_t c = i;
            for (int k = 0; k < 8; ++k) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
            table[i] = c;
        }
        init = true;
    }
    const auto* p = static_cast<const unsigned char*>(data);
    std::uint32_t c = 0xFFFFFFFFu;
    for (std::size_t i = 0; i < n; ++i) c = table[(c ^ p[i]) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

bool alive(pid_t pid) { return pid > 0 && ::kill(pid, 0) == 0; }

}  // namespace

// ---------------------------------------------------------------- the real work

// Runs inside the child process. Reads a real file, analyses it and writes a real
// report next to it. The analysis is repeated `passes` times for one honest reason,
// stated in the output file itself: a single pass over a source file finishes in a few
// milliseconds, which is far too short to observe any scheduling decision. The work is
// genuine either way - repeating it only makes the job long enough to watch.
bool JobScheduler::analyseFile(const std::string& in, const std::string& out, int passes) {
    std::ifstream f(in, std::ios::binary);
    if (!f) return false;
    std::string text((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    if (text.empty()) return false;

    std::uint32_t crc = 0;
    std::map<std::string, int> freq;
    std::vector<std::string> lines;
    std::vector<std::pair<int, int>> dupes;
    std::uint64_t comparisons = 0;

    for (int p = 0; p < passes; ++p) {
        freq.clear();
        lines.clear();
        dupes.clear();
        comparisons = 0;
        crc = crc32(text.data(), text.size());

        // ---- split into lines and count words ----
        std::string cur, word;
        for (char ch : text) {
            if (ch == '\n') { lines.push_back(cur); cur.clear(); }
            else cur.push_back(ch);
            unsigned char u = static_cast<unsigned char>(ch);
            if (std::isalnum(u) || ch == '_') word.push_back(static_cast<char>(std::tolower(u)));
            else { if (word.size() > 2) ++freq[word]; word.clear(); }
        }
        if (!cur.empty()) lines.push_back(cur);
        if (word.size() > 2) ++freq[word];

        // ---- near-duplicate line detection ----
        // A real text-analysis task, and an honestly expensive one: every pair of lines is
        // compared, so the cost grows with the SQUARE of the file length. That is what makes
        // "estimate the burst from the file size" a meaningful thing for the scheduler to do,
        // and it is why big files genuinely take much longer than small ones here.
        std::vector<std::vector<std::uint32_t>> sig(lines.size());
        for (std::size_t i = 0; i < lines.size(); ++i) {
            const std::string& L = lines[i];
            if (L.size() < 3) continue;
            sig[i].reserve(L.size());
            for (std::size_t k = 0; k + 2 < L.size(); ++k) {
                std::uint32_t h = (static_cast<std::uint8_t>(L[k]) << 16) ^
                                  (static_cast<std::uint8_t>(L[k + 1]) << 8) ^
                                   static_cast<std::uint8_t>(L[k + 2]);
                sig[i].push_back(h);
            }
            std::sort(sig[i].begin(), sig[i].end());
            sig[i].erase(std::unique(sig[i].begin(), sig[i].end()), sig[i].end());
        }
        for (std::size_t i = 0; i < sig.size(); ++i) {
            if (sig[i].size() < 4) continue;
            for (std::size_t j = i + 1; j < sig.size(); ++j) {
                if (sig[j].size() < 4) continue;
                ++comparisons;
                std::size_t a = 0, b = 0, shared = 0;
                while (a < sig[i].size() && b < sig[j].size()) {
                    if (sig[i][a] == sig[j][b]) { ++shared; ++a; ++b; }
                    else if (sig[i][a] < sig[j][b]) ++a;
                    else ++b;
                }
                std::size_t uni = sig[i].size() + sig[j].size() - shared;
                if (uni && static_cast<double>(shared) / static_cast<double>(uni) > 0.72 &&
                    p == passes - 1 && dupes.size() < 12)
                    dupes.emplace_back(static_cast<int>(i) + 1, static_cast<int>(j) + 1);
            }
        }
    }

    std::vector<std::pair<std::string, int>> top(freq.begin(), freq.end());
    std::sort(top.begin(), top.end(), [](const auto& a, const auto& b) {
        if (a.second != b.second) return a.second > b.second;
        return a.first < b.first;
    });
    std::uint64_t totalWords = 0;
    for (const auto& kv : freq) totalWords += static_cast<std::uint64_t>(kv.second);

    std::error_code ec;
    fs::create_directories(fs::path(out).parent_path(), ec);
    std::ofstream o(out);
    if (!o) return false;
    o << "# SyncStore job report\n"
      << "source        : " << in << "\n"
      << "bytes         : " << text.size() << "\n"
      << "lines         : " << lines.size() << "\n"
      << "words         : " << totalWords << "\n"
      << "unique words  : " << freq.size() << "\n"
      << "crc32         : " << std::hex << crc << std::dec << "\n"
      << "line pairs    : " << comparisons << " compared for near-duplicates\n"
      << "analysed by   : pid " << ::getpid() << " on cpu " << ::sched_getcpu() << "\n"
      << "passes        : " << passes << "\n"
      << "\nnear-duplicate line pairs (>72% trigram overlap):\n";
    if (dupes.empty()) o << "  none\n";
    for (const auto& d : dupes) o << "  line " << d.first << "  ~  line " << d.second << "\n";
    o << "\ntop words:\n";
    for (std::size_t i = 0; i < top.size() && i < 15; ++i)
        o << "  " << std::setw(16) << std::left << top[i].first << top[i].second << "\n";
    o.flush();
    return static_cast<bool>(o);
}

// ---------------------------------------------------------------- job setup

int JobScheduler::addFilesFrom(const std::string& dir, const std::string& outDir, int maxJobs) {
    jobs_.clear();
    std::error_code ec;
    if (!fs::is_directory(dir, ec)) return 0;

    std::vector<fs::path> files;
    for (fs::recursive_directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec), end;
         it != end; it.increment(ec)) {
        if (ec) { ec.clear(); continue; }
        if (!it->is_regular_file(ec)) continue;
        auto sz = fs::file_size(it->path(), ec);
        if (ec || sz < 256) continue;
        files.push_back(it->path());
    }
    std::sort(files.begin(), files.end());
    if (static_cast<int>(files.size()) > maxJobs) files.resize(maxJobs);

    int id = 1;
    for (const fs::path& p : files) {
        Job j;
        j.id = id++;
        j.inputPath = p.string();
        j.name = p.filename().string();
        j.sizeBytes = fs::file_size(p, ec);
        j.outputPath = (fs::path(outDir) / (p.filename().string() + ".report")).string();

        // Burst is ESTIMATED from the file size - the only thing a scheduler can know
        // before running the job. Roughly one unit per 2 KB, clamped to a sane range.
        // Cost grows with the square of the line count, so the estimate does too.
        double kb = static_cast<double>(j.sizeBytes) / 1024.0;
        j.burst = static_cast<int>(kb * kb / 6.0) + 1;
        if (j.burst > 20) j.burst = 20;
        j.remaining = j.burst;
        // Small files are treated as interactive and given a better priority.
        j.priority = j.sizeBytes < 4096 ? 1 : (j.sizeBytes < 12288 ? 2 : 3);
        jobs_.push_back(j);
    }
    return static_cast<int>(jobs_.size());
}

// ---------------------------------------------------------------- scheduling

std::size_t JobScheduler::pickNext(const std::vector<std::size_t>& ready, CpuAlgo algo) const {
    std::size_t best = 0;
    for (std::size_t k = 1; k < ready.size(); ++k) {
        const Job& a = jobs_[ready[k]];
        const Job& b = jobs_[ready[best]];
        switch (algo) {
            case CpuAlgo::SJF:
                if (a.remaining < b.remaining || (a.remaining == b.remaining && a.id < b.id)) best = k;
                break;
            case CpuAlgo::PRIORITY:
                if (a.priority < b.priority || (a.priority == b.priority && a.id < b.id)) best = k;
                break;
            case CpuAlgo::RR:
                return 0;                       // head of queue
            case CpuAlgo::FCFS:
            default:
                if (a.id < b.id) best = k;
                break;
        }
    }
    return best;
}

void JobScheduler::startOrResume(Job& j, int /*quantumMs*/) {
    if (j.state == JobState::STOPPED) {
        ::kill(j.pid, SIGCONT);                 // the kernel really resumes it
        j.state = JobState::RUNNING;
        ++j.slices;
        if (trace_)
            std::cout << "[t=" << std::fixed << std::setprecision(2) << std::setw(6)
                      << (nowUs() - t0_) / 1e6 << "s] RESUME job " << j.id << " (" << j.name
                      << ") pid " << j.pid << "\n" << std::flush;
        return;
    }

    std::cout.flush();
    pid_t pid = ::fork();
    if (pid == 0) {
        // ---- child: a real process doing real work on a real file ----
        ::setpriority(PRIO_PROCESS, 0, (j.priority - 1) * 5);   // the kernel sees our priority
        bool ok = JobScheduler::analyseFile(j.inputPath, j.outputPath, passes_);
        ::_exit(ok ? 0 : 1);
    }
    j.pid = pid;
    j.state = pid > 0 ? JobState::RUNNING : JobState::FAILED;
    ++j.slices;
    if (j.firstRunUs == 0) j.firstRunUs = nowUs();
    if (trace_ && pid > 0)
        std::cout << "[t=" << std::fixed << std::setprecision(2) << std::setw(6)
                  << (nowUs() - t0_) / 1e6 << "s] START  job " << j.id << " (" << j.name << ", "
                  << j.sizeBytes / 1024 << " KB, burst~" << j.burst << ", prio " << j.priority
                  << ") pid " << pid << "\n" << std::flush;
}

JobRunResult JobScheduler::run(CpuAlgo algo, int quantumMs, int concurrency) {
    JobRunResult r;
    r.algo = toString(algo);
    r.quantumMs = quantumMs;
    r.concurrency = concurrency < 1 ? 1 : concurrency;
    if (jobs_.empty()) return r;

    for (Job& j : jobs_) {
        j.state = JobState::READY;
        j.pid = -1;
        j.slices = j.preemptions = 0;
        j.remaining = j.burst;
        j.firstRunUs = j.finishUs = j.cpuUsedUs = j.waitUs = j.turnaroundUs = 0;
    }

    t0_ = nowUs();
    for (Job& j : jobs_) j.arrivalUs = t0_;

    std::vector<std::size_t> ready;
    for (std::size_t i = 0; i < jobs_.size(); ++i) ready.push_back(i);
    std::vector<std::size_t> running;
    int done = 0;

    auto reap = [&](bool blocking) {
        while (true) {
            int status = 0;
            struct rusage ru {};
            pid_t pid = ::wait4(-1, &status, blocking ? 0 : WNOHANG, &ru);
            if (pid <= 0) return;
            auto it = std::find_if(running.begin(), running.end(),
                                   [&](std::size_t i) { return jobs_[i].pid == pid; });
            if (it == running.end()) continue;
            Job& j = jobs_[*it];
            j.finishUs = nowUs();
            // The kernel's own accounting of what this process consumed.
            j.cpuUsedUs = static_cast<std::uint64_t>(ru.ru_utime.tv_sec) * 1000000ULL + ru.ru_utime.tv_usec +
                          static_cast<std::uint64_t>(ru.ru_stime.tv_sec) * 1000000ULL + ru.ru_stime.tv_usec;
            j.turnaroundUs = j.finishUs - j.arrivalUs;
            j.waitUs = j.turnaroundUs > j.cpuUsedUs ? j.turnaroundUs - j.cpuUsedUs : 0;
            j.state = (WIFEXITED(status) && WEXITSTATUS(status) == 0) ? JobState::DONE : JobState::FAILED;
            if (j.state == JobState::FAILED) ++r.failed;
            if (trace_)
                std::cout << "[t=" << std::fixed << std::setprecision(2) << std::setw(6)
                          << (j.finishUs - t0_) / 1e6 << "s] DONE   job " << j.id << " (" << j.name
                          << ") pid " << pid << "  cpu " << j.cpuUsedUs / 1000.0 << " ms, "
                          << j.slices << " slice(s)\n" << std::flush;
            running.erase(it);
            ++done;
            blocking = false;
        }
    };

    while (done < static_cast<int>(jobs_.size())) {
        // Fill the available "cores".
        while (static_cast<int>(running.size()) < r.concurrency && !ready.empty()) {
            std::size_t k = pickNext(ready, algo);
            std::size_t idx = ready[k];
            ready.erase(ready.begin() + static_cast<long>(k));
            startOrResume(jobs_[idx], quantumMs);
            if (jobs_[idx].state == JobState::FAILED) { ++done; ++r.failed; continue; }
            running.push_back(idx);
        }
        if (running.empty()) break;

        if (algo == CpuAlgo::RR) {
            // Let them run for up to one quantum of real time, but stop waiting as soon as
            // everything running has finished - otherwise a short job would look like it
            // occupied a whole quantum when it did not.
            const std::uint64_t until = nowUs() + static_cast<std::uint64_t>(quantumMs) * 1000;
            while (nowUs() < until && !running.empty()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(2));
                reap(false);
            }
            for (std::size_t idx : std::vector<std::size_t>(running)) {
                Job& j = jobs_[idx];
                if (j.state != JobState::RUNNING || !alive(j.pid)) continue;
                ::kill(j.pid, SIGSTOP);         // real preemption, performed by the kernel
                j.state = JobState::STOPPED;
                ++j.preemptions;
                ++r.preemptions;
                if (j.remaining > 0) --j.remaining;
                if (trace_)
                    std::cout << "[t=" << std::fixed << std::setprecision(2) << std::setw(6)
                              << (nowUs() - t0_) / 1e6 << "s] STOP   job " << j.id << " (" << j.name
                              << ") pid " << j.pid << "  quantum expired -> back of queue\n" << std::flush;
                running.erase(std::find(running.begin(), running.end(), idx));
                ready.push_back(idx);
            }
        } else {
            reap(true);                          // non-preemptive: run to completion
        }
    }

    reap(false);
    const std::uint64_t end = nowUs();
    r.makespanMs = (end - t0_) / 1000.0;

    std::uint64_t w = 0, t = 0;
    for (const Job& j : jobs_) {
        w += j.waitUs;
        t += j.turnaroundUs;
        r.totalCpuUs += j.cpuUsedUs;
        r.totalBytes += j.sizeBytes;
    }
    r.avgWaitMs = static_cast<double>(w) / jobs_.size() / 1000.0;
    r.avgTurnaroundMs = static_cast<double>(t) / jobs_.size() / 1000.0;
    r.jobs = jobs_;
    return r;
}
