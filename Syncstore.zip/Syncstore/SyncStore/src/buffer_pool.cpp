#include "buffer_pool.h"
#include <sstream>

const char* toString(ReplacementPolicy p) {
    switch (p) {
        case ReplacementPolicy::FIFO:  return "FIFO";
        case ReplacementPolicy::LRU:   return "LRU";
        case ReplacementPolicy::CLOCK: return "Clock";
    }
    return "?";
}

BufferPool::BufferPool(std::size_t frames, ReplacementPolicy policy, DiskScheduler& disk, Statistics& stats)
    : disk_(disk), stats_(stats), policy_(policy), frames_(frames < 1 ? 1 : frames) {}

void BufferPool::setPolicy(ReplacementPolicy p) { std::lock_guard<std::mutex> lk(mtx_); policy_ = p; }
ReplacementPolicy BufferPool::policy() const { std::lock_guard<std::mutex> lk(mtx_); return policy_; }
std::size_t BufferPool::frameCount() const { std::lock_guard<std::mutex> lk(mtx_); return frames_.size(); }

void BufferPool::resize(std::size_t frames) {
    flushAll();
    std::lock_guard<std::mutex> lk(mtx_);
    frames_.assign(frames < 1 ? 1 : frames, Frame());
    table_.clear();
    clockHand_ = 0;
}

// Picks the frame to reuse.  Free frames are used first; otherwise the policy decides.
// Frames whose disk read is still in flight are never chosen.
int BufferPool::chooseVictimLocked() {
    const int n = static_cast<int>(frames_.size());
    for (int i = 0; i < n; ++i)
        if (!frames_[i].valid && !frames_[i].loading) return i;

    int victim = -1;
    switch (policy_) {
        case ReplacementPolicy::FIFO:                          // oldest loaded block
            for (int i = 0; i < n; ++i)
                if (!frames_[i].loading && (victim < 0 || frames_[i].loadSeq < frames_[victim].loadSeq)) victim = i;
            break;
        case ReplacementPolicy::LRU:                           // least recently used block
            for (int i = 0; i < n; ++i)
                if (!frames_[i].loading && (victim < 0 || frames_[i].lastUse < frames_[victim].lastUse)) victim = i;
            break;
        case ReplacementPolicy::CLOCK: {                       // second-chance: sweep the hand
            bool any = false;
            for (int i = 0; i < n; ++i) if (!frames_[i].loading) any = true;
            if (!any) return -1;
            for (int step = 0; step < 2 * n + 1; ++step) {
                int i = static_cast<int>(clockHand_);
                clockHand_ = (clockHand_ + 1) % n;
                if (frames_[i].loading) continue;
                if (frames_[i].ref) { frames_[i].ref = false; continue; }   // second chance
                victim = i;
                break;
            }
            break;
        }
    }
    return victim;
}

// Removes the block held by 'idx' from the pool; dirty blocks are written back first.
// The write goes through the disk scheduler. It is done while holding the pool lock so that
// nobody can re-read the block from disk before its newest contents have been written.
void BufferPool::evictLocked(int idx, int forBlock) {
    Frame& f = frames_[idx];
    stats_.cacheReplacement();
    std::ostringstream o;
    o << toString(policy_) << ": evict block " << f.block << (f.dirty ? " (dirty -> write-back)" : " (clean)")
      << " to make room for block " << forBlock;
    if (f.dirty) {
        disk_.writeBlock(f.block, f.data);
        stats_.cacheWriteBack();
        f.dirty = false;
    }
    stats_.cacheEvent(o.str());
    table_.erase(f.block);
    f.valid = false;
    f.block = -1;
}

void BufferPool::readBlock(int block, BlockData& out) {
    std::unique_lock<std::mutex> lk(mtx_);
    bool counted = false;                          // each call counts exactly one hit OR one miss
    while (true) {
        auto it = table_.find(block);
        if (it != table_.end()) {
            Frame& f = frames_[it->second];
            if (!counted) { stats_.cacheHit(); counted = true; }
            if (f.loading) { cv_.wait(lk); continue; }     // another thread is reading it from disk
            touch(f);
            out = f.data;
            return;
        }
        if (!counted) { stats_.cacheMiss(); counted = true; }

        int v = chooseVictimLocked();
        if (v < 0) { cv_.wait(lk); continue; }             // all frames busy loading: wait
        Frame& f = frames_[v];
        if (f.valid) evictLocked(v, block);

        f.block = block; f.valid = true; f.dirty = false; f.loading = true;
        table_[block] = v;
        lk.unlock();                                       // do NOT hold the pool lock during the disk read,
        BlockData tmp;                                     // so several workers' reads can be batched/reordered
        try {
            disk_.readBlock(block, tmp);
        } catch (...) {
            lk.lock();
            table_.erase(block); f.valid = false; f.loading = false; f.block = -1;
            cv_.notify_all();
            throw;
        }
        lk.lock();
        f.data = tmp;
        f.loading = false;
        installLocked(f, block);
        cv_.notify_all();
        out = tmp;
        return;
    }
}

void BufferPool::writeBlock(int block, const BlockData& data) {
    std::unique_lock<std::mutex> lk(mtx_);
    bool counted = false;
    while (true) {
        auto it = table_.find(block);
        if (it != table_.end()) {
            Frame& f = frames_[it->second];
            if (!counted) { stats_.cacheHit(); counted = true; }
            if (f.loading) { cv_.wait(lk); continue; }
            f.data = data;
            f.dirty = true;                                // write-back: disk is NOT touched now
            touch(f);
            return;
        }
        if (!counted) { stats_.cacheMiss(); counted = true; }

        int v = chooseVictimLocked();
        if (v < 0) { cv_.wait(lk); continue; }
        Frame& f = frames_[v];
        if (f.valid) evictLocked(v, block);
        // Whole block is overwritten, so there is nothing to read from disk (write-allocate, no fetch).
        f.data = data;
        f.dirty = true;
        f.loading = false;
        table_[block] = v;
        installLocked(f, block);
        return;
    }
}

void BufferPool::flushAll() {
    std::unique_lock<std::mutex> lk(mtx_);
    cv_.wait(lk, [&] {                                      // let in-flight loads finish first
        for (auto& f : frames_) if (f.loading) return false;
        return true;
    });
    std::vector<std::pair<int, BlockData>> dirty;
    for (auto& f : frames_)
        if (f.valid && f.dirty) dirty.push_back({f.block, f.data});
    if (!dirty.empty()) {
        disk_.writeBlocks(dirty);                           // one batch -> the disk scheduler reorders it
        for (auto& f : frames_)
            if (f.valid && f.dirty) { f.dirty = false; stats_.cacheWriteBack(); }
        stats_.cacheEvent("flush: " + std::to_string(dirty.size()) + " dirty block(s) written back");
    }
    disk_.syncFile();
}

bool BufferPool::isCached(int block) const {
    std::lock_guard<std::mutex> lk(mtx_);
    auto it = table_.find(block);
    return it != table_.end() && !frames_[it->second].loading;
}

bool BufferPool::isDirty(int block) const {
    std::lock_guard<std::mutex> lk(mtx_);
    auto it = table_.find(block);
    return it != table_.end() && frames_[it->second].dirty;
}

bool BufferPool::peek(int block, BlockData& out) const {
    std::lock_guard<std::mutex> lk(mtx_);
    auto it = table_.find(block);
    if (it == table_.end() || frames_[it->second].loading) return false;
    out = frames_[it->second].data;
    return true;
}

std::vector<int> BufferPool::cachedBlocks() const {
    std::lock_guard<std::mutex> lk(mtx_);
    std::vector<int> r;
    for (auto& f : frames_) if (f.valid && !f.loading) r.push_back(f.block);
    return r;
}
