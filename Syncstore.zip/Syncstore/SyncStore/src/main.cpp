// main.cpp - terminal front end for SyncStore.
// Local program only: no sockets, no TCP/UDP, no HTTP. "Users" are either worker threads
// or, in multi-process mode, real forked processes talking through POSIX shared memory.
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include "command_parser.h"
#include "cpu_work.h"
#include "ipc.h"
#include "real_workload.h"
#include "job_scheduler.h"
#include "syncstore.h"

namespace {

bool readLine(const std::string& prompt, std::string& out) {
    std::cout << prompt << std::flush;
    if (!std::getline(std::cin, out)) return false;           // EOF -> caller exits
    while (!out.empty() && (out.back() == '\r' || out.back() == ' ')) out.pop_back();
    return true;
}

// Reads an integer in [lo, hi]; empty input keeps 'def'. Returns false on EOF.
bool askInt(const std::string& prompt, int def, int lo, int hi, int& value) {
    while (true) {
        std::string s;
        if (!readLine(prompt, s)) return false;
        if (s.empty()) { value = def; return true; }
        try {
            std::size_t used = 0;
            int v = std::stoi(s, &used);
            if (used == s.size() && v >= lo && v <= hi) { value = v; return true; }
        } catch (...) {}
        std::cout << "  Please enter a number between " << lo << " and " << hi << ".\n";
    }
}

void printBanner() {
    std::cout << "\n========================================\n"
                 "             SYNCSTORE\n"
                 "     OS POWERED KEY-VALUE STORE\n"
                 "========================================\n";
}

void printMenu(SyncStore& s) {
    printBanner();
    std::cout << " CPU: " << toString(s.cpu().algorithm())
              << " | Disk: " << toString(s.disk().algorithm())
              << (s.disk().physicalMode() ? " (real device blocks)" : " (logical model)")
              << " | Cache: " << toString(s.pool().policy())
              << " (" << s.pool().frameCount() << " frames)"
              << " | Workers: " << s.config().workers << "\n\n"
                 " 1. Execute Command\n"
                 " 2. Select CPU Scheduling Algorithm\n"
                 " 3. Select Disk Scheduling Algorithm\n"
                 " 4. Select Page Replacement Algorithm\n"
                 " 5. Run Concurrent Workload (threads)\n"
                 " 6. Run Multi-Process Workload (fork + POSIX shared memory)\n"
                 " 7. View System Statistics\n"
                 " 8. Reality Check (what is real + our numbers vs the kernel's)\n"
                 " 9. Crash Recovery Demo (kill -9 while data is still in memory)\n"
                 "10. Compare Disk Algorithms (logical model vs real device layout)\n"
                 "11. Schedule Real Processes on Real Files (fork + SIGSTOP/SIGCONT)\n"
                 "12. Configuration\n"
                 "13. Exit\n\n";
}

void printHelp() {
    std::cout << "Commands:\n"
                 "  SET key value          insert or update a key (logged, then cached)\n"
                 "  GET key                read a key\n"
                 "  DEL key                delete a key\n"
                 "  LIST                   show all key-value pairs\n"
                 "  MSET k1 v1 k2 v2 ...   set several keys atomically (ordered locking)\n"
                 "  STATS                  show system statistics\n"
                 "  FLUSH                  write dirty cached blocks to data.db + checkpoint the log\n"
                 "  HELP                   this text\n"
                 "  BACK                   return to the main menu\n"
                 "Limits: key <= " << MAX_KEY_LEN << " chars (no spaces), value <= " << MAX_VALUE_LEN << " chars.\n";
}

void executeCommands(SyncStore& s) {
    printHelp();
    std::string line;
    while (readLine("syncstore> ", line)) {
        if (line.empty()) continue;
        std::string upper = line;
        for (auto& c : upper) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
        if (upper == "BACK" || upper == "EXIT" || upper == "QUIT") return;

        ParsedCommand cmd;
        std::string err;
        if (!parseCommand(line, cmd, err)) { std::cout << "  Invalid: " << err << "\n"; continue; }
        if (cmd.type == CmdType::HELP) { printHelp(); continue; }
        if (cmd.type == CmdType::STATS) { std::cout << s.statsReport(); continue; }
        if (cmd.type == CmdType::FLUSH) {
            try { s.flush(); std::cout << "  Dirty blocks written to " << s.config().dbPath << ", log checkpointed\n"; }
            catch (const std::exception& e) { std::cout << "  ERROR: " << e.what() << "\n"; }
            continue;
        }

        RequestPtr r = s.submitLine(line, 0, err);            // goes through queue -> CPU scheduler -> worker
        if (!r) { std::cout << "  Invalid: " << err << "\n"; continue; }
        Response resp = r->result.get();
        std::cout << (resp.ok ? "" : "  ") << resp.text << "\n";
        std::cout << std::fixed << std::setprecision(3)
                  << "  [R" << r->id << " " << toString(r->type) << " | burst " << r->burst << ", priority "
                  << r->priority << " | waiting " << r->waitUs / 1000.0 << " ms, turnaround "
                  << r->turnaroundUs / 1000.0 << " ms";
        if (r->cpuNs) std::cout << " | real CPU " << r->cpuNs / 1000.0 << " us on core " << r->ranOnCpu;
        std::cout << "]\n";
    }
}

// Same batch of blocks, costed in both address spaces, for every algorithm.
void compareDiskAlgorithms(SyncStore& s) {
    const PhysicalMap& m = s.diskFileMap();
    std::cout << "\n--- Disk algorithms: textbook model vs the real layout of data.db ---\n";
    if (!m.ready()) {
        std::cout << "The real layout is unavailable here (" << m.error() << "),\n"
                     "so only the logical model can be shown.\n";
    } else {
        std::cout << "data.db occupies " << m.extentCount() << " extent(s) with "
                  << m.backwardJumps() << " backward jump(s); physical blocks "
                  << m.minPhysical() << ".." << m.maxPhysical() << ".\n";
    }

    std::vector<int> req = {10, 150, 25, 190, 60, 120, 5, 175};
    std::cout << "Request set (logical blocks):";
    for (int b : req) std::cout << " " << b;
    std::cout << "\n\n" << std::left << std::setw(10) << "Algo"
              << std::setw(16) << "model seek" << std::setw(20) << "real-layout seek"
              << "service order (logical blocks)\n";

    const bool wasPhysical = s.disk().physicalMode();
    for (int i = 0; i < 6; ++i) {
        DiskAlgo a = static_cast<DiskAlgo>(i);

        s.setPhysicalDisk(false);
        DiskPlan L = DiskScheduler::plan(a, 0, true, req, NUM_BLOCKS - 1);

        long realSeek = -1;
        std::vector<std::size_t> realOrder;
        if (s.setPhysicalDisk(true)) {
            std::vector<int> addrs;
            for (int b : req) addrs.push_back(s.disk().addressOf(b));
            DiskPlan P = DiskScheduler::plan(a, 0, true, addrs, s.disk().maxAddress());
            realSeek = P.totalSeek;
            realOrder = P.order;
        }

        std::cout << std::left << std::setw(10) << toString(a) << std::setw(16) << L.totalSeek;
        if (realSeek >= 0) std::cout << std::setw(20) << realSeek; else std::cout << std::setw(20) << "n/a";
        for (std::size_t k : L.order) std::cout << req[k] << " ";
        if (realSeek >= 0 && realOrder != L.order) {
            std::cout << "\n" << std::setw(26) << "" << std::setw(20) << "real order differs -> ";
            for (std::size_t k : realOrder) std::cout << req[k] << " ";
        }
        std::cout << "\n";
    }
    s.setPhysicalDisk(wasPhysical);
    std::cout << "\nSeek is counted in 4 KB blocks in both columns, so the two are comparable.\n"
                 "Where the orders differ, a simulator that only knows logical block numbers\n"
                 "would send the head on a different journey than the device actually needs.\n";
}

// Fork a child that commits data and is then killed with SIGKILL, so no destructor,
// no flush and no fsync of the data file can run. Then reopen and see what survived.
void crashDemo(const std::string& basePath) {
    const std::string db = basePath + ".crashdemo";
    ::unlink(db.c_str());
    ::unlink((db + ".wal").c_str());
    ::unlink((db + ".lock").c_str());

    const int N = 25;
    std::cout << "\n--- Crash recovery demo ---\n"
                 "A child process will commit " << N << " keys and then be killed with SIGKILL.\n"
                 "The buffer pool is write-back, so most of those pages are still only in memory.\n"
                 "Only the write-ahead log has been forced to the device.\n\n";

    std::cout.flush();   // never let a child inherit our buffered output and print it twice
    pid_t pid = ::fork();
    if (pid == 0) {
        Config c;
        c.dbPath = db;
        c.workers = 2;
        c.cpuUnitUs = 50;
        c.frames = 8;
        // Deliberately never destroyed: running ~SyncStore() would flush the buffer pool
        // and checkpoint the log, which is precisely what a crash denies a program.
        SyncStore* s = nullptr;
        try {
            s = new SyncStore(c);
            for (int i = 0; i < N; ++i)
                s->storage().set("crash" + std::to_string(i), "value-" + std::to_string(i * 7));
            WalStats w = s->wal().stats();
            std::cout << "  child pid " << ::getpid() << ": committed " << N << " keys, log holds "
                      << w.appends << " redo records (" << w.bytes / 1024 << " KB), "
                      << "average durable commit " << std::fixed << std::setprecision(0)
                      << s->wal().avgCommitUs() << " us\n"
                      << "  child pid " << ::getpid() << ": " << s->pool().cachedBlocks().size()
                      << " pages still sitting in the buffer pool, data.db not synced\n"
                      << "  child: raising SIGKILL now.\n";
            std::cout.flush();
        } catch (const std::exception& e) {
            std::cout << "  child failed: " << e.what() << "\n";
            ::_exit(2);
        }
        ::raise(SIGKILL);     // the kernel stops us dead: no unwinding, no flush
        ::_exit(0);
    }
    if (pid < 0) { std::cout << "fork failed\n"; return; }

    int st = 0;
    ::waitpid(pid, &st, 0);
    std::cout << "\n  parent: child ended by signal " << (WIFSIGNALED(st) ? WTERMSIG(st) : 0)
              << (WIFSIGNALED(st) && WTERMSIG(st) == SIGKILL ? " (SIGKILL)" : "") << "\n";

    try {
        Config c;
        c.dbPath = db;
        c.workers = 1;
        SyncStore s(c);
        std::cout << "  parent: " << s.recoveryNote() << "\n";
        int found = 0;
        for (int i = 0; i < N; ++i) {
            Response r = s.storage().get("crash" + std::to_string(i));
            if (r.ok && r.text.find("value-" + std::to_string(i * 7)) != std::string::npos) ++found;
        }
        std::cout << "  parent: " << found << " of " << N << " committed keys are intact.\n\n"
                  << (found == N ? "  RESULT: every committed write survived a power-cut-equivalent kill.\n"
                                   "  That is the write-ahead rule doing its job: the log reached the device\n"
                                   "  before the page did, so recovery could replay it.\n"
                                 : "  RESULT: data was lost - the log did not cover every commit.\n");
    } catch (const std::exception& e) {
        std::cout << "  parent: reopen failed: " << e.what() << "\n";
    }
    ::unlink(db.c_str());
    ::unlink((db + ".wal").c_str());
    ::unlink((db + ".lock").c_str());
}

void multiProcessWorkload(SyncStore& s) {
    int clients = 4, per = 25;
    if (!askInt("Client processes (1-16) [4]: ", 4, 1, 16, clients)) return;
    if (!askInt("Requests per client (1-500) [25]: ", 25, 1, 500, per)) return;

    IpcServer srv;
    if (!srv.ok()) { std::cout << "Shared memory unavailable: " << srv.error() << "\n"; return; }

    std::cout << "Forking " << clients << " processes ...\n";
    IpcResult r = srv.run(s, clients, per, s.config().workers);
    s.waitIdle();
    std::cout << std::fixed << std::setprecision(2)
              << r.note << "\n"
              << "Served " << r.served << " requests in " << std::setprecision(1) << r.elapsedMs
              << " ms, average end-to-end latency " << std::setprecision(2) << r.avgLatencyMs << " ms.\n"
              << "Bounded buffer in shared memory: clients blocked on a full ring "
              << r.clientBlocked << " time(s), the server waited on an empty ring "
              << r.serverBlocked << " time(s).\n"
              << "Those two numbers are the producer-consumer problem solved across real\n"
              << "process boundaries with POSIX semaphores (sem_init with pshared=1).\n";
    if (r.failed) std::cout << r.failed << " client process(es) exited abnormally.\n";
}

void configMenu(SyncStore& s) {
    while (true) {
        std::cout << "\n--- Configuration ---\n"
                  << " 1. Worker threads            (now " << s.config().workers << ", machine has "
                  << CpuWork::cpuCount() << " core(s))\n"
                  << " 2. Buffer pool size          (now " << s.pool().frameCount() << " frames)\n"
                  << " 3. Round Robin quantum       (now " << s.cpu().quantum() << " units)\n"
                  << " 4. Live trace of OS events   (now " << (s.stats().trace() ? "ON" : "OFF") << ")\n"
                  << " 5. Kernel scheduling policy  (now " << toString(s.config().kernelPolicy) << ")\n"
                  << " 6. Pin workers to cores      (now " << (s.config().pinWorkers ? "ON" : "OFF") << ")\n"
                  << " 7. Disk addressing           (now " << (s.disk().physicalMode() ? "real device blocks" : "logical model") << ")\n"
                  << " 8. Reset statistics and kernel baseline\n"
                  << " 9. Back\n";
        int c;
        if (!askInt("Choice: ", 9, 1, 9, c) || c == 9) return;
        int v;
        if (c == 1 && askInt("Worker threads (1-32) [4]: ", 4, 1, 32, v)) {
            s.setWorkers(v);
            std::cout << "  Thread pool restarted with " << v << " workers.\n";
            if (v > CpuWork::cpuCount())
                std::cout << "  More workers than cores: run-queue waiting will appear in the Reality Check.\n";
        } else if (c == 2 && askInt("Buffer pool frames (1-100) [8]: ", 8, 1, 100, v)) {
            s.setBufferFrames(static_cast<std::size_t>(v));
            std::cout << "  Dirty blocks flushed; pool resized to " << v << " frames.\n";
        } else if (c == 3 && askInt("Time quantum in units (1-20) [2]: ", 2, 1, 20, v)) {
            s.setQuantum(v);
            std::cout << "  Quantum = " << v << "\n";
        } else if (c == 4) {
            s.setTrace(!s.stats().trace());
            std::cout << "  Trace " << (s.stats().trace() ? "ON" : "OFF") << "\n";
        } else if (c == 5) {
            std::cout << " 1. SCHED_OTHER (CFS, always available)\n"
                         " 2. SCHED_FIFO  (real-time, needs privileges)\n"
                         " 3. SCHED_RR    (real-time round robin, needs privileges)\n";
            int p;
            if (!askInt("Select [1]: ", 1, 1, 3, p)) return;
            KernelPolicy kp = p == 2 ? KernelPolicy::FIFO : (p == 3 ? KernelPolicy::RR : KernelPolicy::OTHER);
            if (kp != KernelPolicy::OTHER && !CpuWork::policyAvailable(kp)) {
                std::cout << "  The kernel refuses that policy for this user. Run with sudo to use it.\n"
                             "  Staying on SCHED_OTHER.\n";
            } else {
                s.setKernelPolicy(kp, 1);
                std::cout << "  Worker threads restarted under " << toString(kp) << ".\n";
            }
        } else if (c == 6) {
            s.setPinWorkers(!s.config().pinWorkers);
            std::cout << "  Worker pinning " << (s.config().pinWorkers ? "ON" : "OFF") << ".\n";
        } else if (c == 7) {
            bool want = !s.disk().physicalMode();
            if (!s.setPhysicalDisk(want) && want)
                std::cout << "  The real layout is unavailable (FIEMAP unsupported here).\n";
            else
                std::cout << "  Disk head now moves over "
                          << (s.disk().physicalMode() ? "real device blocks.\n" : "logical block numbers.\n");
        } else if (c == 8) {
            s.resetBaseline();
            std::cout << "  Statistics and kernel baseline cleared.\n";
        }
    }
}

// One non-interactive pass through everything, for demos and screenshots.
int runBatchDemo(SyncStore& store) {
    std::cout << store.environmentReport();

    std::cout << "\n--- Thread workload: 4 producers x 25 requests ---\n";
    WorkloadResult w = store.runWorkload(4, 25);
    store.waitIdle();
    std::cout << w.totalRequests << " requests in " << std::fixed << std::setprecision(1)
              << w.elapsedMs << " ms\n";

    std::cout << "\n--- Multi-process workload: 4 forked processes x 25 requests ---\n";
    {
        IpcServer srv;
        if (srv.ok()) {
            IpcResult r = srv.run(store, 4, 25, store.config().workers);
            store.waitIdle();
            std::cout << r.note << "\n"
                      << "served " << r.served << " in " << r.elapsedMs << " ms, avg latency "
                      << std::setprecision(2) << r.avgLatencyMs << " ms, client blocked "
                      << r.clientBlocked << ", server blocked " << r.serverBlocked << "\n";
        } else {
            std::cout << "shared memory unavailable: " << srv.error() << "\n";
        }
    }

    store.flush();
    std::cout << store.statsReport();
    std::cout << store.validationReport();
    compareDiskAlgorithms(store);
    crashDemo(store.config().dbPath);
    return 0;
}

// Schedule REAL operating-system processes, each working on a real file.
int runJobScheduler(SyncStore& store, const std::string& dir, const std::string& algoName,
                    int quantumMs, int cores, int passes, int maxJobs) {
    const std::string outDir = "data/reports";
    JobScheduler sched;
    sched.setPasses(passes);
    int n = sched.addFilesFrom(dir, outDir, maxJobs);
    if (n == 0) { std::cout << "No suitable files under " << dir << "\n"; return 1; }

    std::cout << "\n" << n << " real file(s) from " << dir << " will each be processed by a\n"
              << "separate child process. Reports are written to " << outDir << "/.\n"
              << "Watch `top` or `ps` in another terminal - these are real PIDs.\n\n"
              << std::left << std::setw(5) << "job" << std::setw(24) << "file"
              << std::setw(10) << "KB" << std::setw(10) << "burst~" << "priority\n";
    for (const Job& j : sched.jobs())
        std::cout << std::left << std::setw(5) << j.id << std::setw(24) << j.name
                  << std::setw(10) << (j.sizeBytes / 1024) << std::setw(10) << j.burst
                  << j.priority << "\n";
    std::cout << "\nBurst is ESTIMATED from file size - that is all a scheduler can know in\n"
                 "advance. The table at the end compares it with the CPU time really used.\n";

    std::vector<CpuAlgo> algos;
    if (algoName == "fcfs") algos = {CpuAlgo::FCFS};
    else if (algoName == "sjf") algos = {CpuAlgo::SJF};
    else if (algoName == "priority") algos = {CpuAlgo::PRIORITY};
    else if (algoName == "rr") algos = {CpuAlgo::RR};
    else algos = {CpuAlgo::FCFS, CpuAlgo::SJF, CpuAlgo::PRIORITY, CpuAlgo::RR};

    std::vector<JobRunResult> results;
    for (CpuAlgo a : algos) {
        std::cout << "\n================ " << toString(a) << " on real processes ================\n";
        if (a == CpuAlgo::RR)
            std::cout << "Quantum " << quantumMs << " ms. Preemption is a real SIGSTOP; resumption a real SIGCONT.\n";
        std::cout << "\n";
        JobRunResult r = sched.run(a, quantumMs, cores);
        results.push_back(r);
        std::cout << "\n" << std::left << std::setw(5) << "job" << std::setw(22) << "file"
                  << std::setw(10) << "burst~" << std::setw(12) << "cpu used ms"
                  << std::setw(12) << "wait ms" << std::setw(14) << "turnaround ms"
                  << std::setw(9) << "slices" << "state\n";
        for (const Job& j : r.jobs)
            std::cout << std::left << std::setw(5) << j.id << std::setw(22) << j.name
                      << std::setw(10) << j.burst
                      << std::setw(12) << (std::ostringstream() << std::fixed << std::setprecision(1) << j.cpuUsedUs / 1000.0).str()
                      << std::setw(12) << (std::ostringstream() << std::fixed << std::setprecision(1) << j.waitUs / 1000.0).str()
                      << std::setw(14) << (std::ostringstream() << std::fixed << std::setprecision(1) << j.turnaroundUs / 1000.0).str()
                      << std::setw(9) << j.slices << toString(j.state) << "\n";
        std::cout << std::fixed << std::setprecision(1)
                  << "makespan " << r.makespanMs << " ms | avg wait " << r.avgWaitMs
                  << " ms | avg turnaround " << r.avgTurnaroundMs << " ms | preemptions "
                  << r.preemptions << " | kernel-measured CPU " << r.totalCpuUs / 1000.0 << " ms\n";

        // Record each run into the key-value store, so the two halves of the project meet.
        std::ostringstream key;
        key << "run_" << r.algo;
        std::ostringstream val;
        val << r.algo << " wait=" << std::fixed << std::setprecision(1) << r.avgWaitMs
            << "ms turn=" << r.avgTurnaroundMs << "ms preempt=" << r.preemptions;
        store.storage().set(key.str(), val.str());
    }

    if (results.size() > 1) {
        std::cout << "\n================ comparison on the same real files ================\n"
                  << std::left << std::setw(12) << "algorithm" << std::setw(14) << "avg wait ms"
                  << std::setw(18) << "avg turnaround" << std::setw(14) << "makespan ms"
                  << "preemptions\n";
        for (const JobRunResult& r : results)
            std::cout << std::left << std::setw(12) << r.algo
                      << std::setw(14) << (std::ostringstream() << std::fixed << std::setprecision(1) << r.avgWaitMs).str()
                      << std::setw(18) << (std::ostringstream() << std::fixed << std::setprecision(1) << r.avgTurnaroundMs).str()
                      << std::setw(14) << (std::ostringstream() << std::fixed << std::setprecision(1) << r.makespanMs).str()
                      << r.preemptions << "\n";
        std::cout << "\nEvery row above was produced by forking real processes and letting the kernel\n"
                     "run them. The CPU times come from wait4() rusage. Open " << outDir << "/ to see\n"
                     "what those processes actually produced.\n";
    }
    return 0;
}

// Real data, not generated commands: store actual files, read them back, check the bytes.
int runRealWorkload(SyncStore& store, const std::string& dir, bool verify, bool compare) {
    if (!dir.empty()) {
        std::cout << "\n--- Ingesting real files from " << dir << " ---\n";
        IngestResult r = ingestDirectory(store, dir, 60);
        std::cout << r.note << "\n"
                  << std::fixed << std::setprecision(1)
                  << r.bytes << " bytes of real data in " << r.elapsedMs << " ms; the kernel says "
                  << r.deviceWriteBytes / 1024 << " KB actually reached the device.\n";
        if (r.filesStored == 0) return 1;
    }

    if (verify) {
        std::cout << "\n--- Reading it back and checking it against the files on disk ---\n";
        VerifyResult v = verifyAgainstDisk(store);
        std::cout << v.filesChecked << " file(s) checked: " << v.filesOk
                  << " came back exactly as stored, " << v.filesCorrupt << " corrupt, "
                  << v.filesMissing << " missing.\n";
        if (v.filesChanged)
            std::cout << v.filesChanged << " of those no longer match the file on disk - "
                      << "the original was edited after it was stored.\n";
        std::cout
                  << std::fixed << std::setprecision(1)
                  << v.bytes << " bytes verified in " << v.elapsedMs << " ms; "
                  << v.deviceReadBytes / 1024 << " KB came off the device.\n";
        for (const std::string& f : v.failures) std::cout << "  " << f << "\n";
        std::cout << (v.filesOk == v.filesChecked && v.filesChecked > 0
                          ? "\nEvery byte survived the queue, the scheduler, the locks, the log,\n"
                            "the buffer pool and the disk scheduler. A wrong answer anywhere in that\n"
                            "chain would show up here as a checksum mismatch.\n"
                          : "\nData did not survive intact - see the failures above.\n");
    }

    if (compare) {
        std::cout << "\n--- A concurrent, skewed read workload over the real data, per policy ---\n"
                  << "4 threads x 400 reads, 80% of them into a 20% hot set.\n\n"
                  << std::left << std::setw(8) << "cache" << std::setw(8) << "disk"
                  << std::setw(12) << "wall ms" << std::setw(10) << "hits" << std::setw(10) << "misses"
                  << std::setw(14) << "device KB" << std::setw(12) << "seek" << "verified\n";
        for (const PolicyRow& r : comparePolicies(store)) {
            std::cout << std::left << std::setw(8) << r.cacheAlgo << std::setw(8) << r.diskAlgo
                      << std::setw(12) << (std::ostringstream() << std::fixed << std::setprecision(1)
                                           << r.elapsedMs).str()
                      << std::setw(10) << r.cacheHits << std::setw(10) << r.cacheMisses
                      << std::setw(14) << (r.deviceReadBytes / 1024) << std::setw(12) << r.seek
                      << (r.ok ? "yes" : "NO") << "\n";
        }
        std::cout << "\nRead the seek column first: it separates cleanly and in the order theory\n"
                     "predicts (FCFS worst, then C-LOOK, SCAN, SSTF best), and it holds for all\n"
                     "three cache policies. That is a real effect on real data.\n"
                     "Read the hit counts sceptically: at this pool size and hot-set ratio they sit\n"
                     "within run-to-run noise, so do NOT claim the replacement policies differ here.\n"
                     "Raise the frame count or narrow the hot set and the gap appears; that is the\n"
                     "experiment to run, not a number to assert.\n";
    }
    return 0;
}

void usage() {
    std::cout <<
        "Usage: syncstore [options]\n"
        "  --db PATH          data file (default data/data.db)\n"
        "  --workers N        worker threads (default 4)\n"
        "  --frames N         buffer pool frames (default 8)\n"
        "  --policy P         other | fifo | rr   kernel scheduling policy for workers\n"
        "  --pin              pin each worker to a core (sched_setaffinity)\n"
        "  --batch            run one pass of every demo and exit (no menu)\n"
        "\n"
        "  Real data instead of generated commands:\n"
        "  --ingest DIR       store real files from DIR through the whole pipeline\n"
        "  --verify           read them back and checksum against the originals on disk\n"
        "  --compare          run the verification pass under every cache/disk policy\n"
        "\n"
        "  Scheduling of REAL processes working on real files:\n"
        "  --jobs DIR         one child process per file in DIR; writes reports you can open\n"
        "  --job-algo A       fcfs | sjf | priority | rr | all   (default all)\n"
        "  --job-cores N      how many may run at once (default 1)\n"
        "  --job-quantum MS   Round Robin quantum in ms (default 60)\n"
        "  --job-passes N     analysis repetitions per job (default 80)\n"
        "  --job-count N      how many files to turn into jobs (default 6)\n"
        "\n"
        "  Switches that turn a real mechanism back into a model, for comparison:\n"
        "  --no-direct        allow the page cache instead of O_DIRECT\n"
        "  --no-real-work     use sleep() for CPU bursts, like a simulator\n"
        "  --logical-disk     schedule on logical block numbers, not real device blocks\n"
        "  --no-wal           no write-ahead log (a crash then loses recent writes)\n"
        "  --no-fragment      lay a fresh data file out contiguously\n";
}

}  // namespace

int main(int argc, char** argv) {
    Config cfg;
    bool batch = false;
    std::string ingestDir;
    bool doVerify = false, doCompare = false;
    std::string jobsDir;
    std::string jobAlgo = "all";
    int jobQuantumMs = 60, jobCores = 1, jobPasses = 80, jobMax = 6;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--db" && i + 1 < argc) cfg.dbPath = argv[++i];
        else if (a == "--workers" && i + 1 < argc) cfg.workers = std::atoi(argv[++i]);
        else if (a == "--frames" && i + 1 < argc) cfg.frames = static_cast<std::size_t>(std::atoi(argv[++i]));
        else if (a == "--policy" && i + 1 < argc) {
            std::string p = argv[++i];
            cfg.kernelPolicy = (p == "fifo") ? KernelPolicy::FIFO
                             : (p == "rr")   ? KernelPolicy::RR
                                             : KernelPolicy::OTHER;
        }
        else if (a == "--pin") cfg.pinWorkers = true;
        else if (a == "--batch") batch = true;
        else if (a == "--ingest" && i + 1 < argc) ingestDir = argv[++i];
        else if (a == "--verify") doVerify = true;
        else if (a == "--compare") doCompare = true;
        else if (a == "--jobs" && i + 1 < argc) jobsDir = argv[++i];
        else if (a == "--job-algo" && i + 1 < argc) jobAlgo = argv[++i];
        else if (a == "--job-quantum" && i + 1 < argc) jobQuantumMs = std::atoi(argv[++i]);
        else if (a == "--job-cores" && i + 1 < argc) jobCores = std::atoi(argv[++i]);
        else if (a == "--job-passes" && i + 1 < argc) jobPasses = std::atoi(argv[++i]);
        else if (a == "--job-count" && i + 1 < argc) jobMax = std::atoi(argv[++i]);
        else if (a == "--no-direct") cfg.directIo = false;
        else if (a == "--no-real-work") cfg.realWork = false;
        else if (a == "--logical-disk") cfg.physicalDisk = false;
        else if (a == "--no-wal") cfg.wal = false;
        else if (a == "--no-fragment") cfg.fragmentNewDb = false;
        else if (a == "--help" || a == "-h") { usage(); return 0; }
        else { std::cerr << "Unknown option: " << a << "\n"; usage(); return 1; }
    }
    if (cfg.workers < 1) cfg.workers = 1;
    if (cfg.frames < 1) cfg.frames = 1;

    // Only one SyncStore may own a data file. The kernel holds this lock and releases it
    // automatically if we are killed, which is exactly what a lock file alone cannot do.
    DataFileLock lock;
    std::string holder;
    if (!lock.acquire(cfg.dbPath, holder)) {
        std::cerr << "'" << cfg.dbPath << "' is already in use by " << holder << ".\n"
                  << "Close that instance, or start this one with --db on another file.\n";
        return 1;
    }

    try {
        SyncStore store(cfg);
        std::cout << "Opened '" << cfg.dbPath << "' - " << store.storage().keyCount() << " key(s) present.\n";
        std::cout << store.recoveryNote() << "\n";
        if (!jobsDir.empty()) {
            int rc = runJobScheduler(store, jobsDir, jobAlgo, jobQuantumMs, jobCores, jobPasses, jobMax);
            store.flush();
            return rc;
        }
        if (!ingestDir.empty() || doVerify || doCompare) {
            int rc = runRealWorkload(store, ingestDir, doVerify || doCompare, doCompare);
            store.flush();
            return rc;
        }
        if (batch) {
            int rc = runBatchDemo(store);
            store.flush();
            return rc;
        }
        std::cout << "\nTip: menu option 8 shows which parts of this run are real and\n"
                     "checks our own measurements against the kernel's counters.\n";

        while (true) {
            printMenu(store);
            int choice;
            if (!askInt("Enter choice (0-13): ", 13, 0, 13, choice) || choice == 0 || choice == 13) {
                std::cout << "Flushing dirty blocks and checkpointing the log ...\n";
                store.flush();
                std::cout << "Goodbye.\n";
                return 0;
            }
            switch (choice) {
                case 1: executeCommands(store); break;
                case 2: {
                    std::cout << "1. FCFS\n2. SJF\n3. Priority\n4. Round Robin\n";
                    int c;
                    if (!askInt("Select: ", 1, 1, 4, c)) return 0;
                    store.setCpuAlgorithm(static_cast<CpuAlgo>(c - 1));
                    std::cout << "CPU scheduler = " << toString(store.cpu().algorithm()) << "\n";
                    break;
                }
                case 3: {
                    std::cout << "1. FCFS\n2. SSTF\n3. SCAN\n4. C-SCAN\n5. LOOK\n6. C-LOOK\n";
                    int c;
                    if (!askInt("Select: ", 1, 1, 6, c)) return 0;
                    store.setDiskAlgorithm(static_cast<DiskAlgo>(c - 1));
                    std::cout << "Disk scheduler = " << toString(store.disk().algorithm()) << "\n";
                    break;
                }
                case 4: {
                    std::cout << "1. FIFO\n2. LRU\n3. Clock\n";
                    int c;
                    if (!askInt("Select: ", 2, 1, 3, c)) return 0;
                    store.setReplacementPolicy(static_cast<ReplacementPolicy>(c - 1));
                    std::cout << "Page replacement = " << toString(store.pool().policy()) << "\n";
                    break;
                }
                case 5: {
                    int producers, per;
                    if (!askInt("Producer threads (1-16) [4]: ", 4, 1, 16, producers)) return 0;
                    if (!askInt("Requests per producer (1-2000) [25]: ", 25, 1, 2000, per)) return 0;
                    std::cout << "Running " << producers << " producers x " << per << " requests ...\n";
                    WorkloadResult w = store.runWorkload(producers, per);
                    store.waitIdle();
                    std::cout << std::fixed << std::setprecision(1)
                              << "Done: " << w.totalRequests << " requests in " << w.elapsedMs << " ms ("
                              << (w.elapsedMs > 0 ? w.totalRequests * 1000.0 / w.elapsedMs : 0.0) << " req/s), "
                              << w.succeeded << " ok, " << w.notFound << " not-found/other.\n";
                    break;
                }
                case 6: multiProcessWorkload(store); break;
                case 7: std::cout << store.statsReport(); break;
                case 8:
                    std::cout << "\n" << store.environmentReport() << store.validationReport();
                    break;
                case 9: crashDemo(store.config().dbPath); break;
                case 10: compareDiskAlgorithms(store); break;
                case 11: {
                    std::string dir;
                    if (!readLine("Directory of files to process [src]: ", dir)) return 0;
                    if (dir.empty()) dir = "src";
                    int count, q;
                    if (!askInt("How many files (1-12) [5]: ", 5, 1, 12, count)) return 0;
                    if (!askInt("Round Robin quantum in ms (10-500) [60]: ", 60, 10, 500, q)) return 0;
                    runJobScheduler(store, dir, "all", q, 1, 80, count);
                    break;
                }
                case 12: configMenu(store); break;
                case 13:
                    std::cout << "Flushing dirty blocks and checkpointing the log ...\n";
                    store.flush();
                    std::cout << "Goodbye.\n";
                    return 0;
            }
        }
    done:
        std::cout << "Flushing dirty blocks and checkpointing the log ...\n";
        store.flush();
        std::cout << "Goodbye.\n";
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
