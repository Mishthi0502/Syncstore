#include "block_file.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <stdexcept>
#include "kernel_probe.h"

namespace {
// O_DIRECT requires the user buffer, the file offset and the length to be aligned to the
// device's logical block size. BlockData lives wherever the caller put it, so every
// transfer goes through this aligned bounce buffer. One per thread, so it needs no lock.
char* alignedBounce() {
    static thread_local char* buf = [] {
        void* p = nullptr;
        if (::posix_memalign(&p, 4096, BLOCK_SIZE) != 0) return static_cast<char*>(nullptr);
        return static_cast<char*>(p);
    }();
    return buf;
}
}  // namespace

BlockFile::BlockFile(const std::string& path, const Options& opt) : path_(path) {
    auto parent = std::filesystem::path(path).parent_path();
    if (!parent.empty()) {
        std::error_code ec;
        std::filesystem::create_directories(parent, ec);
    }

    const off_t wanted = static_cast<off_t>(BLOCK_SIZE) * NUM_BLOCKS;
    struct stat st;
    created_ = (::stat(path.c_str(), &st) != 0 || st.st_size < wanted);

    // A brand new database can be laid out the way a real one ages: in several extents.
    if (created_ && opt.fragment) {
        std::string err;
        PhysicalMap::createFragmented(path, BLOCK_SIZE, NUM_BLOCKS, err);
    }

    openFile(opt.direct);

    if (::fstat(fd_, &st) != 0 || (st.st_size < wanted && ::ftruncate(fd_, wanted) != 0)) {
        int e = errno;
        ::close(fd_);
        throw std::runtime_error("cannot size '" + path + "': " + std::strerror(e));
    }

    device_ = PhysicalMap::deviceOfPath(path);
    rotational_ = PhysicalMap::deviceIsRotational(device_);
    KernelProbe::setDevice(device_);

    if (opt.mapPhysical) remapPhysical();
}

void BlockFile::openFile(bool wantDirect) {
    if (wantDirect) {
        fd_ = ::open(path_.c_str(), O_RDWR | O_CREAT | O_DIRECT, 0644);
        if (fd_ >= 0) {
            // Opening can succeed where the filesystem still refuses aligned I/O
            // (overlayfs and some tmpfs setups). Prove it works before trusting it.
            char* b = alignedBounce();
            if (b && ::pread(fd_, b, BLOCK_SIZE, 0) >= 0) {
                direct_ = true;
                ioMode_ = "O_DIRECT (page cache bypassed)";
                return;
            }
            ioMode_ = std::string("buffered - O_DIRECT read refused: ") + std::strerror(errno);
            ::close(fd_);
            fd_ = -1;
        } else {
            ioMode_ = std::string("buffered - O_DIRECT open refused: ") + std::strerror(errno);
        }
    } else {
        ioMode_ = "buffered (O_DIRECT disabled by configuration)";
    }

    fd_ = ::open(path_.c_str(), O_RDWR | O_CREAT, 0644);
    if (fd_ < 0) throw std::runtime_error("cannot open '" + path_ + "': " + std::strerror(errno));
    direct_ = false;
}

BlockFile::~BlockFile() { if (fd_ >= 0) ::close(fd_); }

void BlockFile::remapPhysical() { map_.build(fd_, BLOCK_SIZE, NUM_BLOCKS); }

void BlockFile::readBlock(int block, BlockData& out) {
    if (block < 0 || block >= NUM_BLOCKS) throw std::runtime_error("read: block out of range");
    char* dst = out.data();
    char* bounce = nullptr;
    if (direct_) {
        bounce = alignedBounce();
        if (!bounce) throw std::runtime_error("read: no aligned buffer");
        dst = bounce;
    }
    std::size_t done = 0;
    while (done < BLOCK_SIZE) {
        ssize_t n = ::pread(fd_, dst + done, BLOCK_SIZE - done,
                            static_cast<off_t>(block) * BLOCK_SIZE + done);
        if (n < 0) {
            if (errno == EINTR) continue;
            throw std::runtime_error(std::string("pread failed: ") + std::strerror(errno));
        }
        if (n == 0) { std::memset(dst + done, 0, BLOCK_SIZE - done); break; }
        done += static_cast<std::size_t>(n);
    }
    if (bounce) std::memcpy(out.data(), bounce, BLOCK_SIZE);
}

void BlockFile::writeBlock(int block, const BlockData& in) {
    if (block < 0 || block >= NUM_BLOCKS) throw std::runtime_error("write: block out of range");
    const char* src = in.data();
    if (direct_) {
        char* bounce = alignedBounce();
        if (!bounce) throw std::runtime_error("write: no aligned buffer");
        std::memcpy(bounce, in.data(), BLOCK_SIZE);
        src = bounce;
    }
    std::size_t done = 0;
    while (done < BLOCK_SIZE) {
        ssize_t n = ::pwrite(fd_, src + done, BLOCK_SIZE - done,
                             static_cast<off_t>(block) * BLOCK_SIZE + done);
        if (n < 0) {
            if (errno == EINTR) continue;
            throw std::runtime_error(std::string("pwrite failed: ") + std::strerror(errno));
        }
        done += static_cast<std::size_t>(n);
    }
}

void BlockFile::sync() { ::fsync(fd_); }
void BlockFile::syncData() { ::fdatasync(fd_); }
