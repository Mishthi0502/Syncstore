#include "statistics.h"
#include <iomanip>
#include <iostream>
#include <sstream>

namespace {
std::mutex g_printMutex;   // keeps trace lines from different threads from interleaving
std::string ms(double us) {
    std::ostringstream o;
    o << std::fixed << std::setprecision(3) << us / 1000.0 << " ms";
    return o.str();
}
}  // namespace

void Statistics::log(const std::string& tag, const std::string& msg) const {
    if (!trace_) return;
    std::lock_guard<std::mutex> lk(g_printMutex);
    std::cout << "  [" << tag << "] " << msg << std::endl;
}

void Statistics::updateMax(std::atomic<std::uint64_t>& target, std::uint64_t v) {
    std::uint64_t cur = target.load();
    while (v > cur && !target.compare_exchange_weak(cur, v)) {}
}

void Statistics::reset() {
    std::lock_guard<std::mutex> lk(mtx_);
    dispatchOrder_.clear(); completions_.clear(); diskOrder_.clear(); cacheEvents_.clear();
    for (auto* a : {&enqueued_, &producerBlocked_, &consumerBlocked_, &dispatches_, &firstDispatches_,
                    &queueWaitTotalUs_, &maxQueueLen_, &preemptions_, &completed_, &waitTotalUs_,
                    &turnTotalUs_, &diskAccesses_, &diskReads_, &diskWrites_, &diskBatches_,
                    &diskBatchedReqs_, &maxBatch_, &cacheHits_, &cacheMisses_, &replacements_,
                    &writeBacks_, &sharedAcq_, &exclAcq_, &contended_, &multiLocks_,
                    &multiLockedBlocks_, &maxReaders_})
        a->store(0);
    seekTotal_ = 0; seekExecuted_ = 0; seekOther_ = 0;
}

void Statistics::recordEnqueue(std::size_t len) {
    ++enqueued_;
    updateMax(maxQueueLen_, len);
}

void Statistics::recordDispatch(std::uint64_t id, bool firstTime, std::uint64_t queueWaitUs) {
    ++dispatches_;
    if (firstTime) { ++firstDispatches_; queueWaitTotalUs_ += queueWaitUs; }
    std::lock_guard<std::mutex> lk(mtx_);
    dispatchOrder_.push_back(id);
}

void Statistics::recordCompletion(std::uint64_t id, const char* type, int burst,
                                  std::uint64_t waitUs, std::uint64_t turnUs) {
    ++completed_;
    waitTotalUs_ += waitUs;
    turnTotalUs_ += turnUs;
    std::lock_guard<std::mutex> lk(mtx_);
    completions_.push_back({id, type, burst, waitUs, turnUs});
}

void Statistics::recordDiskAccess(int block, bool isWrite) {
    ++diskAccesses_;
    if (isWrite) ++diskWrites_; else ++diskReads_;
    std::lock_guard<std::mutex> lk(mtx_);
    diskOrder_.push_back({block, isWrite});
}

void Statistics::recordDiskBatch(std::size_t n, long seek) {
    ++diskBatches_;
    diskBatchedReqs_ += n;
    seekTotal_ += seek;
    updateMax(maxBatch_, n);
}

void Statistics::recordSeekModels(long executed, long other) {
    seekExecuted_ += executed;
    seekOther_ += other;
}

void Statistics::cacheEvent(const std::string& text) {
    {
        std::lock_guard<std::mutex> lk(mtx_);
        cacheEvents_.push_back(text);
        if (cacheEvents_.size() > 500) cacheEvents_.erase(cacheEvents_.begin(), cacheEvents_.begin() + 250);
    }
    log("CACHE", text);
}

void Statistics::syncShared(bool contended)   { ++sharedAcq_; if (contended) ++contended_; }
void Statistics::syncExclusive(bool contended){ ++exclAcq_;   if (contended) ++contended_; }
void Statistics::syncMultiLock(std::size_t n) { ++multiLocks_; multiLockedBlocks_ += n; }
void Statistics::syncReaders(int now)         { updateMax(maxReaders_, static_cast<std::uint64_t>(now)); }

double Statistics::avgWaitUs() const {
    auto n = completed_.load();
    return n ? static_cast<double>(waitTotalUs_.load()) / n : 0.0;
}
double Statistics::avgTurnaroundUs() const {
    auto n = completed_.load();
    return n ? static_cast<double>(turnTotalUs_.load()) / n : 0.0;
}
std::vector<std::uint64_t> Statistics::dispatchOrder() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return dispatchOrder_;
}
std::vector<DiskEvent> Statistics::diskOrder() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return diskOrder_;
}

std::string Statistics::report(const StatsContext& c) const {
    std::ostringstream o;
    const std::string bar(60, '=');
    o << bar << "\n                 SYNCSTORE  STATISTICS\n" << bar << "\n";

    // ------------------------------------------------------------ CPU
    std::vector<std::uint64_t> order;
    std::vector<Completion> done;
    std::vector<DiskEvent> dorder;
    std::vector<std::string> events;
    {
        std::lock_guard<std::mutex> lk(mtx_);
        order = dispatchOrder_; done = completions_; dorder = diskOrder_; events = cacheEvents_;
    }
    o << "[CPU SCHEDULING]\n";
    o << "  Algorithm              : " << c.cpuAlgo;
    if (c.cpuAlgo == "Round Robin") o << " (time quantum = " << c.quantum << " units)";
    o << "\n  Burst unit             : " << c.cpuUnitUs << " us ("
      << (c.burstMode.empty() ? "service time" : c.burstMode) << ")\n";
    o << "  Processed requests     : " << completed_ << "\n";
    o << "  Preemptions (RR)       : " << preemptions_ << "\n";
    o << "  Avg waiting time       : " << ms(avgWaitUs()) << "\n";
    o << "  Avg turnaround time    : " << ms(avgTurnaroundUs()) << "\n";
    o << "  Dispatch order (last " << std::min<std::size_t>(order.size(), 40) << " of " << order.size() << "): ";
    for (std::size_t i = order.size() > 40 ? order.size() - 40 : 0; i < order.size(); ++i) o << "R" << order[i] << ' ';
    o << "\n";
    if (!done.empty()) {
        o << "  Last completed requests:\n";
        o << "    " << std::left << std::setw(6) << "id" << std::setw(7) << "type" << std::setw(7) << "burst"
          << std::setw(14) << "waiting" << "turnaround\n";
        for (std::size_t i = done.size() > 8 ? done.size() - 8 : 0; i < done.size(); ++i)
            o << "    R" << std::setw(5) << done[i].id << std::setw(7) << done[i].type << std::setw(7) << done[i].burst
              << std::setw(14) << ms(done[i].waitUs) << ms(done[i].turnUs) << "\n";
    }

    // ------------------------------------------------------------ DISK
    o << "\n[DISK SCHEDULING]   head moves over "
      << (c.addressing.empty() ? "block numbers" : c.addressing) << "\n";
    o << "  Algorithm              : " << c.diskAlgo << "\n";
    o << "  Block accesses         : " << diskAccesses_ << "  (" << diskReads_ << " reads, " << diskWrites_ << " writes)\n";
    o << "  Total seek distance    : " << seekTotal_ << " blocks\n";
    o << "  Scheduling batches     : " << diskBatches_;
    if (diskBatches_) o << "  (avg " << std::fixed << std::setprecision(2)
                        << static_cast<double>(diskBatchedReqs_) / diskBatches_ << " requests/batch, max " << maxBatch_ << ")";
    o << "\n  I/O order (last " << std::min<std::size_t>(dorder.size(), 30) << " of " << dorder.size() << "): ";
    for (std::size_t i = dorder.size() > 30 ? dorder.size() - 30 : 0; i < dorder.size(); ++i)
        o << (dorder[i].isWrite ? 'W' : 'R') << dorder[i].block << ' ';
    o << "\n";

    // ------------------------------------------------------------ MEMORY
    std::uint64_t acc = cacheHits_ + cacheMisses_;
    o << "\n[MEMORY MANAGEMENT - BUFFER POOL]\n";
    o << "  Replacement algorithm  : " << c.cacheAlgo << "   (" << c.frames << " frames)\n";
    o << "  Total cache accesses   : " << acc << "\n";
    o << "  Cache hits             : " << cacheHits_ << "\n";
    o << "  Cache misses           : " << cacheMisses_ << "\n";
    o << std::fixed << std::setprecision(2);
    o << "  Hit ratio              : " << (acc ? 100.0 * cacheHits_ / acc : 0.0) << " %\n";
    o << "  Miss ratio             : " << (acc ? 100.0 * cacheMisses_ / acc : 0.0) << " %\n";
    o << "  Page replacements      : " << replacements_ << "\n";
    o << "  Dirty-page write-backs : " << writeBacks_ << "\n";
    if (!events.empty()) {
        o << "  Recent replacement activity:\n";
        std::size_t shown = 0;
        for (std::size_t i = events.size(); i-- > 0 && shown < 5; ++shown) o << "    " << events[i] << "\n";
    }

    // ------------------------------------------------------------ SYNC
    o << "\n[SYNCHRONIZATION]\n";
    o << "  Producer threads       : " << producers_ << "\n";
    o << "  Worker threads         : " << c.workers << "\n";
    o << "  Completed operations   : " << completed_ << "\n";
    o << "  Queue capacity         : " << c.queueCapacity << "  (max length seen " << maxQueueLen_ << ")\n";
    o << "  Avg time in queue      : "
      << ms(firstDispatches_ ? static_cast<double>(queueWaitTotalUs_) / firstDispatches_ : 0.0) << "\n";
    o << "  Producers blocked (queue full)   : " << producerBlocked_ << "  (sem_wait on 'empty slots')\n";
    o << "  Workers blocked (queue empty)    : " << consumerBlocked_ << "  (sem_wait on 'full slots')\n";
    o << "  Shared (reader) lock acquisitions: " << sharedAcq_ << "\n";
    o << "  Exclusive (writer) acquisitions  : " << exclAcq_ << "\n";
    o << "  Contended acquisitions (had to block): " << contended_ << "\n";
    o << "  Max concurrent readers on a block: " << maxReaders_ << "\n";
    o << "  Multi-lock ops (MSET/LIST, ascending order): " << multiLocks_
      << "  (" << multiLockedBlocks_ << " block locks)\n";
    o << bar << "\n";
    return o.str();
}
