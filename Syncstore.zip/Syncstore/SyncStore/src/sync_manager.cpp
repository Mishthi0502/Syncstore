#include "sync_manager.h"
#include <algorithm>
#include <sstream>

void SyncManager::lockShared(int b) {
    bool contended = false;
    if (!locks_[b].try_lock_shared()) {            // somebody holds it exclusively -> we will block
        contended = true;
        locks_[b].lock_shared();
    }
    int now = ++readers_[b];
    if (writers_[b] != 0) ++violations_;           // a reader must never overlap a writer
    stats_.syncShared(contended);
    stats_.syncReaders(now);
}

void SyncManager::unlockShared(int b) {
    --readers_[b];
    locks_[b].unlock_shared();
}

void SyncManager::lockExclusive(int b) {
    bool contended = false;
    if (!locks_[b].try_lock()) {
        contended = true;
        locks_[b].lock();
    }
    int w = ++writers_[b];
    if (w != 1 || readers_[b] != 0) ++violations_; // a writer must be alone in the block
    stats_.syncExclusive(contended);
}

void SyncManager::unlockExclusive(int b) {
    --writers_[b];
    locks_[b].unlock();
}

std::vector<int> SyncManager::lockAll(std::vector<int> blocks, bool exclusive) {
    std::sort(blocks.begin(), blocks.end());       // global lock order = ascending block number
    blocks.erase(std::unique(blocks.begin(), blocks.end()), blocks.end());
    for (int b : blocks) exclusive ? lockExclusive(b) : lockShared(b);
    stats_.syncMultiLock(blocks.size());
    if (stats_.trace()) {
        std::ostringstream o;
        o << (exclusive ? "exclusive" : "shared") << " locks taken in ascending order:";
        for (int b : blocks) o << ' ' << b;
        stats_.log("SYNC", o.str());
    }
    return blocks;
}

void SyncManager::unlockAll(const std::vector<int>& blocks, bool exclusive) {
    for (auto it = blocks.rbegin(); it != blocks.rend(); ++it)
        exclusive ? unlockExclusive(*it) : unlockShared(*it);
}
