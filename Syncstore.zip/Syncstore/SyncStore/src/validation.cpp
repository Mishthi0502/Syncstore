// validation.cpp - "is any of this real?"
//
// Every subsystem claims something: the CPU scheduler claims requests waited, the buffer
// pool claims it avoided disk reads, the disk scheduler claims a seek distance. A simulator
// can only quote itself. Here each claim is printed next to the number the Linux kernel
// kept independently, so the two can disagree - and when they agree, that agreement is
// evidence rather than assertion.
#include <iomanip>
#include <sstream>
#include "cpu_work.h"
#include "kernel_probe.h"
#include "syncstore.h"

namespace {
std::string bytes(std::uint64_t b) {
    std::ostringstream o;
    o << std::fixed << std::setprecision(1);
    if (b >= 1024ULL * 1024 * 1024) o << (b / 1073741824.0) << " GB";
    else if (b >= 1024ULL * 1024)   o << (b / 1048576.0) << " MB";
    else if (b >= 1024)             o << (b / 1024.0) << " KB";
    else                            o << b << " B";
    return o.str();
}
std::string ms(std::uint64_t ns) {
    std::ostringstream o;
    o << std::fixed << std::setprecision(1) << (ns / 1000000.0) << " ms";
    return o.str();
}
}  // namespace

WorkerSchedSummary SyncStore::workerSched() const {
    WorkerSchedSummary w;
    std::lock_guard<std::mutex> lk(workerInfoMtx_);
    for (const WorkerInfo& wi : workerInfo_) {
        ThreadSched now = KernelProbe::threadSched(wi.tid);
        if (!now.ok) continue;
        w.ok = true;
        ++w.threads;
        if (now.cpuRunNs >= wi.base.cpuRunNs) w.cpuRunNs += now.cpuRunNs - wi.base.cpuRunNs;
        if (now.runqueueWaitNs >= wi.base.runqueueWaitNs)
            w.runqueueWaitNs += now.runqueueWaitNs - wi.base.runqueueWaitNs;
        if (now.timeslices >= wi.base.timeslices) w.timeslices += now.timeslices - wi.base.timeslices;
    }
    return w;
}

std::string SyncStore::environmentReport() const {
    std::ostringstream o;
    const PhysicalMap& m = file_->map();

    o << "[WHAT IS REAL IN THIS RUN]\n";
    o << "  Data file      : " << file_->path() << "  (" << (NUM_BLOCKS * BLOCK_SIZE / 1024)
      << " KB, " << NUM_BLOCKS << " blocks of " << BLOCK_SIZE << " B)\n";
    o << "  Device         : /dev/" << (file_->device().empty() ? "?" : file_->device())
      << "   kernel calls it " << (file_->rotational() ? "rotational (seeks cost time)"
                                                       : "non-rotational (SSD/virtual)") << "\n";
    o << "  I/O mode       : " << file_->ioMode() << "\n";
    o << "  Physical layout: ";
    if (m.ready())
        o << m.extentCount() << " extents, " << m.backwardJumps() << " backward jump(s), physical blocks "
          << m.minPhysical() << ".." << m.maxPhysical() << "\n";
    else
        o << "unavailable (" << m.error() << ")\n";
    o << "  Disk head moves over: " << disk_->addressingDescription() << "\n";
    o << "  CPU bursts     : ";
    if (cfg_.realWork)
        o << "real computation - 1 burst unit = " << std::fixed << std::setprecision(1)
          << CpuWork::measuredUnitUs() << " us of measured CPU time ("
          << CpuWork::iterationsPerUnit() << " iterations)\n";
    else
        o << "sleep() of " << cfg_.cpuUnitUs << " us per unit (MODELLED - thread is blocked, not runnable)\n";
    o << "  Kernel policy  : " << CpuWork::describeCurrentPolicy()
      << "   |  " << cfg_.workers << " worker threads on " << CpuWork::cpuCount() << " core(s)"
      << (cfg_.pinWorkers ? ", pinned" : "") << "\n";
    if (!policyNote_.empty()) o << "                   note: " << policyNote_ << "\n";
    o << "  Durability     : " << (cfg_.wal ? "write-ahead log, fsync on commit, replay at start-up"
                                            : "write-back only (no WAL)") << "\n";
    o << "  " << KernelProbe::capabilityLine() << "\n";
    return o.str();
}

std::string SyncStore::validationReport() const {
    std::ostringstream o;
    KernelSnapshot now = KernelProbe::snapshot();
    KernelSnapshot d = KernelProbe::delta(startSnap_, now);
    WorkerSchedSummary w = workerSched();

    o << "\n================ MODEL  vs  KERNEL ================\n";
    o << "Left column: what SyncStore measured itself.\n"
         "Right column: what Linux recorded about this process, independently.\n";

    // ---------------- CPU ----------------
    o << "\n[CPU SCHEDULING]\n";
    o << "  ours   : " << stats_.completed() << " requests, avg waiting "
      << std::fixed << std::setprecision(3) << (stats_.avgWaitUs() / 1000.0) << " ms, avg turnaround "
      << (stats_.avgTurnaroundUs() / 1000.0) << " ms\n";
    o << "  ours   : " << stats_.preemptions() << " preemptions (our quantum expiring)\n";
    if (w.ok) {
        o << "  kernel : worker threads ran " << ms(w.cpuRunNs) << " on a CPU and waited "
          << ms(w.runqueueWaitNs) << " on the run queue, over " << w.timeslices << " timeslices\n";
        o << "           (per-thread /proc/self/task/<tid>/schedstat, " << w.threads << " threads)\n";
        if (w.cpuRunNs + w.runqueueWaitNs > 0) {
            double pct = 100.0 * static_cast<double>(w.runqueueWaitNs) /
                         static_cast<double>(w.cpuRunNs + w.runqueueWaitNs);
            o << "           workers spent " << std::setprecision(1) << pct
              << " % of their runnable time waiting for a core";
            if (cfg_.workers > CpuWork::cpuCount())
                o << " (" << cfg_.workers << " workers > " << CpuWork::cpuCount() << " cores, as expected)";
            o << "\n";
        }
    } else {
        o << "  kernel : per-thread schedstat unavailable (CONFIG_SCHEDSTATS off)\n";
    }
    if (d.statusOk)
        o << "  kernel : " << d.nonvolCtxt << " involuntary context switches (the kernel preempting us), "
          << d.volCtxt << " voluntary (us blocking)\n";
    o << "  kernel : CPU time consumed - user " << ms(d.utimeUs * 1000) << ", system " << ms(d.stimeUs * 1000) << "\n";
    if (!cfg_.realWork)
        o << "  WARNING: bursts are sleep()-based in this run, so the kernel numbers above stay near zero.\n";

    // ---------------- Disk ----------------
    o << "\n[DISK SCHEDULING]\n";
    o << "  ours   : " << stats_.diskAccesses() << " block accesses, total head movement "
      << stats_.totalSeek() << " blocks = "
      << bytes(static_cast<std::uint64_t>(stats_.totalSeek() > 0 ? stats_.totalSeek() : 0) * BLOCK_SIZE)
      << " of travel (" << (disk_->physicalMode() ? "real device addresses" : "logical model") << ")\n";
    if (stats_.seekExecuted() || stats_.seekOtherModel()) {
        o << "  ours   : the same batches costed in the other address space would be "
          << stats_.seekOtherModel() << " blocks = "
          << bytes(static_cast<std::uint64_t>(stats_.seekOtherModel() > 0 ? stats_.seekOtherModel() : 0) * BLOCK_SIZE)
          << "\n";
        o << "           -> " << (disk_->physicalMode()
                ? "a simulator scheduling on logical block numbers would report that smaller figure "
                  "and pick a different service order; the device does not agree with it.\n"
                : "this is the figure a simulator reports; the real layout costs the other one.\n");
    }
    if (d.ioOk) {
        // Compare against the reads our disk layer really issued, not against misses:
        // a full-block overwrite allocates a frame without fetching the old contents,
        // so it is a miss that performs no read at all.
        const std::uint64_t expectRead = stats_.diskReads() * static_cast<std::uint64_t>(BLOCK_SIZE);
        o << "  kernel : this process pulled " << bytes(d.readBytes) << " from the device and pushed "
          << bytes(d.writeBytes) << " to it (/proc/self/io)\n";
        o << "  check  : we issued " << stats_.diskReads() << " block reads = " << bytes(expectRead)
          << "; the device moved " << bytes(d.readBytes);
        if (expectRead > 0) {
            double ratio = static_cast<double>(d.readBytes) / static_cast<double>(expectRead);
            o << "  (ratio " << std::setprecision(2) << ratio << ")\n";
            if (ratio > 0.75 && ratio < 1.6)
                o << "           ratio near 1 => the page cache is NOT serving these reads; O_DIRECT is real.\n"
                     "           (slightly under 1 is normal: a read of a never-written extent is\n"
                     "            answered with zeros by the filesystem without touching the device.)\n";
            else if (ratio < 0.4)
                o << "           ratio well under 1 => reads are being served from the page cache,\n"
                     "           not the device. Check whether O_DIRECT was refused above.\n";
        } else {
            o << "\n";
        }
    }
    if (d.diskOk)
        o << "  kernel : device " << KernelProbe::device() << " completed " << d.devReads << " reads and "
          << d.devWrites << " writes (" << d.devSectorsRead << " + " << d.devSectorsWritten
          << " sectors), busy " << d.devIoTicksMs << " ms (/proc/diskstats)\n";

    // ---------------- Memory ----------------
    o << "\n[MEMORY MANAGEMENT]\n";
    const std::uint64_t acc = stats_.cacheHits() + stats_.cacheMisses();
    o << "  ours   : " << acc << " page accesses, " << stats_.cacheHits() << " hits, "
      << stats_.cacheMisses() << " misses, " << stats_.replacements() << " replacements, "
      << stats_.writeBacks() << " dirty write-backs\n";
    if (acc)
        o << "  ours   : hit ratio " << std::setprecision(2)
          << (100.0 * static_cast<double>(stats_.cacheHits()) / static_cast<double>(acc)) << " %\n";
    o << "  kernel : " << d.minFaults << " minor page faults, " << d.majFaults
      << " major page faults (getrusage)\n";
    if (d.memOk)
        o << "  kernel : " << bytes(d.memAvailableKb * 1024) << " of " << bytes(d.memTotalKb * 1024)
          << " memory available on this machine (/proc/meminfo)\n";

    o << "\n  Reading this: the left column is our bookkeeping, the right is the kernel's.\n"
         "  They are collected by different code paths, so matching numbers mean the\n"
         "  mechanism really ran; a mismatch is a bug worth explaining.\n";
    o << "===================================================\n";
    return o.str();
}
