// physical_map.h - where our blocks REALLY live on the storage device.
//
// A simulator invents a disk head position. We ask the kernel instead:
// the FIEMAP ioctl (FS_IOC_FIEMAP) returns the extents of data.db, i.e. the real
// physical block addresses the filesystem gave our file. The disk scheduler then
// orders requests by those real addresses, not by our logical block numbers.
//
// Because the filesystem is free to scatter a file, logical order and physical order
// are genuinely different - a file can have logical block 16 at a LOWER physical
// address than logical block 0. That difference is measurable, and it is the reason
// disk-head scheduling still matters.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct Extent {
    std::uint64_t logicalBlock = 0;    // first logical block (in BLOCK_SIZE units) of this extent
    std::uint64_t physicalBlock = 0;   // its physical block on the device
    std::uint64_t lengthBlocks = 0;
};

class PhysicalMap {
public:
    // Reads the real layout of an open file. Returns false if the filesystem
    // does not support FIEMAP (then the caller stays in logical mode).
    bool build(int fd, std::uint64_t blockSize, int numBlocks);

    bool ready() const { return ready_; }
    const std::string& error() const { return error_; }

    // Real physical block of a logical block, or -1 if it is not mapped (sparse hole).
    long long physicalBlock(int logicalBlock) const;

    const std::vector<Extent>& extents() const { return extents_; }
    std::size_t extentCount() const { return extents_.size(); }

    // How scattered the file is: extents, and how often the physical address goes
    // backwards as the logical address goes forwards.
    int backwardJumps() const;
    std::uint64_t physicalSpanBlocks() const;   // highest - lowest physical block used
    long long minPhysical() const { return minPhys_; }
    long long maxPhysical() const { return maxPhys_; }

    // Device that holds the file: "vda", "sda", ... and whether the kernel calls it rotational.
    static std::string deviceOfPath(const std::string& path);
    static bool deviceIsRotational(const std::string& device);
    static std::uint64_t deviceSizeSectors(const std::string& device);

    // Create a deliberately fragmented file, the way a real database file ages on a busy
    // filesystem: write a chunk of the data file, then a chunk of a filler file, repeat,
    // fsync-ing so the allocator cannot merge them. The filler is deleted afterwards.
    // Returns the number of extents the file ended up with.
    static int createFragmented(const std::string& path, std::uint64_t blockSize, int numBlocks,
                                std::string& error);

    std::string describe(int numBlocks) const;

private:
    bool ready_ = false;
    std::string error_;
    std::vector<Extent> extents_;
    long long minPhys_ = -1, maxPhys_ = -1;
};
