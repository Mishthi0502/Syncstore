// command_parser.h - turns a text line ("SET name Alice") into a validated command.
#pragma once
#include <string>
#include <vector>
#include "request.h"

struct ParsedCommand {
    CmdType type = CmdType::HELP;
    std::vector<KeyValue> pairs;
};

// Returns false and fills 'error' when the line is invalid.
bool parseCommand(const std::string& line, ParsedCommand& out, std::string& error);
