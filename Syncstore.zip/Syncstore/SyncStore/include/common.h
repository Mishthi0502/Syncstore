// common.h - constants and tiny helpers shared by every module.
#pragma once
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <string>

// ---- Disk geometry ----
// BLOCK_SIZE is 4096 on purpose: it is the page size, the ext4 block size and the
// alignment O_DIRECT demands. One block = one page = one filesystem block, so the
// "page" the buffer pool manages and the "block" the disk scheduler moves are the
// same real object the kernel works with.
constexpr int BLOCK_SIZE = 4096;
constexpr int NUM_BLOCKS = 200;          // data.db is 200 * 4 KB = 800 KB
constexpr std::size_t MAX_KEY_LEN = 32;
constexpr std::size_t MAX_VALUE_LEN = 3900;   // header + key + value must fit one block

using BlockData = std::array<char, BLOCK_SIZE>;

// Monotonic microsecond clock used for all waiting/turnaround measurements.
inline std::uint64_t nowUs() {
    using namespace std::chrono;
    return duration_cast<microseconds>(steady_clock::now().time_since_epoch()).count();
}
