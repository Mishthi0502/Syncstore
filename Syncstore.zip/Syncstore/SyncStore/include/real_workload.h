// real_workload.h - a workload that is not invented by the program.
//
// The honest criticism of any OS lab project is that its "processes" are made up: a table
// of bursts and priorities that exists only to be sorted. Sorting a table proves nothing.
//
// This module removes the invention. SyncStore ingests REAL files from the disk, splits
// them into records, stores them through the full pipeline (queue -> CPU scheduler ->
// locks -> write-ahead log -> buffer pool -> disk scheduler), then reads them back and
// compares a CRC-32 of the reassembled bytes against a CRC-32 of the original file.
//
// Two things follow that a simulator cannot claim:
//   * Correctness is externally checkable. If the locking, the write-back ordering or the
//     recovery is wrong, the checksum fails and the program says so. A simulator has
//     nothing to be wrong about.
//   * The manifest is stored in SyncStore too, so a later run can verify the data against
//     the original files WITHOUT being told what it stored - across process restarts.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

class SyncStore;

struct IngestResult {
    int filesStored = 0;
    int filesSkipped = 0;        // did not fit in the remaining blocks
    int chunks = 0;
    std::uint64_t bytes = 0;
    double elapsedMs = 0;
    std::uint64_t deviceWriteBytes = 0;   // what the kernel says actually went to the device
    std::string note;
};

struct VerifyResult {
    int filesChecked = 0;
    int filesOk = 0;
    int filesCorrupt = 0;        // what came out does not match what we stored -> a real bug
    int filesMissing = 0;
    int filesChanged = 0;        // intact, but the original file was edited after ingestion
    std::uint64_t bytes = 0;
    double elapsedMs = 0;
    std::uint64_t deviceReadBytes = 0;
    std::vector<std::string> failures;
};

// One row of the policy comparison: the SAME real verification pass, run under a
// different scheduling / replacement choice, timed on the wall clock.
struct PolicyRow {
    std::string cacheAlgo, diskAlgo;
    double elapsedMs = 0;
    std::uint64_t deviceReadBytes = 0;
    std::uint64_t cacheHits = 0, cacheMisses = 0;
    long long seek = 0;
    bool ok = false;
};

// Store every regular file under `dir` (recursively, up to maxFiles) into the store.
IngestResult ingestDirectory(SyncStore& store, const std::string& dir, int maxFiles);

// Read everything back out of the store and check it against the files still on disk.
VerifyResult verifyAgainstDisk(SyncStore& store);

// Run the same real verification pass under every cache/disk policy combination.
std::vector<PolicyRow> comparePolicies(SyncStore& store);
