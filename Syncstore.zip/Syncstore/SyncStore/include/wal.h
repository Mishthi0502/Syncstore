// wal.h - write-ahead log: the part of the system that survives the power going out.
//
// The buffer pool is write-back, so a committed SET may live only in memory for a long
// time. That is fast but it loses data on a crash. The fix is the rule every real database
// obeys: the change goes into the log and the log is forced to the device BEFORE the page
// is allowed to reach the data file. Redo records are after-images, so recovery is simply
// "replay what the log remembers".
//
// Nothing here is modelled. fsync() really blocks until the device acknowledges, the cost
// of that is measured, and the recovery path is exercised by killing the process with
// SIGKILL - the kernel gives it no chance to clean up, exactly like a power cut.
#pragma once
#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include "block_file.h"
#include "common.h"

struct WalStats {
    std::uint64_t appends = 0;        // redo records written
    std::uint64_t commits = 0;        // fsync calls on the log
    std::uint64_t bytes = 0;          // bytes appended
    std::uint64_t fsyncNs = 0;        // real time spent waiting for the device
    std::uint64_t checkpoints = 0;
    std::uint64_t replayed = 0;       // records re-applied by the last recovery
    std::uint64_t truncatedTail = 0;  // bytes of torn/partial tail discarded at recovery
};

class Wal {
public:
    Wal(const std::string& path, bool enabled);
    ~Wal();
    Wal(const Wal&) = delete;
    Wal& operator=(const Wal&) = delete;

    bool enabled() const { return enabled_; }
    const std::string& path() const { return path_; }

    // Write-ahead: append the after-image of `block` and force it to the device.
    // Returns the LSN. Must be called BEFORE the page is handed to the buffer pool.
    std::uint64_t logWrite(int block, const BlockData& after);

    // All dirty pages are now on the data file, so the log can start again from empty.
    void checkpoint();

    WalStats stats() const;
    void resetStats();

    // Replay a log over a data file at start-up. Safe to call when no log exists.
    // Returns the number of records re-applied; `summary` describes what happened.
    static int recover(const std::string& walPath, BlockFile& file, std::string& summary,
                       std::uint64_t* truncatedTail = nullptr);

    // Average cost of one durable commit on this machine, in microseconds.
    double avgCommitUs() const;

private:
    void openLog();

    bool enabled_;
    std::string path_;
    int fd_ = -1;
    std::atomic<std::uint64_t> lsn_{1};
    mutable std::mutex mtx_;
    WalStats st_;
};
