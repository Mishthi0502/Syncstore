// request_queue.h - bounded producer-consumer queue (classic semaphore solution).
//
//   producers:  sem_wait(emptySlots) -> lock -> insert -> unlock -> sem_post(fullSlots)
//   workers  :  sem_wait(fullSlots)  -> lock -> CPU scheduler picks one -> unlock
//   finished :  sem_post(emptySlots)
//
// 'capacity' bounds the number of admitted-but-unfinished requests, so a request that
// is preempted (Round Robin) can always go back into the queue without waiting.
#pragma once
#include <semaphore.h>
#include <condition_variable>
#include <deque>
#include <mutex>
#include "cpu_scheduler.h"
#include "request.h"
#include "statistics.h"

class RequestQueue {
public:
    RequestQueue(std::size_t capacity, CpuScheduler& sched, Statistics& stats);
    ~RequestQueue();
    RequestQueue(const RequestQueue&) = delete;
    RequestQueue& operator=(const RequestQueue&) = delete;

    void push(RequestPtr r);        // producer side; blocks while the queue is full
    RequestPtr pop();               // consumer side; blocks while empty; nullptr after shutdown
    void requeue(RequestPtr r);     // preempted request returns to the tail (keeps its slot)
    void complete();                // request finished -> free its slot

    void pause();                   // workers stop taking requests (used to build a batch)
    void resume();
    void waitUntilIdle();           // returns when every admitted request has completed
    void shutdown(int workers);     // wakes 'workers' blocked consumers so they can exit

    std::size_t size() const;
    std::size_t capacity() const { return capacity_; }

private:
    const std::size_t capacity_;
    CpuScheduler& sched_;
    Statistics& stats_;
    sem_t emptySlots_;
    sem_t fullSlots_;
    mutable std::mutex mtx_;
    std::condition_variable gateCv_, idleCv_;
    std::deque<RequestPtr> ready_;
    bool paused_ = false;
    bool stopping_ = false;
    std::size_t outstanding_ = 0;
};
