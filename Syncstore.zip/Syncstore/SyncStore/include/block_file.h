// block_file.h - the real file data.db, accessed in fixed-size blocks.
//
// Two things make this real rather than simulated:
//
//  1. O_DIRECT. Without it every read would be served by the kernel's page cache and
//     our buffer pool would be a cache in front of a cache - the replacement policy
//     would change nothing measurable. With O_DIRECT the kernel keeps no copy, so a
//     buffer-pool miss is a true device access. /proc/self/io read_bytes proves it.
//
//  2. The physical map (FIEMAP), so the disk scheduler can order requests by the real
//     addresses the filesystem assigned, not by our own logical numbering.
#pragma once
#include <cstdint>
#include <string>
#include "common.h"
#include "physical_map.h"

class BlockFile {
public:
    struct Options {
        bool direct = true;        // O_DIRECT: bypass the page cache
        bool fragment = false;     // lay a new file out in several extents (realistic ageing)
        bool mapPhysical = true;   // run FIEMAP and keep the real layout
    };

    BlockFile(const std::string& path, const Options& opt);
    explicit BlockFile(const std::string& path) : BlockFile(path, Options{}) {}
    ~BlockFile();
    BlockFile(const BlockFile&) = delete;
    BlockFile& operator=(const BlockFile&) = delete;

    void readBlock(int block, BlockData& out);
    void writeBlock(int block, const BlockData& in);
    void sync();                                   // fsync: force data to the device
    void syncData();                               // fdatasync: data only, no metadata

    const std::string& path() const { return path_; }
    bool directIo() const { return direct_; }
    const std::string& ioMode() const { return ioMode_; }      // "O_DIRECT" or why it fell back
    const PhysicalMap& map() const { return map_; }
    const std::string& device() const { return device_; }
    bool rotational() const { return rotational_; }
    bool createdNow() const { return created_; }

    // Re-rSead the extent map (after the file has been grown or rewritten).
    void remapPhysical();

private:
    void openFile(bool wantDirect);

    int fd_ = -1;
    std::string path_;
    bool direct_ = false;
    bool created_ = false;
    bool rotational_ = false;
    std::string ioMode_, device_;
    PhysicalMap map_;
};
