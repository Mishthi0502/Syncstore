// ipc.h - real processes instead of pretend users.
//
// The thread-based workload simulator shares one address space: a "user" there is just
// another thread, and std::mutex is enough to keep them apart. That is the part of the
// original design that was closest to a simulation of multi-user access.
//
// This module replaces it with the real thing:
//   * POSIX shared memory (shm_open + mmap) holds a bounded ring of request slots -
//     the only memory the processes have in common;
//   * POSIX semaphores created with pshared=1 live INSIDE that shared memory, so the
//     producer-consumer handshake crosses process boundaries, not thread boundaries;
//   * clients are separate processes created with fork(), with their own page tables,
//     their own file descriptors and their own scheduling entities;
//   * each slot carries its own completion semaphore so a client blocks until its own
//     reply is ready, instead of polling.
//
// Nothing here can be done with std::mutex or std::condition_variable: those only
// synchronise threads of one process.
#pragma once
#include <semaphore.h>
#include <cstdint>
#include <string>
#include <vector>

class SyncStore;

constexpr int IPC_SLOTS = 64;
constexpr int IPC_CMD_LEN = 240;
constexpr int IPC_REPLY_LEN = 480;

struct IpcSlot {
    sem_t done;                      // posted by the server when this request is answered
    char cmd[IPC_CMD_LEN];
    char reply[IPC_REPLY_LEN];
    int ok;
    int clientPid;
    std::uint64_t submitUs, finishUs;
};

struct IpcRegion {
    // The classic bounded buffer, but the semaphores are process-shared.
    sem_t emptySlots;                // free slots available to clients
    sem_t fullSlots;                 // requests waiting for the server
    sem_t mutex;                     // protects the ring and the free list
    int ring[IPC_SLOTS];             // indices of slots holding a pending request
    int head, tail, count;
    int freeList[IPC_SLOTS];         // indices of slots nobody owns
    int freeTop;
    volatile int stop;

    // counters every process updates under `mutex`
    std::uint64_t submitted, served, clientBlocked, serverBlocked;
    std::uint64_t totalLatencyUs;

    IpcSlot slots[IPC_SLOTS];
};

struct IpcResult {
    int clients = 0;
    int requestsPerClient = 0;
    int served = 0;
    int failed = 0;
    double elapsedMs = 0;
    double avgLatencyMs = 0;
    std::uint64_t clientBlocked = 0;    // times a client had to wait for a free slot
    std::uint64_t serverBlocked = 0;    // times the server had nothing to do
    std::vector<int> childPids;
    std::string note;
};

class IpcServer {
public:
    IpcServer();
    ~IpcServer();
    IpcServer(const IpcServer&) = delete;
    IpcServer& operator=(const IpcServer&) = delete;

    bool ok() const { return region_ != nullptr; }
    const std::string& error() const { return error_; }

    // Forks `clients` child processes, each sending `perClient` commands through shared
    // memory. The calling process serves them with `store` and waits for every child.
    IpcResult run(SyncStore& store, int clients, int perClient, int serverThreads);

private:
    void serveLoop(SyncStore& store);
    void clientMain(int clientIndex, int perClient);   // runs inside the forked child

    IpcRegion* region_ = nullptr;
    std::string error_;
    std::string shmName_;
};

// Advisory lock on the data file, so two SyncStore processes cannot open the same
// database at once (fcntl F_SETLK - the kernel keeps the lock, and drops it if we die).
class DataFileLock {
public:
    DataFileLock() = default;
    ~DataFileLock();
    bool acquire(const std::string& path, std::string& holderInfo);
    void release();
    bool held() const { return fd_ >= 0; }

private:
    int fd_ = -1;
};
