// cpu_scheduler.h - decides WHICH queued request runs next.
#pragma once
#include <atomic>
#include <deque>
#include "request.h"

enum class CpuAlgo { FCFS, SJF, PRIORITY, RR };
const char* toString(CpuAlgo a);

class CpuScheduler {
public:
    void setAlgorithm(CpuAlgo a) { algo_ = a; }
    CpuAlgo algorithm() const { return algo_; }
    void setQuantum(int q) { quantum_ = q < 1 ? 1 : q; }
    int quantum() const { return quantum_; }

    // Returns the index (inside the ready queue) of the request that must run next.
    // The queue is only ever touched while the queue mutex is held by the caller.
    //  FCFS     : earliest arrival (smallest id)
    //  SJF      : smallest remaining burst (non-preemptive: remaining == burst)
    //  PRIORITY : smallest priority number (ties -> earliest arrival)
    //  RR       : head of queue (preempted requests are re-queued at the tail)
    std::size_t selectNext(const std::deque<RequestPtr>& ready) const;

    // How many burst units the chosen request may run before the CPU is taken away.
    int sliceFor(const Request& r) const;

private:
    std::atomic<CpuAlgo> algo_{CpuAlgo::FCFS};
    std::atomic<int> quantum_{2};
};
