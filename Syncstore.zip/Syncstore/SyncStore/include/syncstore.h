// syncstore.h - wires every module together into one running system.
//
//  CLI/producers -> parser -> RequestQueue(bounded, semaphores) -> CpuScheduler picks ->
//  worker thread -> StorageEngine -> lock manager -> BufferPool -> DiskScheduler -> BlockFile
#pragma once
#include <atomic>
#include <memory>
#include <string>
#include <thread>
#include <mutex>
#include <vector>
#include "block_file.h"
#include "buffer_pool.h"
#include "cpu_scheduler.h"
#include "cpu_work.h"
#include "kernel_probe.h"
#include "disk_scheduler.h"
#include "request_queue.h"
#include "statistics.h"
#include "storage_engine.h"
#include "sync_manager.h"
#include "wal.h"

struct Config {
    std::string dbPath = "data/data.db";
    int workers = 4;                  // worker thread pool size
    std::size_t frames = 8;           // buffer pool size (frames)
    int quantum = 2;                  // Round Robin time quantum (burst units)
    int cpuUnitUs = 300;              // real CPU time one burst unit must consume
    std::size_t queueCapacity = 16;   // bounded queue size

    // ---- real-system switches (all default to the real behaviour) ----
    bool realWork = true;             // genuine computation per burst unit instead of sleep()
    bool directIo = true;             // O_DIRECT: a cache miss is a real device access
    bool physicalDisk = true;         // schedule on real device addresses (FIEMAP)
    bool fragmentNewDb = true;        // lay a fresh data.db out in several extents
    bool wal = true;                  // write-ahead log + crash recovery
    KernelPolicy kernelPolicy = KernelPolicy::OTHER;   // hand FCFS/RR to the kernel itself
    int rtPriority = 1;
    bool pinWorkers = false;          // one worker per core via sched_setaffinity
};

// What the kernel reported about the worker threads themselves.
struct WorkerSchedSummary {
    bool ok = false;
    int threads = 0;
    std::uint64_t cpuRunNs = 0;       // time workers really spent on a CPU
    std::uint64_t runqueueWaitNs = 0; // time workers were RUNNABLE but had no core
    std::uint64_t timeslices = 0;     // timeslices the kernel handed them
};

struct WorkloadResult {
    int producers = 0;
    int totalRequests = 0;
    int succeeded = 0;                // requests that returned ok
    int notFound = 0;                 // GET/DEL of missing keys etc. (still completed normally)
    double elapsedMs = 0;
};

class SyncStore {
public:
    explicit SyncStore(const Config& cfg);   // throws std::runtime_error if data.db cannot be opened
    ~SyncStore();
    SyncStore(const SyncStore&) = delete;
    SyncStore& operator=(const SyncStore&) = delete;

    // ---- runtime configuration (call while the system is idle) ----
    void setCpuAlgorithm(CpuAlgo a) { cpu_.setAlgorithm(a); }
    void setDiskAlgorithm(DiskAlgo a) { disk_->setAlgorithm(a); }
    void setReplacementPolicy(ReplacementPolicy p) { pool_->setPolicy(p); }
    void setQuantum(int q) { cpu_.setQuantum(q); cfg_.quantum = cpu_.quantum(); }
    void setWorkers(int n);
    void setBufferFrames(std::size_t n);
    void setTrace(bool on) { stats_.setTrace(on); }
    void setKernelPolicy(KernelPolicy p, int rtPriority);   // restarts the worker pool
    void setPinWorkers(bool on);                            // restarts the worker pool
    bool setPhysicalDisk(bool on);                          // false if FIEMAP is unavailable

    // ---- execution ----
    RequestPtr makeRequest(CmdType type, std::vector<KeyValue> pairs, int producerId = 0) const;
    void submit(RequestPtr r);                       // assigns id + arrival time, enters the bounded queue
    RequestPtr submitLine(const std::string& line, int producerId, std::string& error);   // parse + submit
    void waitIdle() { queue_->waitUntilIdle(); }
    void pauseDispatch() { queue_->pause(); }
    void resumeDispatch() { queue_->resume(); }
    void flush();                                    // write all dirty blocks to disk
    void resetBaseline();                            // reset our stats AND the kernel baseline together

    WorkloadResult runWorkload(int producers, int requestsPerProducer);

    // ---- information ----
    std::string statsReport() const;
    std::string describeStorage() { return storage_->describeStorage(); }
    Statistics& stats() { return stats_; }
    WorkerSchedSummary workerSched() const;        // real per-thread numbers from /proc
    std::string environmentReport() const;         // what is real vs modelled in this run
    std::string validationReport() const;          // our model next to the kernel's counters
    const KernelSnapshot& startSnapshot() const { return startSnap_; }
    const Config& config() const { return cfg_; }
    Wal& wal() { return *wal_; }
    const std::string& recoveryNote() const { return recoveryNote_; }
    int recoveredRecords() const { return recoveredRecords_; }
    CpuScheduler& cpu() { return cpu_; }
    DiskScheduler& disk() { return *disk_; }
    BufferPool& pool() { return *pool_; }
    SyncManager& sync() { return *sync_; }
    StorageEngine& storage() { return *storage_; }
    BlockFile& file() { return *file_; }
    const PhysicalMap& diskFileMap() const { return file_->map(); }

private:
    void startWorkers();
    void stopWorkers();
    void workerLoop();
    Response runCommand(const Request& r);

    Config cfg_;
    Statistics stats_;
    CpuScheduler cpu_;
    std::unique_ptr<BlockFile> file_;
    std::unique_ptr<DiskScheduler> disk_;
    std::unique_ptr<BufferPool> pool_;
    std::unique_ptr<SyncManager> sync_;
    std::unique_ptr<StorageEngine> storage_;
    std::unique_ptr<Wal> wal_;
    std::unique_ptr<RequestQueue> queue_;
    std::string walPath_, recoveryNote_;
    int recoveredRecords_ = 0;
    std::vector<std::thread> workers_;
    std::atomic<std::uint64_t> nextId_{1};
    std::atomic<std::uint64_t> workSink_{0};       // keeps the real work from being optimised away

    struct WorkerInfo { long tid = 0; ThreadSched base; };
    mutable std::mutex workerInfoMtx_;
    std::vector<WorkerInfo> workerInfo_;
    KernelSnapshot startSnap_;
    std::string policyNote_;
};
