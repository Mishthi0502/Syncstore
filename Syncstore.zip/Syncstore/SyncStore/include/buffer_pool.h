// buffer_pool.h - fixed-size cache of disk blocks (the "physical memory frames").
// Blocks are the "pages"; FIFO / LRU / Clock decide which frame is the victim.
// Write policy: write-back - a modified block only gets a dirty bit; it is written to
// disk (through the disk scheduler) when evicted or flushed.
#pragma once
#include <condition_variable>
#include <mutex>
#include <unordered_map>
#include <vector>
#include "disk_scheduler.h"
#include "statistics.h"

enum class ReplacementPolicy { FIFO, LRU, CLOCK };
const char* toString(ReplacementPolicy p);

class BufferPool {
public:
    BufferPool(std::size_t frames, ReplacementPolicy policy, DiskScheduler& disk, Statistics& stats);

    void setPolicy(ReplacementPolicy p);
    ReplacementPolicy policy() const;
    void resize(std::size_t frames);               // flushes dirty frames, then rebuilds (call when idle)
    std::size_t frameCount() const;

    void readBlock(int block, BlockData& out);     // hit: copy from frame; miss: load via disk scheduler
    void writeBlock(int block, const BlockData& data);   // whole-block overwrite -> frame becomes dirty
    void flushAll();                               // write every dirty frame back (one disk batch)

    // Diagnostics (no statistics, no disk I/O).
    bool isCached(int block) const;
    bool isDirty(int block) const;
    bool peek(int block, BlockData& out) const;    // copy from cache if present
    std::vector<int> cachedBlocks() const;

private:
    struct Frame {
        int block = -1;
        bool valid = false;
        bool dirty = false;
        bool loading = false;                      // a disk read for this frame is in flight
        bool ref = false;                          // Clock reference bit
        std::uint64_t loadSeq = 0;                 // FIFO: order in which blocks were loaded
        std::uint64_t lastUse = 0;                 // LRU: logical time of last access
        BlockData data{};
    };

    int chooseVictimLocked();                      // -1 if every frame is busy loading
    void touch(Frame& f) { f.lastUse = ++tick_; f.ref = true; }
    void evictLocked(int frameIdx, int forBlock);  // write-back (if dirty) + unmap
    void installLocked(Frame& f, int block) { f.block = block; f.valid = true; f.ref = true; f.loadSeq = ++seq_; f.lastUse = ++tick_; }

    DiskScheduler& disk_;
    Statistics& stats_;
    ReplacementPolicy policy_;
    mutable std::mutex mtx_;
    std::condition_variable cv_;
    std::vector<Frame> frames_;
    std::unordered_map<int, int> table_;           // block number -> frame index
    std::size_t clockHand_ = 0;
    std::uint64_t seq_ = 0, tick_ = 0;
};
