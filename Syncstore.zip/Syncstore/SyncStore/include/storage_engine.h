// storage_engine.h - the key-value engine on top of the block file.
//
// On-disk record (exactly one record per 256-byte block; the key decides the block via a hash):
//   byte 0      : 0xA5 = block in use, 0x00 = free
//   byte 1      : key length
//   bytes 2..3  : value length (little endian)
//   bytes 4..   : key bytes, then value bytes
//
// All block accesses go:  StorageEngine -> lock manager -> BufferPool -> (miss) DiskScheduler -> BlockFile
#pragma once
#include <array>
#include <map>
#include <mutex>
#include <string>
#include <vector>
#include "block_file.h"
#include "buffer_pool.h"
#include "request.h"
#include "statistics.h"
#include "sync_manager.h"
#include "wal.h"

class StorageEngine {
public:
    StorageEngine(BlockFile& file, BufferPool& pool, SyncManager& sync, Statistics& stats,
                  Wal* wal = nullptr);

    Response set(const std::string& key, const std::string& value);
    Response get(const std::string& key);
    Response del(const std::string& key);
    Response mset(const std::vector<KeyValue>& pairs);   // multi-block, deadlock-free (ordered locking)
    Response list();                                     // consistent snapshot (ordered shared locks)

    std::size_t keyCount() const;
    std::string describeStorage();                       // block map for the "View Storage" menu

    // record encoding (public so tests can inspect raw blocks)
    static void encodeRecord(const std::string& key, const std::string& value, BlockData& out);
    static bool decodeRecord(const BlockData& in, std::string& key, std::string& value);

private:
    void rebuildIndex();                                 // boot-time scan of data.db (like fsck/mount)
    int allocateLocked(const std::string& key);          // caller holds indexMutex_
    int resolveForWrite(const std::string& key);         // existing block, or allocate a new one
    bool ownsBlock(const std::string& key, int block);   // does the index still map key -> block?

    // Write-ahead rule: the redo record is forced to the device before the page is
    // handed to the (write-back) buffer pool, so a crash can never lose a committed write.
    void logThenWrite(int block, const BlockData& data);

    BlockFile& file_;
    BufferPool& pool_;
    SyncManager& sync_;
    Statistics& stats_;
    Wal* wal_ = nullptr;

    mutable std::mutex indexMutex_;                      // protects index_ and used_ (NOT block data)
    std::map<std::string, int> index_;                   // key -> block number
    std::array<bool, NUM_BLOCKS> used_{};                // free-block bitmap
};
