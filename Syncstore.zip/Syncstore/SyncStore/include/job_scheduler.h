// job_scheduler.h - CPU scheduling applied to REAL operating-system processes.
//
// Everywhere else in this project a "process" is a request object handled by a worker
// thread. That is defensible, but it is still our own bookkeeping. This module removes
// the last layer of pretence:
//
//   * every job is a real child process created with fork(), with its own PID, its own
//     address space and its own entry in the kernel's run queue - you can watch them in
//     `top` or `ps` while the demo runs;
//   * every job reads a REAL input file and writes a REAL output file you can open;
//   * priorities are applied with setpriority(), so the kernel sees them too;
//   * Round Robin preemption is performed with SIGSTOP and SIGCONT. The kernel genuinely
//     suspends the process mid-computation and genuinely resumes it later. Nothing is
//     re-queued in a model - the process is actually stopped;
//   * CPU time is taken from wait4()'s rusage, i.e. measured by the kernel, not by us.
//
// Burst is estimated from the input file's size. That is an estimate, like every real
// scheduler's, and the report prints the estimate next to the CPU time actually used so
// the two can be compared.
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "cpu_scheduler.h"

enum class JobState { READY, RUNNING, STOPPED, DONE, FAILED };
const char* toString(JobState s);

struct Job {
    int id = 0;
    std::string inputPath, outputPath, name;
    std::uint64_t sizeBytes = 0;

    int burst = 1;              // estimated from file size, in quantum-sized units
    int priority = 1;           // lower = more urgent
    int remaining = 1;

    pid_t pid = -1;
    JobState state = JobState::READY;
    int slices = 0;             // how many times it was given the CPU
    int preemptions = 0;        // how many times the kernel stopped it on our order
    int ranOnCpu = -1;

    std::uint64_t arrivalUs = 0, firstRunUs = 0, finishUs = 0;
    std::uint64_t cpuUsedUs = 0;     // from wait4 rusage: the kernel's own measurement
    std::uint64_t waitUs = 0, turnaroundUs = 0;

    // real results the job produced, read back from its output file
    std::uint64_t wordsCounted = 0;
    std::uint32_t checksum = 0;
};

struct JobRunResult {
    std::string algo;
    int quantumMs = 0, concurrency = 0;
    std::vector<Job> jobs;
    double makespanMs = 0;           // wall time from first start to last finish
    double avgWaitMs = 0, avgTurnaroundMs = 0;
    int preemptions = 0;
    std::uint64_t totalCpuUs = 0;    // summed from the kernel's rusage for every child
    std::uint64_t totalBytes = 0;
    int failed = 0;
};

class JobScheduler {
public:
    // Collect real files to work on. Returns how many jobs were created.
    int addFilesFrom(const std::string& dir, const std::string& outDir, int maxJobs);
    const std::vector<Job>& jobs() const { return jobs_; }
    void setTrace(bool on) { trace_ = on; }
    void setPasses(int p) { passes_ = p < 1 ? 1 : p; }
    int passes() const { return passes_; }

    // Run every job under the chosen policy. Forks real processes.
    JobRunResult run(CpuAlgo algo, int quantumMs, int concurrency);

    // The work a child process performs. Public so the child path stays readable.
    static bool analyseFile(const std::string& in, const std::string& out, int passes);

private:
    std::size_t pickNext(const std::vector<std::size_t>& ready, CpuAlgo algo) const;
    void startOrResume(Job& j, int quantumMs);

    std::vector<Job> jobs_;
    bool trace_ = true;
    int passes_ = 1;
    std::uint64_t t0_ = 0;
};
