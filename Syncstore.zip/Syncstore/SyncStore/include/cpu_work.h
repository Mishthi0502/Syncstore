// cpu_work.h - real CPU work and real kernel scheduling policies.
//
// A simulator represents a CPU burst with sleep(). A sleeping thread is BLOCKED, not
// RUNNABLE, so the kernel never has to schedule anything and no scheduling pressure
// exists. Here a burst unit is actual computation (checksum + sort over a 4 KB page),
// calibrated once at start-up so that one unit costs a known amount of real CPU time,
// measured with CLOCK_THREAD_CPUTIME_ID.
//
// Consequences that a simulator cannot produce:
//   * with more workers than cores the threads genuinely compete, and the kernel's own
//     run-queue wait time (/proc/self/task/<tid>/schedstat field 2) becomes non-zero;
//   * nonvoluntary_ctxt_switches in /proc/self/status counts real preemptions;
//   * our FCFS and Round Robin can be handed to the kernel as SCHED_FIFO and SCHED_RR,
//     so the policy is enforced by Linux, not imitated by us.
#pragma once
#include <cstdint>
#include <string>

enum class KernelPolicy {
    OTHER,     // SCHED_OTHER (CFS) + nice values - always available
    FIFO,      // SCHED_FIFO  - real first-in-first-out, needs privileges
    RR         // SCHED_RR    - real round robin with the kernel's own quantum
};
const char* toString(KernelPolicy p);

class CpuWork {
public:
    // ---- real work ----
    // Finds how many iterations of the work kernel cost targetUs of real CPU time.
    static void calibrate(int targetUsPerUnit);
    static std::uint64_t iterationsPerUnit();
    static double measuredUnitUs();                 // what one unit really cost when calibrated
    // Executes `units` burst units of genuine computation. Returns a checksum so the
    // optimiser cannot remove it. Reports the real CPU nanoseconds it consumed.
    static std::uint64_t burn(int units, std::uint64_t& cpuNsOut);

    // ---- real kernel scheduling ----
    static bool policyAvailable(KernelPolicy p);
    // Applies the policy to the CALLING thread. rtPriority is used for FIFO/RR (1..99),
    // niceValue for OTHER (-20..19). Returns false and fills err when the kernel refuses.
    static bool applyPolicy(KernelPolicy p, int rtPriority, int niceValue, std::string& err);
    static KernelPolicy currentPolicy();
    static std::string describeCurrentPolicy();
    static std::uint64_t kernelRrQuantumNs();       // sched_rr_get_interval for this thread

    // ---- CPU topology ----
    static int cpuCount();
    static int currentCpu();                        // which core is running this thread now
    static bool pinToCpu(int cpu);                  // sched_setaffinity
    static bool unpin();
    static std::string affinityDescription();
};
