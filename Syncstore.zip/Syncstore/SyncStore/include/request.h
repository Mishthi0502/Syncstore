// request.h - a storage request = the "process" that the CPU scheduler schedules.
#pragma once
#include <cstdint>
#include <future>
#include <memory>
#include <string>
#include <utility>
#include <vector>

enum class CmdType { SET, GET, DEL, LIST, MSET, STATS, FLUSH, HELP };

inline const char* toString(CmdType t) {
    switch (t) {
        case CmdType::SET:   return "SET";
        case CmdType::GET:   return "GET";
        case CmdType::DEL:   return "DEL";
        case CmdType::LIST:  return "LIST";
        case CmdType::MSET:  return "MSET";
        case CmdType::STATS: return "STATS";
        case CmdType::FLUSH: return "FLUSH";
        case CmdType::HELP:  return "HELP";
    }
    return "?";
}

struct Response {
    bool ok = true;
    std::string text;
};

using KeyValue = std::pair<std::string, std::string>;

// Estimated CPU burst (in abstract "time units") - needed by SJF and Round Robin.
// A burst unit is turned into real service time by the worker (see SyncStore::workerLoop).
inline int defaultBurst(CmdType t, std::size_t nPairs) {
    switch (t) {
        case CmdType::GET:  return 1;
        case CmdType::DEL:  return 2;
        case CmdType::SET:  return 3;
        case CmdType::MSET: return 2 + 2 * static_cast<int>(nPairs);
        case CmdType::LIST: return 6;
        default:            return 1;
    }
}

// Priority: LOWER number = HIGHER priority (like UNIX nice values).
inline int defaultPriority(CmdType t) {
    switch (t) {
        case CmdType::GET:  return 1;   // interactive reads first
        case CmdType::SET:  return 2;
        case CmdType::DEL:  return 2;
        case CmdType::MSET: return 3;
        case CmdType::LIST: return 4;   // big scans last
        default:            return 1;
    }
}

struct Request {
    std::uint64_t id = 0;                 // assigned at submission (arrival order)
    CmdType type = CmdType::GET;
    std::vector<KeyValue> pairs;          // SET/MSET: key+value, GET/DEL: key only
    int producerId = 0;                   // which producer thread ("user") created it

    // --- CPU-scheduling attributes (the PCB of this "process") ---
    int burst = 1;                        // estimated total burst
    int priority = 1;
    int remaining = 1;                    // remaining burst (shrinks under Round Robin)

    // --- timing, filled in while the request moves through the system ---
    std::uint64_t arrivalUs = 0;
    std::uint64_t firstDispatchUs = 0;
    std::uint64_t finishUs = 0;
    std::uint64_t serviceUs = 0;          // time actually spent executing
    std::uint64_t waitUs = 0;             // turnaround - service
    std::uint64_t turnaroundUs = 0;       // finish - arrival
    bool started = false;

    // --- measured against the real CPU, not a model ---
    std::uint64_t cpuNs = 0;              // CPU time really consumed (CLOCK_THREAD_CPUTIME_ID)
    int ranOnCpu = -1;                    // core the last slice executed on (sched_getcpu)
    int slices = 0;                       // how many times it was dispatched

    std::promise<Response> promise;       // completed by the worker thread
    std::shared_future<Response> result;
    Request() { result = promise.get_future().share(); }
};
using RequestPtr = std::shared_ptr<Request>;
