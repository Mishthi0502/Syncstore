// sync_manager.h - the lock manager: one readers-writer lock per disk block.
//
//  * many readers may hold a block's lock together (lockShared)
//  * a writer needs exclusive access (lockExclusive)
//  * when an operation needs SEVERAL blocks (MSET, LIST) it must use lockAll(): the blocks
//    are sorted and locked in ASCENDING block order.  A global lock order removes the
//    "circular wait" condition, so two MSETs can never deadlock each other.
#pragma once
#include <array>
#include <atomic>
#include <shared_mutex>
#include <vector>
#include "common.h"
#include "statistics.h"

class SyncManager {
public:
    explicit SyncManager(Statistics& stats) : stats_(stats) {
        for (auto& r : readers_) r = 0;
        for (auto& w : writers_) w = 0;
    }

    void lockShared(int block);
    void unlockShared(int block);
    void lockExclusive(int block);
    void unlockExclusive(int block);

    // Sorts + removes duplicates, then locks in ascending order. Returns the sorted list
    // (pass it to unlockAll). exclusive=false -> shared locks.
    std::vector<int> lockAll(std::vector<int> blocks, bool exclusive);
    void unlockAll(const std::vector<int>& sortedBlocks, bool exclusive);

    // Self-check counters: must stay 0 (a reader and a writer, or two writers, inside the same block).
    long exclusionViolations() const { return violations_; }

private:
    Statistics& stats_;
    std::array<std::shared_mutex, NUM_BLOCKS> locks_;
    std::array<std::atomic<int>, NUM_BLOCKS> readers_;   // threads currently inside as readers
    std::array<std::atomic<int>, NUM_BLOCKS> writers_;   // threads currently inside as writers
    std::atomic<long> violations_{0};
};
