// statistics.h - central, thread-safe collection of every metric shown by STATS.
// Every number printed by STATS is measured while the system runs (nothing is hard-coded).
#pragma once
#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>
#include "common.h"

struct DiskEvent { int block; bool isWrite; };

// Names/settings that the report needs but Statistics itself does not own.
struct StatsContext {
    std::string cpuAlgo, diskAlgo, cacheAlgo;
    int workers = 0, quantum = 0, cpuUnitUs = 0, frames = 0, queueCapacity = 0;
    std::string burstMode;     // how a burst unit is spent (real work or sleep)
    std::string addressing;    // what the disk head moves over
};

class Statistics {
public:
    // ---- live tracing (prints one line per OS event when enabled) ----
    void setTrace(bool on) { trace_ = on; }
    bool trace() const { return trace_; }
    void log(const std::string& tag, const std::string& msg) const;
    void reset();

    // ---- bounded queue / CPU scheduling ----
    void recordEnqueue(std::size_t queueLenAfter);
    void recordProducerBlocked() { ++producerBlocked_; }
    void recordConsumerBlocked() { ++consumerBlocked_; }
    void recordDispatch(std::uint64_t id, bool firstTime, std::uint64_t queueWaitUs);
    void recordPreemption() { ++preemptions_; }
    void recordCompletion(std::uint64_t id, const char* type, int burst,
                          std::uint64_t waitUs, std::uint64_t turnaroundUs);

    // ---- disk scheduling ----
    void recordDiskAccess(int block, bool isWrite);
    void recordDiskBatch(std::size_t batchSize, long seekDistance);
    // Cost of the same batch in both address spaces: the one we executed, and the one we
    // did not. Lets the report compare the textbook model with the real on-device layout.
    void recordSeekModels(long executedSeek, long otherModelSeek);

    // ---- buffer pool ----
    void cacheHit()         { ++cacheHits_; }
    void cacheMiss()        { ++cacheMisses_; }
    void cacheReplacement() { ++replacements_; }
    void cacheWriteBack()   { ++writeBacks_; }
    void cacheEvent(const std::string& text);

    // ---- synchronization ----
    void syncShared(bool contended);
    void syncExclusive(bool contended);
    void syncMultiLock(std::size_t nBlocks);
    void syncReaders(int concurrentNow);
    void setProducers(int n) { producers_ = n; }
    void setWorkers(int n)   { workers_ = n; }

    // ---- getters (used by the report and by the tests) ----
    std::uint64_t completed() const { return completed_; }
    std::uint64_t preemptions() const { return preemptions_; }
    std::uint64_t cacheHits() const { return cacheHits_; }
    std::uint64_t cacheMisses() const { return cacheMisses_; }
    std::uint64_t replacements() const { return replacements_; }
    std::uint64_t writeBacks() const { return writeBacks_; }
    std::uint64_t diskAccesses() const { return diskAccesses_; }
    std::uint64_t diskReads() const { return diskReads_; }
    std::uint64_t diskWrites() const { return diskWrites_; }
    long long totalSeek() const { return seekTotal_; }
    long long seekExecuted() const { return seekExecuted_; }
    long long seekOtherModel() const { return seekOther_; }
    std::uint64_t maxReaders() const { return maxReaders_; }
    std::uint64_t producerBlocked() const { return producerBlocked_; }
    double avgWaitUs() const;
    double avgTurnaroundUs() const;
    std::vector<std::uint64_t> dispatchOrder() const;
    std::vector<DiskEvent> diskOrder() const;

    std::string report(const StatsContext& ctx) const;

private:
    static void updateMax(std::atomic<std::uint64_t>& target, std::uint64_t v);

    std::atomic<bool> trace_{false};
    mutable std::mutex mtx_;                 // protects the vectors below
    std::vector<std::uint64_t> dispatchOrder_;
    struct Completion { std::uint64_t id; std::string type; int burst; std::uint64_t waitUs, turnUs; };
    std::vector<Completion> completions_;
    std::vector<DiskEvent> diskOrder_;
    std::vector<std::string> cacheEvents_;

    std::atomic<std::uint64_t> enqueued_{0}, producerBlocked_{0}, consumerBlocked_{0}, dispatches_{0},
        firstDispatches_{0}, queueWaitTotalUs_{0}, maxQueueLen_{0}, preemptions_{0}, completed_{0},
        waitTotalUs_{0}, turnTotalUs_{0};
    std::atomic<std::uint64_t> diskAccesses_{0}, diskReads_{0}, diskWrites_{0}, diskBatches_{0},
        diskBatchedReqs_{0}, maxBatch_{0};
    std::atomic<long long> seekTotal_{0}, seekExecuted_{0}, seekOther_{0};
    std::atomic<std::uint64_t> cacheHits_{0}, cacheMisses_{0}, replacements_{0}, writeBacks_{0};
    std::atomic<std::uint64_t> sharedAcq_{0}, exclAcq_{0}, contended_{0}, multiLocks_{0},
        multiLockedBlocks_{0}, maxReaders_{0};
    std::atomic<int> producers_{0}, workers_{0};
};
