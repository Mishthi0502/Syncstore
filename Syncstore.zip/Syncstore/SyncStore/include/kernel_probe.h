// kernel_probe.h - reads the REAL numbers the Linux kernel keeps about this process.
//
// This is what separates SyncStore from a simulator: every claim the scheduler,
// buffer pool or disk scheduler makes is checked against the kernel's own counters.
//
//   /proc/self/io          -> read_bytes / write_bytes = bytes that actually reached
//                             the block device (page cache hits do NOT count here)
//   /proc/self/schedstat   -> ns on CPU, ns waiting on the run queue, timeslices run
//                             (the kernel's own waiting time, next to ours)
//   /proc/self/status      -> voluntary / nonvoluntary context switches (real preemptions)
//   getrusage              -> minor/major page faults, user/system CPU time
//   /proc/diskstats        -> I/Os and sectors the device actually served
//   /proc/meminfo          -> real memory pressure
//
// Needs CONFIG_SCHEDSTATS for schedstat and CONFIG_TASK_IO_ACCOUNTING for io.
// Every field carries an "available" flag so the program still runs where a file is missing.
#pragma once
#include <cstdint>
#include <string>

struct KernelSnapshot {
    bool ioOk = false, schedOk = false, statusOk = false, diskOk = false, memOk = false;

    // ---- /proc/self/io ----
    std::uint64_t rchar = 0, wchar = 0;             // bytes through read()/write() syscalls
    std::uint64_t syscr = 0, syscw = 0;             // number of read/write syscalls
    std::uint64_t readBytes = 0, writeBytes = 0;    // bytes actually fetched from / sent to the device

    // ---- /proc/self/schedstat (nanoseconds) ----
    std::uint64_t cpuRunNs = 0;                     // time this process spent running on a CPU
    std::uint64_t runqueueWaitNs = 0;               // time RUNNABLE but waiting for a CPU
    std::uint64_t timeslices = 0;                   // timeslices the kernel gave it

    // ---- /proc/self/status ----
    std::uint64_t volCtxt = 0, nonvolCtxt = 0;      // nonvoluntary = the kernel preempted us

    // ---- getrusage(RUSAGE_SELF) ----
    std::uint64_t minFaults = 0, majFaults = 0;     // page faults (major = had to hit the disk)
    std::uint64_t utimeUs = 0, stimeUs = 0;         // user / system CPU time

    // ---- /proc/diskstats for the device holding data.db ----
    std::uint64_t devReads = 0, devWrites = 0;          // I/O requests the device completed
    std::uint64_t devSectorsRead = 0, devSectorsWritten = 0;
    std::uint64_t devIoTicksMs = 0;                     // ms the device was busy

    // ---- /proc/meminfo (kB) ----
    std::uint64_t memTotalKb = 0, memAvailableKb = 0;
};

// Per-thread scheduling numbers from /proc/self/task/<tid>/schedstat.
struct ThreadSched {
    bool ok = false;
    std::uint64_t cpuRunNs = 0, runqueueWaitNs = 0, timeslices = 0;
};

class KernelProbe {
public:
    // deviceName like "vda" or "sda"; pass "" if unknown (device counters are then skipped).
    static void setDevice(const std::string& name);
    static const std::string& device();

    static KernelSnapshot snapshot();
    static KernelSnapshot delta(const KernelSnapshot& before, const KernelSnapshot& after);

    static ThreadSched threadSched(long tid);       // tid from gettid()
    static long currentTid();
    static std::uint64_t threadCpuTimeNs();         // CLOCK_THREAD_CPUTIME_ID of the calling thread

    // One line describing what the kernel exposes here (printed at start-up).
    static std::string capabilityLine();
};
