// disk_scheduler.h - disk-head scheduling for block I/O.
//
// Two addressing modes:
//
//   LOGICAL  - the head moves over our own block numbers 0..NUM_BLOCKS-1. This is the
//              textbook model and it is what a simulator does. Kept as the baseline.
//
//   PHYSICAL - the head moves over the REAL physical block addresses that the filesystem
//              gave data.db, read from the kernel with the FIEMAP ioctl. Because a file
//              is scattered across extents, two logically adjacent blocks can be far
//              apart (or backwards) on the device, so the order the algorithms produce
//              is genuinely different from the logical model.
//
// Either way the chosen order is the order in which the real pread()/pwrite() calls are
// issued. With O_DIRECT those calls go to the device, not to the page cache.
//
// Honest limit: the kernel's own I/O scheduler and the device's queue sit below us, so we
// decide the order our requests are *submitted* in, not the order the platter is served in.
// Both seek totals are recorded every batch so the two models can be compared.
#pragma once
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <utility>
#include <vector>
#include "block_file.h"
#include "physical_map.h"
#include "statistics.h"

enum class DiskAlgo { FCFS, SSTF, SCAN, CSCAN, LOOK, CLOOK };
const char* toString(DiskAlgo a);

// Result of ordering one batch of pending requests.
struct DiskPlan {
    std::vector<std::size_t> order;     // indices into the input vector, in service order
    long totalSeek = 0;                 // total head movement, including edge/jump moves
    int endHead = 0;                    // head position after the batch
    bool endDirectionUp = true;         // sweep direction after the batch (SCAN/LOOK)
    std::vector<int> headPath;          // every position the head moves to
};

class DiskScheduler {
public:
    DiskScheduler(BlockFile& file, Statistics& stats);
    ~DiskScheduler();

    void setAlgorithm(DiskAlgo a) { algo_ = a; }
    DiskAlgo algorithm() const { return algo_; }
    void setBatchTarget(std::size_t n) { batchTarget_ = n < 1 ? 1 : n; }
    int headPosition() const { return head_; }
    void resetHead(int pos = 0) { head_ = pos; dirUp_ = true; }

    // ---- real-device addressing ----
    void setPhysicalMode(bool on);
    bool physicalMode() const { return physical_; }
    bool physicalAvailable() const { return file_.map().ready(); }
    // Address used for scheduling: physical block (normalised to 0) or the logical block.
    int addressOf(int block) const;
    int maxAddress() const;
    std::string addressingDescription() const;

    void readBlock(int block, BlockData& out);
    void writeBlock(int block, const BlockData& data);
    void writeBlocks(const std::vector<std::pair<int, BlockData>>& items);   // submitted as ONE batch
    void syncFile() { file_.sync(); }

    // Pure ordering function (no I/O) - also used directly by the unit tests.
    static DiskPlan plan(DiskAlgo algo, int head, bool dirUp, const std::vector<int>& blocks, int maxBlock);

private:
    struct Pending {
        int block = 0;
        bool isWrite = false;
        BlockData* readBuf = nullptr;
        const BlockData* writeBuf = nullptr;
        bool done = false;
        std::string error;
    };
    void submitAndWait(std::vector<Pending>& reqs);
    void run();                                    // the disk-scheduler thread

    BlockFile& file_;
    Statistics& stats_;
    std::atomic<DiskAlgo> algo_{DiskAlgo::FCFS};
    std::atomic<std::size_t> batchTarget_{1};
    std::atomic<int> head_{0};
    std::atomic<bool> dirUp_{true};
    std::atomic<bool> physical_{false};
    int physBase_ = 0, physMax_ = 0;               // normalisation of the real address range

    std::mutex mtx_;
    std::condition_variable cvWork_, cvDone_;
    std::vector<Pending*> pending_;
    bool stop_ = false;
    std::thread thread_;
};
