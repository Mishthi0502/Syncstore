# SyncStore – a key-value store that actually operates the OS

A multithreaded, **purely local** key-value store in C++17 whose purpose is to make
Operating-Systems concepts *do real work*: CPU scheduling, disk-head scheduling,
buffer-pool memory management, process synchronization, deadlock prevention and
crash recovery.

**No networking of any kind** – no sockets, TCP/UDP, HTTP or client-server code.
"Users" are either worker threads or, in multi-process mode, real `fork()`ed processes
talking to the server through POSIX shared memory.

---------------------------------------------------------------------------------------------

## 1. "Is this just a simulator?"

No, and the program is built to prove it rather than claim it.

A simulator invents the state of the world: it keeps a pretend disk-head position, it
represents a CPU burst with `sleep()`, and it reports numbers that only it has ever seen.
SyncStore asks the kernel instead. Every mechanism below runs against the real machine, and
every number it reports is printed **next to the kernel's own counter for the same thing**.

| OS mechanism | What a simulator does | What SyncStore does | How you check it |
|---|---|---|---|
| CPU burst | `sleep(300us)` – the thread is *blocked*, so the scheduler never has to do anything | Runs **real computation** calibrated to cost 300 µs of measured CPU time (`CLOCK_THREAD_CPUTIME_ID`). The thread stays *runnable* and really competes for a core | `/proc/self/task/<tid>/schedstat` shows real run-queue waiting |
| CPU policy | Imitates FCFS / Round Robin in user code | Hands FCFS and RR to **Linux itself** via `sched_setscheduler(SCHED_FIFO / SCHED_RR)`; pins workers with `sched_setaffinity` | `sched_getscheduler`, `sched_rr_get_interval` |
| Disk head | A variable counting 0…199 | Moves over the **real physical block addresses** the filesystem gave `data.db`, read from the kernel with the `FIEMAP` ioctl | Menu 10 prints the extent map and both costs |
| Disk I/O | Nothing, or a buffered write the page cache absorbs | `O_DIRECT`, so a buffer-pool miss is a **true device access** | `/proc/self/io read_bytes` and `/proc/diskstats` |
| Page replacement | Counts hits and misses in a model | Same FIFO/LRU/Clock, but a miss now costs a real device read, so the policy changes real time | Hit ratio vs real bytes moved |
| Process synchronization | Threads inside one process, `std::mutex` | Real processes from `fork()`, a bounded buffer in **POSIX shared memory**, and semaphores created with `sem_init(pshared=1)` that work *across process boundaries* | Menu 6 prints the child PIDs |
| Durability | Assumed | **Write-ahead log** forced with `fdatasync` before the page may move, replayed at start-up | Menu 9 kills a process with `SIGKILL` and recovers |
| Exclusion between programs | Not modelled | `fcntl(F_SETLK)` advisory lock on the data file; the kernel releases it if we die | Start a second `./syncstore` on the same file |

### The one-line version for a viva

> In a simulator, the disk scheduler orders I/O that never happens.
> Run `make demo-simulated` and the report says: *we issued 303 block reads, the device
> moved 0 B, `/proc/diskstats` recorded 0 reads.*
> Run `make demo` and it says: *we issued 224 block reads = 896 KB, the device moved
> 896 KB, `/proc/diskstats` recorded 224 reads.*
> Same code, same algorithms. One of those two runs is a simulation, and it is not the
> second one.

Every "real" mechanism can be switched back to its modelled version with a command-line
flag (`--no-direct`, `--no-real-work`, `--logical-disk`, `--no-wal`). That is deliberate:
the comparison is the demonstration.

### "But the processes are made up"

A fair criticism of any OS lab project: its "processes" are rows in a table — `P1, burst 5,
priority 2` — invented so they can be sorted. Sorting a table you invented proves nothing,
and a generated workload of random SET/GET commands is only slightly better.

So the workload can come from outside the program entirely:

```bash
./syncstore --ingest src --verify      # store real files, read them back, check the bytes
./syncstore --verify                   # a SEPARATE run verifies what is on disk
./syncstore --compare                  # the same real data under every policy
```

`--ingest` walks a real directory, splits every file into records and stores them through
the entire pipeline — bounded queue, CPU scheduler, block locks, write-ahead log, buffer
pool, disk scheduler, device. `--verify` reads them back, reassembles them and compares a
CRC-32 against the original files still sitting on the filesystem.

```
stored 18 real file(s) as 93 records
150327 bytes of real data in 121.0 ms; the kernel says 1336 KB actually reached the device.
18 file(s) checked: 18 came back exactly as stored, 0 corrupt, 0 missing.
```

This matters for one reason: **correctness becomes externally checkable.** If the block
locking has a race, if the write-back ordering is wrong, if recovery replays the wrong
record, a file comes back with the wrong bytes and the program says so. A simulator has
nothing to be wrong about — its numbers cannot disagree with reality because they never
touch it. Run `--verify` in a separate process and the data is re-read from the device and
checked again, so durability is tested too, not asserted.

The verification separates two questions that are easy to conflate: *did the data come back
as stored* (our correctness) and *does it still match the file on disk* (has the source been
edited since). Only the first is a bug.

### Scheduling real processes, not request objects

Everywhere above, a "process" is a request object handled by a worker thread. Defensible,
but still our own bookkeeping. `--jobs` removes that last layer:

```bash
./syncstore --jobs src                       # all four algorithms, compared
./syncstore --jobs src --job-algo rr          # watch Round Robin preempt
./syncstore --jobs /path/to/my/files --job-count 10
```

Each file in the directory becomes a **real child process** created with `fork()`, with its
own PID and its own entry in the kernel's run queue. Run `top` in a second terminal and you
can watch them appear. Each one reads a real file, finds near-duplicate lines in it, and
writes a report you can open in `data/reports/`.

Three things are real that cannot be in a request-object model:

* **Preemption is a real `SIGSTOP`.** Under Round Robin the scheduler does not move an
  object to the back of a list — it sends a signal and the kernel genuinely suspends the
  process mid-computation, then resumes it later with `SIGCONT`.
* **Priorities reach the kernel.** Each child calls `setpriority()`, so the kernel's own
  scheduler sees the ordering too.
* **CPU time is the kernel's figure**, taken from `wait4()`'s `rusage`, not from our clocks.

The live trace shows the interleaving as it happens:

```
[t=0.00  s] START  job 2 (buffer_pool.cpp, 7 KB, burst~10, prio 2) pid 268
[t=0.06  s] STOP   job 2 (buffer_pool.cpp) pid 268  quantum expired -> back of queue
[t=0.26  s] RESUME job 1 (block_file.cpp) pid 267
[t=0.45  s] DONE   job 1 (block_file.cpp) pid 267  cpu 126.91 ms, 3 slice(s)
```

And the comparison comes out the way the theory says it should, on real processes:

| algorithm | avg wait ms | avg turnaround ms | makespan ms | preemptions |
|---|---|---|---|---|
| FCFS | 292.5 | 448.4 | 784.4 | 0 |
| SJF | **143.2** | **294.2** | 759.6 | 0 |
| Priority | 151.1 | 301.4 | 754.9 | 0 |
| Round Robin | 306.7 | 462.9 | 788.0 | **11** |

SJF gives the lowest average waiting time, as it provably must. Round Robin is worst on that
measure and pays 11 real context switches for it — which is the correct trade, because RR
optimises fairness and response time, not average waiting.

**Why the work is what it is.** Each job finds near-duplicate lines by comparing every pair
of lines in the file, so its cost grows with the *square* of the file length. That is what
makes "estimate the burst from the file size" a meaningful thing for a scheduler to attempt,
and why a 7 KB file genuinely takes 20× longer than a 1 KB one. The analysis is repeated a
configurable number of times (`--job-passes`, default 80) for one honest reason, which the
output file states: a single pass finishes in a few milliseconds, far too short to observe
any scheduling decision. The work is real either way; repeating it makes the job long enough
to watch.

**On using several laptops:** it would not add anything. Real CPU scheduling needs real
processes competing for real cores, and that happens on one machine — which is exactly what
this mode does. Spreading the jobs across machines would require sockets and turn the project
into a Computer Networks exercise, which is the thing the design set out to avoid.

### Does the algorithm choice actually cost anything?

`--compare` runs the same concurrent read workload over that real data under every
cache/disk combination — 4 threads, 400 reads each, 80 % of them into a 20 % hot set.
Two measured runs on the dev machine:

| disk algorithm | seek, run 1 | seek, run 2 |
|---|---|---|
| FCFS   | 2,343,911 | 2,311,479 |
| C-LOOK | 1,958,454 | 1,953,024 |
| SCAN   | 1,713,756 | 1,725,456 |
| SSTF   | 1,432,066 | 1,551,176 |

The ordering is exactly what the theory predicts, it is stable across runs, and it holds
for all three replacement policies. That is a reproducible experimental result on real data
and real device addresses — not a number the program printed about itself.

**The honest half of the same table:** the cache hit counts (467–505 out of 1600) do *not*
separate. At this pool size and hot-set ratio the three replacement policies sit inside
run-to-run noise, and the program says so rather than pretending otherwise. Widen the pool
or narrow the hot set and the gap appears — that is an experiment to run, not a claim to
make. An earlier version of this benchmark used a single sequential pass and every policy
scored identically, because a pass with no re-reference is all compulsory misses. Knowing
*why* a benchmark shows nothing is worth more than a benchmark that shows something.

---------------------------------------------------------------------------------------------

## 2. Build, run, test (Ubuntu / Linux, g++ ≥ 9)

```bash
make            # builds ./syncstore and ./test_runner
./syncstore     # interactive menu (data file: data/data.db, created automatically)
make demo       # one non-interactive pass through every feature - best first run
make test       # 101 checks (~60 s)
make fresh      # start from an empty database
make clean
```

Useful flags:

```bash
./syncstore --workers 8 --frames 32        # more contention, bigger cache
./syncstore --policy rr --pin              # real SCHED_RR, one worker per core (needs sudo)
./syncstore --ingest src --verify          # real files in, checksummed on the way out
./syncstore --compare                      # every policy, measured on that real data
./syncstore --jobs src                     # real processes on real files, all four algorithms
make demo-simulated                        # the same demo with every mechanism modelled
```

Open the folder in VS Code and use the integrated terminal – no extra setup is needed.

**What needs privileges:** nothing, by default. `SCHED_FIFO` / `SCHED_RR` need `CAP_SYS_NICE`
(run with `sudo`); without it the program says so and stays on `SCHED_OTHER`.

**What may be unavailable on some systems:** `O_DIRECT` and `FIEMAP` need a real filesystem
(ext4, xfs, btrfs). Inside Docker's overlayfs, or on tmpfs, they can be refused. SyncStore
detects this, prints *why*, falls back to the modelled behaviour and keeps running – it
never pretends a mechanism worked.

## 3. Project layout

```
SyncStore/
├── include/                      src/
│   ├── common.h        4 KB blocks (= page size = ext4 block = O_DIRECT alignment)
│   ├── request.h       Request = the "process" being scheduled
│   ├── command_parser.h          command_parser.cpp   validate "SET k v" ...
│   ├── block_file.h              block_file.cpp       O_DIRECT file I/O, aligned buffers
│   ├── physical_map.h            physical_map.cpp     FIEMAP: where blocks really live   [new]
│   ├── kernel_probe.h            kernel_probe.cpp     /proc + getrusage counters         [new]
│   ├── cpu_work.h                cpu_work.cpp         real CPU work, real sched policies [new]
│   ├── wal.h                     wal.cpp              write-ahead log + recovery         [new]
│   ├── ipc.h                     ipc.cpp              shm + pshared semaphores + fork    [new]
│   ├── real_workload.h           real_workload.cpp    ingest real files, CRC verify      [new]
│   ├── job_scheduler.h           job_scheduler.cpp    schedule real fork()ed processes   [new]
│   ├── statistics.h              statistics.cpp       all metrics + STATS report
│   ├── cpu_scheduler.h           cpu_scheduler.cpp    FCFS / SJF / Priority / RR
│   ├── request_queue.h           request_queue.cpp    bounded queue, POSIX semaphores
│   ├── disk_scheduler.h          disk_scheduler.cpp   FCFS SSTF SCAN C-SCAN LOOK C-LOOK
│   ├── buffer_pool.h             buffer_pool.cpp      FIFO / LRU / Clock, dirty write-back
│   ├── sync_manager.h            sync_manager.cpp     per-block RW locks, ordered multi-lock
│   ├── storage_engine.h          storage_engine.cpp   SET GET DEL LIST MSET on blocks
│   ├── syncstore.h               syncstore.cpp        wires everything + worker threads
│   │                             validation.cpp       model vs kernel report             [new]
│   │                             main.cpp             terminal menu
├── tests/test_main.cpp           116 checks, 27 areas
├── data/data.db                  created at first run (+ data.db.wal, data.db.lock)
├── Makefile
└── README.md
```

## 4. Architecture

```
  ┌─────────────────────────────┐    ┌──────────────────────────────────────────────┐
  │ 1  Terminal menu / CLI      │    │ Client PROCESSES (fork)                      │
  └──────────────┬──────────────┘    │  POSIX shm ring + sem_init(pshared=1)        │
                 │ text line         └───────────────────┬──────────────────────────┘
          ┌──────▼──────┐                                │ Request objects
          │ 2  Parser   │  validates, estimates burst + priority
          └──────┬──────┘                                │
                 └───────────────────┬──────────────────-┘
                                     ▼
          ┌──────────────────────────────────────────────┐
          │ 4  Bounded queue   sem_t emptySlots/fullSlots │  ← PRODUCER-CONSUMER
          └──────────────────────────┬───────────────────┘
                                     │ pop(): 5  CPU SCHEDULER chooses the request
                                     ▼   (FCFS | SJF | Priority | Round Robin)
          ┌──────────────────────────────────────────────┐
          │ 6  Worker pool, under a REAL kernel policy    │  runs REAL work for a slice;
          │    SCHED_OTHER / SCHED_FIFO / SCHED_RR        │  RR: preempt → requeue at tail
          └──────────────────────────┬───────────────────┘
                                     ▼
          ┌──────────────────────────────────────────────┐
          │ 10 Storage engine  (key → block via hash)    │
          └───────┬──────────────────────────────────────┘
                  │ 12 WRITE-AHEAD LOG: append + fdatasync BEFORE the page may change
          ┌───────▼──────────────────────────────────────┐
          │  7 Lock manager: one shared_mutex per block  │  ← SYNC + DEADLOCK PREVENTION
          └───────┬──────────────────────────────────────┘
                  ▼
          ┌──────────────────────────────────────────────┐
          │ 8  Buffer pool (N frames, FIFO/LRU/Clock)    │  hit → memory copy
          └───────┬──────────────────────────────────────┘
                  │ miss, or write-back of a dirty victim
          ┌───────▼──────────────────────────────────────┐
          │ 9  Disk scheduler thread                     │  batches pending block I/O and
          │    orders them by REAL physical address      │  reorders by real head position
          └───────┬──────────────────────────────────────┘
                  ▼  pread()/pwrite() with O_DIRECT, in the scheduled order
          ┌──────────────────────────────────────────────┐
          │  data.db  on /dev/vda   (page cache bypassed) │
          └──────────────────────────────────────────────┘
   11 Statistics + 13 Validation: every layer reports into one thread-safe object, and
      every claim is printed next to the kernel's independent counter for the same thing.
```

**Workflow of one command** – menu → parser validates → request enters bounded queue →
CPU scheduler picks it → worker runs *real work* for a slice → locks acquired in block
order → **redo record appended and fsync'd** → buffer pool checked → on miss/write-back the
block I/O is scheduled by real physical address → storage engine returns → locks released →
result + waiting/turnaround time printed.

## 5. The OS concepts, and exactly what is real

### 5.1 CPU scheduling (`cpu_scheduler.*`, `cpu_work.*`, `request_queue.*`)

* Every command becomes a `Request` (the PCB): `burst`, `priority` (lower = more urgent),
  `remaining`, arrival time. Default bursts: GET 1, DEL 2, SET 3, MSET 2+2·pairs, LIST 6.
  Priorities: GET 1, SET/DEL 2, MSET 3, LIST 4.
* The queue is the classic bounded buffer: producers `sem_wait(emptySlots)`, workers
  `sem_wait(fullSlots)`. Capacity (16) bounds admitted-but-unfinished requests.
* **The scheduler really controls execution:** `RequestQueue::pop()` calls
  `CpuScheduler::selectNext()` *under the queue lock*; whatever it returns is what runs.
  FCFS – smallest id; SJF – smallest remaining burst; Priority – smallest priority number;
  Round Robin – head of queue.
* **Round Robin preemption:** a worker runs at most *quantum* units; if burst remains the
  request goes to the tail. The storage operation executes in the final slice.

**What is real here.** A burst unit is not a sleep. `CpuWork::calibrate()` measures, at
start-up, how many iterations of a checksum-and-compaction pass over a 4 KB page cost
300 µs of CPU on *this* machine, then each slice runs that many. The worker is therefore
`RUNNABLE`, not `BLOCKED`, so with more workers than cores the kernel genuinely has to
arbitrate. Measured on a 2-core machine with 4 workers:

```
kernel : worker threads ran 192.2 ms on a CPU and waited 114.9 ms on the run queue,
         over 1719 timeslices   (/proc/self/task/<tid>/schedstat)
         workers spent 37.4 % of their runnable time waiting for a core
```

With `--no-real-work` the same workload reports **21.3 ms** of CPU: the sleep consumed wall
time and nothing else. That difference is the whole argument.

`--policy fifo` / `--policy rr` hand the policy to Linux through `sched_setscheduler`, so
FCFS and Round Robin are then enforced by the kernel, not imitated by us. SJF has no kernel
equivalent – that is the part our user-level scheduler adds, and the reason it still exists.

### 5.2 Disk scheduling (`disk_scheduler.*`, `physical_map.*`, `block_file.*`)

* Each key hashes (FNV-1a) to a preferred block (linear probing on collisions);
  one record per 4 KB block.
* Every block read (cache miss) or write (write-back/flush) becomes a block I/O request.
* A dedicated **disk-scheduler thread** collects pending requests into a batch (waits
  ≤ 0.5 ms), asks `DiskScheduler::plan()` for the service order, then performs the **real**
  `pread()/pwrite()` calls in that order.
* Seek distance counts every block crossed, including the trip to the disk edge
  (SCAN, C-SCAN) and the return jump (C-SCAN, C-LOOK). SCAN/LOOK remember their direction.
* Verified against the textbook example (head 53; 98 183 37 122 14 124 65 67; disk 0‥199):
  FCFS 640, SSTF 236, SCAN 331, C-SCAN 382, LOOK 299, C-LOOK 322.

**What is real here.** The head position is not invented. `FIEMAP` returns the extents the
filesystem actually gave `data.db`, and the scheduler orders requests by those addresses.
A database file ages into several extents, so logical and physical order genuinely diverge.
From one run:

```
extents        : 5   backward jumps in physical order: 1
    logical    0 ..   15  ->  physical 3261563 .. 3261578
    logical   16 ..   31  ->  physical 3254256 .. 3254271   (backwards)
    logical   32 ..   63  ->  physical 3258464 .. 3258495
```

Logical block 16 lives *before* logical block 0 on the platter. So the two models disagree
about what to do, not merely about the cost:

```
Algo      model seek      real-layout seek    service order (logical blocks)
FCFS      915             25389               10 150 25 190 60 120 5 175
SSTF      190             7137                5 10 25 60 120 150 175 190
                          real order differs -> 25 60 120 150 175 190 5 10
```

A simulator that only knows logical block numbers sends the head on a journey the device
does not need. Both columns are in 4 KB blocks, so they are directly comparable.

`O_DIRECT` is what makes the I/O real. Without it the page cache answers everything and the
buffer pool is a cache in front of a cache. With it:

```
ours   : we issued 224 block reads = 896.0 KB
kernel : the device moved 896.0 KB   (ratio 1.00)   [/proc/self/io]
kernel : device vda completed 224 reads               [/proc/diskstats]
```

Three independent counters agree. With `--no-direct` the same run reports
`we issued 303 block reads … the device moved 0 B … 0 device reads`.

**Honest limit.** The kernel's own I/O scheduler and the device queue sit below us, so we
decide the order our requests are *submitted* in, not the order the platter is finally
served in. We also do not control head movement directly – no user program can. What we do
control, and measure, is the sequence of real device accesses and the real distance between
the addresses they touch.

### 5.3 Memory management – buffer pool (`buffer_pool.*`)

* Fixed number of frames (default 8). Each frame: block number, 4 KB of data, **dirty bit**,
  **reference bit** (Clock), load sequence (FIFO), last-use tick (LRU).
* Hit → copy from the frame. Miss → pick a victim (free frame first, otherwise FIFO / LRU /
  Clock), write it back if dirty, load the new block through the disk scheduler.
* **Write-back policy:** SET/DEL only modify the frame and set the dirty bit. The disk is
  written when the dirty block is evicted, on `FLUSH`, when the pool is resized, and at exit.
  A full-block overwrite is installed without reading the old block first (write-allocate,
  no fetch) – which is why "misses" exceed "reads issued" in the statistics.
* The disk read happens *outside* the pool mutex (frame marked `loading`, others wait on a
  condition variable), so several misses can be batched and reordered. Dirty write-back is
  done holding the pool mutex so nobody re-reads a block before its newest version is down.

**What is real here.** Because of `O_DIRECT`, a miss is a device access and a hit is not, so
changing FIFO → LRU → Clock changes real elapsed time and real bytes moved, not just a
counter. `getrusage` minor/major page faults and `/proc/meminfo` are reported alongside.

### 5.4 Process synchronization and deadlock prevention (`sync_manager.*`, `ipc.*`)

* **Threads:** `std::shared_mutex` per block. GET takes it *shared* (many readers at once);
  SET/DEL take it *exclusive*. The lock manager records any reader/writer overlap – the tests
  show it stays at 0. A small index mutex protects the key→block map; after taking a block
  lock the engine **re-validates** that the key still owns the block and retries, closing the
  check-then-act race.
* **Deadlock prevention (MSET, LIST):** deadlock needs *circular wait*.
  `SyncManager::lockAll()` sorts the blocks and locks them in **ascending block order**, so
  two MSETs asking for the same keys in opposite order can never form a cycle. MSET is atomic
  (all keys written while all locks are held); LIST takes ordered shared locks and sees a
  consistent snapshot.
* Other conditions: no hold-and-wait across layers (the pool lock is never held while waiting
  for a block lock; the disk thread never takes any other lock).

**What is real here (menu 6).** `std::mutex` only synchronises threads of one process, so the
original "users are producer threads" design was the weakest part of the project. Multi-process
mode replaces it: `shm_open` + `mmap` create a region shared with `fork()`ed children, the
bounded buffer lives inside it, and its semaphores are created with `sem_init(..., pshared=1)`
so the producer-consumer handshake crosses address spaces. Each slot carries its own
completion semaphore, so a client blocks until *its* reply is ready.

```
4 real processes (pids 824..827) talked to this one through 49 KB of POSIX shared memory
served 100 in 188.1 ms, avg latency 6.16 ms, client blocked 0, server blocked 95
```

`DataFileLock` adds `fcntl(F_SETLK)` on `data.db`, so a second `./syncstore` on the same file
is refused and told which PID holds it. The kernel drops that lock automatically if we are
killed – something a plain lock file cannot do.

### 5.5 Crash recovery (`wal.*`) – new

The buffer pool is write-back, which is fast and loses data on a crash. The fix is the rule
every real database obeys: **the redo record goes to the device before the page is allowed to
change.** `StorageEngine::logThenWrite()` appends the after-image, calls `fdatasync()`, and
only then hands the page to the pool. At start-up `Wal::recover()` replays the log, discards
a torn tail (CRC-32 per record) and truncates.

Menu 9 demonstrates it honestly: a child process commits 25 keys, reports that 8 pages are
still only in memory, and raises `SIGKILL` – no destructors, no flush, no `fsync` of the data
file. The parent reopens and finds all 25 keys. With `--no-wal`, the same crash loses 4 of 15.

Measured cost of durability on this machine: **~300 µs per committed write**, all of it inside
`fdatasync`. That number is the reason write-back caching exists at all.

## 6. Using the program

```
 1. Execute Command                     8. Reality Check (model vs kernel)
 2. Select CPU Scheduling               9. Crash Recovery Demo (SIGKILL)
 3. Select Disk Scheduling             10. Compare Disk Algorithms (model vs real layout)
 4. Select Page Replacement            11. View Storage Contents
 5. Run Concurrent Workload (threads)  12. Configuration
 6. Run Multi-Process Workload (fork)  13. Exit (flushes + checkpoints)
 7. View System Statistics
11. Schedule Real Processes on Real Files (fork + SIGSTOP/SIGCONT)
```

Commands: `SET k v`, `GET k`, `DEL k`, `LIST`, `MSET k1 v1 k2 v2 …`, `STATS`, `FLUSH`,
`HELP`, `BACK`. Limits: key ≤ 32 chars without spaces, value ≤ 3900 chars, 200 records.

**Tips for the demo:** *Configuration → Live trace ON* prints one line per OS event:
`[CPU]` dispatch/preempt, `[DISK]` arrived vs served order + seek (and what the other
addressing model would have cost), `[CACHE]` evictions, `[SYNC]` lock order.
Set workers above the core count to make run-queue waiting appear in the Reality Check.

### Sample session (real output, abridged)

```
syncstore> SET name Alice
OK (block 22)
  [R1 SET | burst 3, priority 2 | waiting 0.080 ms, turnaround 1.156 ms | real CPU 905.2 us on core 1]
syncstore> MSET city Delhi age 20
OK (2 keys, locked blocks: 154 188)
syncstore> DEL course
DELETED (block 136 freed)
syncstore> GET missing
  (not found)
syncstore> SET bad
  Invalid: SET: missing value  (usage: SET key value)
```

## 7. Tests (`make test`) – 116 checks

| # | Area | Verified |
|---|------|------|
| 1 | FCFS CPU | order R1 R2 R3 R4 |
| 2 | SJF | bursts 6,8,7,3 → R4 R1 R3 R2 |
| 3 | Priority | priorities 3,1,4,2 → R2 R4 R1 R3 |
| 4 | Round Robin | q=3, bursts 5,3,4 → R1 R2 R3 R1 R3, 2 preemptions |
| 5–6 | All six disk algorithms | textbook seeks 236/331/382/299/322/640 plus exact orders |
| 7–8 | LRU / FIFO / Clock | Clock keeps 2 where FIFO evicts it |
| 9–10 | Hit/miss, dirty write-back | disk unchanged until eviction |
| 11 | Readers/writers | 4 writers + 4 readers → 0 torn values, 0 exclusion violations |
| 12 | Deadlock prevention | 4 threads × 300 opposite-order MSETs + LIST all finish |
| 13–14 | Persistence, 2000-request volume | under all four CPU algorithms |
| **15** | **Kernel counters** | `/proc/self/io`, schedstat, status, getrusage all readable and moving |
| **16** | **Real work, not sleep** | CPU time ≈ wall time (2971 µs vs 2973 µs) |
| **17** | **Run-queue contention** | 6 workers on 2 cores → 124 ms of real waiting |
| **18** | **O_DIRECT** | 50 reads → exactly 204800 device bytes |
| **19** | **Page cache** | buffered mode: same reads cost **0** device bytes |
| **20** | **Physical layout** | FIEMAP map valid; SSTF order differs from the logical model |
| **21** | **WAL + SIGKILL** | 15 redo records replayed, all keys intact |
| **22** | **No WAL + SIGKILL** | data really is lost – the control case |
| **23** | **Multi-process IPC** | 4 forked PIDs, 80 cross-process requests served |
| **24** | **fcntl locking** | second process refused, succeeds after release |
| **25** | **Cross-checking** | our read count vs device bytes, ratio 1.00 |
| **27** | **Real process scheduling** | 4 real files become 4 real PIDs; every child reports non-zero CPU time via `wait4` rusage, writes its report, the bigger file really costs more CPU (189 ms vs 14 ms), and Round Robin really preempts via SIGSTOP (16 times) with every process still finishing correctly |
| **26** | **Real files round-trip** | 7 binary files of awkward sizes (1 B … 12345 B) stored, read back byte-identical, and verified again after closing and reopening the database |

Tests 19 and 22 are *negative* controls: they prove the mechanism matters by showing what
happens when it is switched off. Test 26 is the one that cannot be faked: the data is real,
the sizes are deliberately awkward (including a 1-byte file and sizes either side of the
1800-byte chunk boundary), the content includes NUL and 0xFF bytes, and a single wrong byte
anywhere in the pipeline fails it.

## 8. Design decisions and honest limits (state these in the viva)

* **Block size is 4096 B** because that is simultaneously the page size, the ext4 block size
  and the `O_DIRECT` alignment requirement, so "page" and "block" are the same real object.
* **One burst unit = 300 µs of real CPU**, calibrated per machine. Calibration takes ~20 ms
  at start-up and is printed in the environment report.
* **Waiting time** = turnaround − service, so lock/disk waits inside the operation count as
  execution. Admission delay when the queue is full counts as waiting. The kernel's own
  run-queue wait is reported separately and measures something slightly different – that is
  why both appear.
* Priority scheduling has **no aging**, so low-priority LIST requests can starve.
* **We do not control the physical disk head.** We control the order our requests reach the
  kernel and we measure the real distance between the real addresses involved. The kernel's
  I/O scheduler and the drive's own queue remain below us.
* `FIEMAP` gives offsets within the *partition*; on a partitioned disk add the partition
  start for whole-disk addresses. Fine for seek *distance*, which is what the algorithms use.
* Write-back of a dirty victim is synchronous while holding the pool mutex (simple and
  correct; limits parallelism).
* `resize` of the pool / worker count must happen while the system is idle (the menu ensures it).
* Real-time policies are capped to the bottom 10 % of the priority range, and Linux's RT
  throttle (`sched_rt_runtime_us`, 95 % by default) is the second safety net.
* Storage capacity: 200 records, one per block.
* The fragmented-layout helper creates a filler file next to `data.db` while laying out a new
  database and deletes it immediately; it only runs when the file does not yet exist.

## 9. Viva questions and answers

1. **Why no sockets?** The project is about OS mechanisms; networking would make it a CN
   project. Users are real local processes (menu 6), which is what multi-user actually means
   to the kernel.
2. **Your professor said no simulators. What makes this one different?** Section 1. The short
   answer: run `make demo-simulated` and `make demo` and compare the device counters. In the
   first, the disk scheduler orders 303 reads the device never performs.
3. **Where exactly is the CPU scheduler?** `RequestQueue::pop()` → `CpuScheduler::selectNext()`.
   The worker executes whatever it returns (tests 1–4).
4. **How is a burst "real"?** `CpuWork::burn()` runs a checksum + compaction pass over a 4 KB
   page, calibrated so one unit costs 300 µs of `CLOCK_THREAD_CPUTIME_ID`. Test 16 shows CPU
   time ≈ wall time; with `sleep()` it would be ~0.
5. **Prove the kernel had to schedule anything.** `/proc/self/task/<tid>/schedstat` field 2 is
   time spent runnable but off-CPU. With 4 workers on 2 cores it is 114.9 ms, 37 % of their
   runnable time. Sleeping threads cannot produce that.
6. **Preemptive vs non-preemptive here?** FCFS/SJF/Priority run the whole burst; RR runs
   ≤ quantum units then requeues at the tail. `--policy rr` additionally puts the kernel's own
   `SCHED_RR` underneath, with the quantum `sched_rr_get_interval` reports.
7. **Why does SJF give the lowest average waiting time?** Running short jobs first reduces the
   time every other job waits behind a long one (provably optimal for non-preemptive
   scheduling with known bursts). Drawbacks: starvation and the need to estimate bursts.
8. **Why is Round Robin slower on average?** Every preemption adds a requeue and re-dispatch.
   RR optimises fairness and response time, not average waiting.
9. **Is this controlling the real disk?** No, and section 5.2 says so explicitly. It schedules
   real requests by real physical addresses and measures real device traffic. No user-space
   program can command a disk head.
10. **How do you know where a block physically is?** The `FIEMAP` ioctl returns the file's
    extents. Menu 10 prints them; a fragmented file shows backward jumps.
11. **SCAN vs C-SCAN vs LOOK vs C-LOOK?** SCAN sweeps to the edge and reverses; C-SCAN sweeps
    one way, jumps back to the start and sweeps again (more uniform waiting); LOOK/C-LOOK only
    travel to the last pending request instead of the edge.
12. **Why can SSTF starve requests?** A far-away request keeps losing to nearer newcomers.
13. **What does O_DIRECT change?** It removes the page cache, so a buffer-pool miss becomes a
    device access. Without it the replacement policy cannot affect real I/O at all (test 19).
14. **How does a key map to a block?** FNV-1a mod 200 gives the preferred block; linear probing
    handles collisions; a free-block bitmap tracks use; the index is rebuilt by scanning
    `data.db` at start-up, like a mount-time check.
15. **FIFO vs LRU vs Clock?** FIFO evicts the oldest-loaded, LRU the least recently used, Clock
    approximates LRU with a reference bit and a sweeping hand. Test 8 shows a sequence where
    Clock and FIFO pick different victims.
16. **Dirty bit and write-back?** A modified frame is marked dirty and written only on
    eviction/flush, saving writes for repeatedly updated blocks (test 10).
17. **Why is the disk read done outside the buffer-pool mutex?** So several misses can be
    pending together and the disk scheduler can reorder them. The `loading` flag plus a
    condition variable stop two threads loading the same block.
18. **Which synchronization primitives are used?** `sem_t` (bounded queue, and process-shared
    for IPC), `std::mutex`, `std::shared_mutex` (readers-writer per block),
    `std::condition_variable`, atomics, and `fcntl` file locks between programs.
19. **Can writers starve?** Per-block `shared_mutex`: many readers or one writer. Writer
    starvation depends on the glibc rwlock policy (reader-preferring by default). We guarantee
    correctness, not fairness, and say so.
20. **Four conditions for deadlock, and which do you break?** Mutual exclusion, hold-and-wait,
    no preemption, circular wait. We break **circular wait** by locking multiple blocks in
    ascending order (resource ordering).
21. **What race does re-validation after locking solve?** Between looking up key→block and
    taking the block lock another thread may delete the key and reuse the block. After locking
    we re-check the index and retry.
22. **Why is MSET atomic and LIST consistent?** MSET holds all its block locks while writing;
    LIST takes shared locks on all used blocks in the same ascending order (test 12).
23. **What does the bounded queue prevent?** Overflow (producers block on `emptySlots`) and
    busy waiting (workers block on `fullSlots`). STATS counts how often each side blocked.
24. **Why does multi-process mode need different primitives?** `std::mutex` and
    `std::condition_variable` live in one address space. Across processes you need memory both
    can see (`shm_open` + `mmap`) and semaphores created with `pshared=1`.
25. **What is the write-ahead rule and why?** Append the redo record and `fdatasync` it
    *before* the page may change. A crash between the two is harmless because recovery replays
    the record; the reverse order could lose a committed write (tests 21 and 22).
26. **What does recovery do with a half-written record?** Each record carries a CRC-32. The
    first record that fails its checksum or runs past the end of the file ends the replay, and
    the torn tail is discarded – that is exactly where the power cut landed.
27. **How much does durability cost?** ~300 µs per commit on this machine, essentially all of
    it inside `fdatasync`. That is the measurement that justifies group commit in real systems.
28. **Why an advisory lock instead of a lock file?** `fcntl(F_SETLK)` is held by the kernel and
    released automatically when the process dies, so a crash cannot leave a stale lock behind.
29. **What happens on a filesystem without FIEMAP or O_DIRECT?** The program says so in the
    environment report, falls back to the logical model, and keeps running. It never claims a
    mechanism worked when it did not.
30. **"You just pick an algorithm from a menu and print its runtime — that's a simulator."**
    The menu is simulator-shaped, agreed. The difference is what sits underneath it. A
    scheduling simulator's processes exist only to be sorted, and their runtime is computed
    by adding their own burst numbers back up. Here a request writes real bytes to a real
    device, the runtime is measured from clocks and cross-checked against the kernel, and
    `--ingest`/`--verify` lets the workload be real files whose contents are checksummed on
    the way out. If any mechanism is wrong, a file comes back corrupt. Ask a simulator to be
    wrong about something and it cannot.
31. **What is still modelled?** Burst *estimates* (GET 1, SET 3 …) are heuristics, as they are
    in any scheduler that has not run the job yet; the request→"process" mapping is ours; and
    the head-distance cost model assumes distance is proportional to blocks crossed, which is
    true of a rotating disk and only roughly true of an SSD – which is why the report prints
    whether the kernel calls the device rotational.
